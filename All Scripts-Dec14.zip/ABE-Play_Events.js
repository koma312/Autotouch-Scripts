const { touchDown, touchMove, touchUp, usleep, appActivate, keyDown, keyUp, tap, toast, } = at
const targetImagePath = 'images/abe_win.png'
const options = {
    targetImagePath: targetImagePath,
    count: 0,
    threshold: 0.5,
    region: null,
    debug: false, 
    method: 1,
}

usleep(2e6);
toast("starting", 8);
tap(498, 1036);
usleep(1e7);
toast("autoplay", 6);
usleep(1e6);
tap(1982, 1467);
usleep(5e6);

at.findImage({
    options,
    duration: 600,
    interval: 1000,
    exitIfFound: true,
    errorCallback: error => {alert(error)},
    block: true, 
})

toast('exiting findImage', 5);
usleep(8000000);
toast("Victory", 6);
usleep(1000000);
tap(1953, 1451);
usleep(5000000);
toast("Rewards", 4);
usleep(1000000);
tap(1953, 1451);
usleep(3000000);
toast("Ending…");
usleep(5000000);


































