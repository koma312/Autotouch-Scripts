usleep(15e5);
tap(838, 1033);
usleep(2e6);
tap(1093, 1108);








