usleep(1500000);
tap(822, 1038);
usleep(1500000);
tap(1049, 955);
usleep(3200000);
tap(1023, 1072);
usleep(2000000);
tap(1359, 56);
usleep(1500000);
tap(1225, 1026);
usleep(1500000);












































