// --------------------------------------
// Information of recording
// Time: 2021-06-09 21:01:59
// Resolution: 1536, 2048
// Front most app: Clash of Clans
// Orientation of front most app: LandscapeRight
// --------------------------------------

const { touchDown, touchMove, touchUp, usleep, appActivate, keyDown, keyUp } = at

appActivate("com.supercell.magic");


touchDown(11, 588.88, 1382.79);
usleep(74973.04);
touchUp(11, 588.88, 1382.79);
usleep(891877.25);

toast("Golems", 2);

touchDown(7, 1175.72, 143.09);
usleep(115947.17);
touchUp(7, 1175.72, 143.09);
usleep(791901.92);

touchDown(13, 797.44, 134.91);
usleep(116697.71);
touchUp(13, 797.44, 134.91);
usleep(1091194.71);

touchDown(4, 400.75, 1375.62);
usleep(91602.79);
touchUp(4, 400.75, 1375.62);
usleep(717270.33);

touchDown(5, 1081.69, 85.71);
usleep(99249.96);
touchUp(5, 1081.69, 85.71);
usleep(658632.71);

touchDown(9, 889.47, 61.12);
usleep(91585.54);
touchUp(9, 889.47, 61.12);
usleep(833839.58);

touchDown(6, 190.16, 1438.10);
usleep(82639.38);
touchUp(6, 190.16, 1438.10);
usleep(433541.54);

touchDown(5, 1121.53, 62.16);
usleep(99648.25);
touchUp(5, 1121.53, 62.16);
usleep(441839.29);

touchDown(9, 917.06, 77.53);
usleep(49866.75);
touchUp(9, 917.06, 77.53);
usleep(1750224.17);

touchDown(15, 749.41, 1416.59);
usleep(99953.92);
touchUp(15, 749.41, 1416.59);
usleep(1141615.62);

touchDown(10, 1052.03, 41.67);
usleep(2182598.79);
touchUp(10, 1052.03, 41.67);
usleep(809030.92);

touchDown(10, 1030.56, 39.61);
usleep(99979.79);
touchUp(10, 1030.56, 39.61);
usleep(108394.54);

touchDown(10, 1026.47, 44.74);
usleep(66380.96);
touchUp(10, 1026.47, 44.74);
usleep(66894.38);

touchDown(10, 1030.56, 35.51);
usleep(57981.42);
touchUp(10, 1030.56, 35.51);
usleep(75290.58);

touchDown(10, 1029.53, 46.78);
usleep(66407.96);
touchUp(10, 1029.53, 46.78);
usleep(50086.46);

touchDown(10, 1029.53, 46.78);
usleep(158189.67);
touchUp(10, 1029.53, 46.78);
usleep(75540.17);

touchDown(10, 1028.50, 48.84);
usleep(57627.25);
touchUp(10, 1028.50, 48.84);
usleep(41532.54);

touchDown(10, 1028.50, 48.84);
usleep(66839.04);
touchUp(10, 1028.50, 48.84);
usleep(58267.12);

touchDown(10, 1023.41, 46.78);
usleep(41555.62);
touchUp(10, 1023.41, 46.78);
usleep(58348.08);

touchDown(10, 1024.41, 47.81);
usleep(74843.04);
touchUp(10, 1024.41, 47.81);
usleep(25343.62);

touchDown(10, 1024.41, 47.81);
usleep(83523.04);
touchUp(10, 1024.41, 47.81);
usleep(33260.96);

touchDown(10, 1024.41, 47.81);
usleep(58364.21);
touchUp(10, 1024.41, 47.81);
usleep(175523.38);

touchDown(10, 1012.16, 52.95);
usleep(57607.58);
touchUp(10, 1012.16, 52.95);
usleep(42163.67);

touchDown(10, 1012.16, 52.95);
usleep(74388.62);
touchUp(10, 1012.16, 52.95);
usleep(41725.21);

touchDown(10, 1012.16, 52.95);
usleep(66662.04);
touchUp(10, 1012.16, 52.95);
usleep(58687.04);

touchDown(10, 1013.19, 46.78);
usleep(49486.62);
touchUp(10, 1013.19, 46.78);
usleep(41902.12);

touchDown(10, 1013.19, 46.78);
usleep(75144.50);
touchUp(10, 1013.19, 46.78);
usleep(41382.42);

touchDown(10, 1013.19, 46.78);
usleep(66742.46);
touchUp(10, 1013.19, 46.78);
usleep(50179.00);

touchDown(10, 1015.22, 62.16);
usleep(58263.46);
touchUp(10, 1015.22, 62.16);
usleep(899973.29);

touchDown(17, 1477.34, 1422.75);
usleep(66530.71);
touchUp(17, 1477.34, 1422.75);
usleep(808667.21);

touchDown(14, 1097.00, 336.73);
usleep(82929.54);
touchUp(14, 1097.00, 336.73);
usleep(1366605.17);

touchDown(2, 936.50, 377.72);
usleep(66676.42);
touchUp(2, 936.50, 377.72);
usleep(791814.67);

touchDown(3, 1631.72, 1388.93);
usleep(58313.46);
touchUp(3, 1631.72, 1388.93);
usleep(433172.33);

touchDown(16, 1163.47, 344.93);
usleep(91984.79);
touchUp(16, 1163.47, 344.93);
usleep(757871.58);

touchDown(2, 924.22, 339.80);
usleep(83479.12);
touchUp(2, 924.22, 339.80);
usleep(1849758.42);

touchDown(1, 1837.22, 1393.03);
usleep(58134.83);
touchUp(1, 1837.22, 1393.03);
usleep(700482.96);

touchDown(8, 1018.28, 495.54);
usleep(82837.00);
touchUp(8, 1018.28, 495.54);
usleep(91853.62);

touchDown(8, 1014.19, 505.78);
usleep(74824.92);
touchUp(8, 1014.19, 505.78);
usleep(50370.96);

touchDown(8, 1005.00, 513.98);
usleep(66287.00);
touchUp(8, 1005.00, 513.98);
usleep(524867.17);

touchDown(8, 1046.91, 523.20);
usleep(50098.71);
touchUp(8, 1046.91, 523.20);
usleep(150390.92);

touchDown(8, 1032.59, 509.88);
usleep(24674.58);
touchUp(8, 1032.59, 509.88);
usleep(58258.62);

touchDown(8, 1023.41, 499.64);
usleep(50307.25);
touchUp(8, 1023.41, 499.64);
usleep(74972.54);

touchDown(8, 1025.44, 516.02);
usleep(24891.79);
touchUp(8, 1025.44, 516.02);
usleep(666651.29);

touchDown(12, 931.38, 1428.89);
usleep(108568.46);
touchUp(12, 931.38, 1428.89);
usleep(724636.33);

touchDown(11, 1162.44, 208.66);
usleep(124971.50);
touchUp(11, 1162.44, 208.66);
usleep(1341725.00);

touchDown(7, 1203.34, 159.49);
usleep(91547.88);
touchUp(7, 1203.34, 159.49);
usleep(708219.38);

touchDown(13, 1137.91, 1401.23);
usleep(66705.12);
touchUp(13, 1137.91, 1401.23);
usleep(675344.71);

touchDown(4, 842.44, 115.43);
usleep(83153.88);
touchUp(4, 842.44, 115.43);
usleep(724600.17);

touchDown(6, 1279.00, 1353.07);
usleep(83212.92);
touchUp(6, 1279.00, 1353.07);
usleep(383503.79);

touchDown(4, 824.03, 139.01);
usleep(108764.79);
touchUp(4, 824.03, 139.01);
usleep(29864148.33);

touchDown(12, 976.38, 1408.41);
usleep(66413.33);
touchUp(12, 976.38, 1408.41);
usleep(9799691.46);

touchDown(13, 1100.06, 1389.96);
usleep(41516.96);
touchUp(13, 1100.06, 1389.96);
usleep(2966729.29);

touchDown(6, 1273.88, 1388.93);
usleep(49459.46);
touchUp(6, 1273.88, 1388.93);

toast("End of Script", 6);