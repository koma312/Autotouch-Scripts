usleep(1000000);

tap(1126, 611);
usleep(3000000);

tap(1786, 1440);
usleep(3000000);

tap(1377, 1009);
usleep(9000000);

-- popup dismiss
tap(1026, 828);
usleep(2000000);

tap(1793, 1438);
usleep(3000000);

local victory = (findImage("images/victory.png", 1, 0.99, nil, false));

if (victory == 1) then

usleep(8000000);

tap(1026, 828);
usleep(1000000);
tap(1026, 828);
usleep(2000000);

-- tap(1114, 1276);
-- usleep(4000000);

-- Tap End Quest
tap(1937, 1075);
-- tap(1949, 1074);
usleep(2000000);

-- Tap Confirm End
tap(1263, 922);
usleep(6000000);
	
else

repeat
	usleep(2000000);
until (victory == 1);

-- then

-- usleep(1000000);

-- tap(1114, 1276);

-- tap anywhere on victory screen
tap(1567, 454);
usleep(15000000);

-- Tap End Quest
tap(1949, 1074);
usleep(5000000);

-- Tap Confirm End
tap(1263, 922);
usleep(6000000);

end









