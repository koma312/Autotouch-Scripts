function fight()

	fightColor = getColor(1082, 76);
     while (fightColor)==2302498 do 
		--tap(1654, 354);
		tap(1285, 1211);
		usleep(2e6);
	end

while (fightColor) ~= 2302498 do 
		tap(1285, 1211);
		usleep(2e6);
end
end

fight()

fight()

fight()












