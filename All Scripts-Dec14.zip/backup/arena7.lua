toast("Arena Start", 2);
usleep(1e6);

function tap(x, y)

    touchDown(2, x, y);
    usleep(1e4);
    touchUp(2, x, y);
end

function clearChamps()
	i1 = findImage("/images/help.png", 0, 0.8, null, true, 1);
	for i,v in pairs(i1) do
	tap(v[1], v[2])
	usleep(1e6)
	end
end

usleep(2e5);
clearChamps()

for i=3,1,-1 do
	usleep(1e6); 
	touchDown(0, 714, 719);
	usleep(5e4);
	touchMove(0, 439, 729);
	usleep(5e4);
	touchUp(0, 493, 729);
	usleep(1e6); 
	tap(271, 1430);
	usleep(1e6);
end
	usleep(7e6); 
	tap(1268, 1191);

for i=4,1,-1 do
	usleep(2e6);
	tap(1756, 1445);
end
	usleep(6e6);

repeat
	tap(1303, 1209);
	usleep(3e6);
until getColor(1732, 1444) == 16777215
	usleep(2e6); 
	tap(1403, 1456);
	usleep(6e6);

clearChamps()




