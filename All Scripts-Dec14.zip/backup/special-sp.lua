
usleep(2000000);

--tap node
tap(1496, 757);

usleep(12000000);

--start fight
tap(1786, 1421);
usleep(16000000);

--attack
tap(344, 1366);
usleep(8000000);

--tap
tap(1006, 1093);
usleep(3000000);

tap(1006, 1093);
usleep(1000000);

tap(1006, 1093);
usleep(10000000);

--tap exit
tap(1882, 1224);
usleep(2000000);
tap(1023, 905);
usleep(6000000);





























