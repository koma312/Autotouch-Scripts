usleep(1000000);

touchDown(5, 86.88, 825.45);
usleep(33821.58);
touchMove(5, 108.34, 828.52);
usleep(8009.46);
touchMove(5, 117.56, 828.52);
usleep(8466.67);
touchMove(5, 127.78, 828.52);
usleep(8035.21);
touchMove(5, 141.06, 828.52);
usleep(8458.21);
touchMove(5, 156.41, 829.55);
usleep(8674.88);
touchMove(5, 172.78, 829.55);
usleep(7896.71);
touchMove(5, 188.09, 829.55);
usleep(8383.17);
touchMove(5, 205.50, 830.55);
usleep(8370.25);
touchMove(5, 221.84, 830.55);
usleep(8308.88);
touchMove(5, 236.16, 830.55);
usleep(8574.67);
touchMove(5, 251.50, 830.55);
usleep(8324.25);
touchMove(5, 268.88, 830.55);
usleep(8148.75);
touchMove(5, 286.25, 830.55);
usleep(8391.25);
touchMove(5, 303.62, 830.55);
usleep(8258.17);
touchMove(5, 323.06, 830.55);
usleep(8681.29);
touchMove(5, 347.59, 830.55);
usleep(8003.62);
touchMove(5, 369.06, 830.55);
usleep(8380.08);
touchMove(5, 391.56, 829.55);
usleep(8225.83);
touchMove(5, 417.12, 828.52);
usleep(8525.75);
touchMove(5, 441.66, 827.48);
usleep(8415.67);
touchMove(5, 469.25, 826.45);
usleep(8147.29);
touchMove(5, 496.88, 826.45);
usleep(8303.50);
touchMove(5, 525.50, 826.45);
usleep(8268.46);
touchMove(5, 559.22, 826.45);
usleep(8405.29);
touchMove(5, 589.91, 826.45);
usleep(8471.71);
touchMove(5, 622.62, 826.45);
usleep(8078.00);
touchMove(5, 655.34, 826.45);
usleep(8523.96);
touchMove(5, 691.12, 826.45);
usleep(8254.38);
touchMove(5, 728.94, 826.45);
usleep(8647.71);
touchMove(5, 767.81, 826.45);
usleep(8103.08);
touchMove(5, 807.69, 826.45);
usleep(8148.88);
touchMove(5, 846.53, 826.45);
usleep(8468.12);
touchMove(5, 885.38, 826.45);
usleep(8325.38);
touchMove(5, 925.25, 826.45);
usleep(8312.67);
touchMove(5, 963.06, 826.45);
usleep(8513.67);
touchMove(5, 1010.09, 826.45);
usleep(8123.29);
touchMove(5, 1053.03, 827.48);
usleep(8473.33);
touchMove(5, 1091.91, 828.52);
usleep(8194.54);
touchMove(5, 1143.03, 830.55);
usleep(8479.04);
touchMove(5, 1192.09, 830.55);
usleep(8415.71);
touchMove(5, 1244.22, 831.59);
usleep(8396.88);
touchMove(5, 1298.41, 832.62);
usleep(8080.50);
touchMove(5, 1353.62, 832.62);
usleep(8441.33);
touchMove(5, 1407.81, 833.62);
usleep(8203.21);
touchMove(5, 1463.03, 836.72);
usleep(8675.42);
touchMove(5, 1520.28, 840.80);
usleep(7996.04);
touchMove(5, 1578.56, 847.97);
usleep(8447.04);
touchMove(5, 1631.72, 854.13);
usleep(8278.62);
touchMove(5, 1681.81, 860.27);
usleep(8299.92);
touchMove(5, 1729.88, 866.41);
usleep(8471.08);
touchMove(5, 1779.97, 871.55);
usleep(8283.42);
touchMove(5, 1831.09, 874.62);
usleep(8073.92);
touchMove(5, 1878.12, 876.66);
usleep(8575.08);
touchMove(5, 1923.09, 878.72);
usleep(8036.33);
touchUp(5, 1971.16, 882.82);

--

tap(1105, 922);

usleep(1000000);

tap(1901, 1370);

usleep(2000000);

tap(138, 645);

usleep(250000);

touchDown(0, 1026, 766);
usleep(100000);
touchMove(0, 1125, 675);
usleep(100000);
touchUp(0, 1125, 675);












































































