const { touchDown, touchMove, touchUp, usleep, appActivate, keyDown, keyUp, toast, getScreenResolution, } = at

usleep(5e5);

function tap(x, y) {
    touchDown(0, x, y)
    usleep(2e4)
    touchUp(0, x, y)
}

function screenSet(){
width, height = getScreenResolution();
X = 1536 / height
Y = 2048 / width	
SF800 = 800 / X
SFY800 = 830 / X  
SF200 = 200 / Y
SF1000 = 1000 / Y
SF1100 = 1100 / Y
SF1800 = 1800 / Y
usleep(50000);
touchDown(0, SFY800, SF800) touchDown(1, SF1000, SF800) usleep(30000)
touchMove(0, SF200, SF800) touchMove(1, SF1800, SF800) usleep(30000)
touchUp(0, SF200, SF800) touchUp(1, SF1800, SF800) usleep(700000)
touchDown(0, SF200, SF800) touchDown(1, SF1800, SF800) usleep(30000)
touchMove(0, SFY800, SF800) touchMove(1, SF1100, SF800) usleep(30000)
touchUp(0, SFY800, SF800) touchUp(1, SF1100, SF800) usleep(30000)
usleep(50000);
touchDown(0, 1000, 1000)
usleep(50000)
touchMove(0, 100, 100)
usleep(50000)
touchUp(0, 100, 100)
usleep(500000)
touchDown(0, 500, 500)
usleep(500000)
touchMove(0, 500, 540)
usleep(1000000)
touchUp(0, 500, 540)
usleep(500000)
}

screenSet()

//Select Slot One



//Place Slot One



//Select Slot Two



//Place Slot Two



//Select Slot Three



//Place Slot Three



//Select Slot Four



//Place Slot Four



//Select Slot Five



//Place Slot Five



//Select Slot Six



//Place Slot Six












































































