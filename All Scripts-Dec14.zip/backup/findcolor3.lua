myColor = rgbToInt(243,162,29); --This is a pixel color taken from your image
while true do
    local result = findColor(myColor, 0, nil);
    for i, v in pairs(result) do
        usleep(20000);
        tap(v[1],v[2]);
    end
end