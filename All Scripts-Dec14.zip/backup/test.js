
function myFunction() {
  at.toast('hello', 'center', 5);
}
myFunction();
