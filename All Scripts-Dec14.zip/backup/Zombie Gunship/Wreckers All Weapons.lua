--------------------------------------
-- Information of recording
-- Time: 2021-02-16 06:41:09
-- Resolution: 1536, 2048
-- Front most app: ZG Survival
-- Orientation of front most app: LandscapeRight;
--------------------------------------

appActivate("com.flaregames.zombiegunship");

usleep(1000000);

touchDown(10, 1901.62, 1361.27);
usleep(79627.42);
touchUp(10, 1901.62, 1361.27);
usleep(1066690.00);

touchDown(5, 123.69, 620.53);
usleep(91710.38);
touchUp(5, 123.69, 620.53);
usleep(38282010.75);

touchDown(11, 183.00, 1194.28);
usleep(87589.83);
touchUp(11, 183.00, 1194.28);
usleep(5253674.58);

touchDown(3, 206.50, 1371.52);
usleep(138646.58);
touchUp(3, 206.50, 1371.52);
usleep(9992339.62);

touchDown(11, 185.03, 1255.73);
usleep(125391.92);
touchUp(11, 185.03, 1255.73);
usleep(3404065.96);

touchDown(7, 205.50, 1026.26);
usleep(45962.17);
touchUp(7, 205.50, 1026.26);
usleep(25239551.12);

touchDown(7, 221.84, 1028.30);
usleep(79614.38);
touchUp(7, 221.84, 1028.30);
usleep(5956982.21);

touchDown(3, 238.19, 1401.23);
usleep(43257.25);
touchUp(3, 238.19, 1401.23);
usleep(5090510.58);

touchDown(8, 188.09, 1184.02);
usleep(59948.08);
touchUp(8, 188.09, 1184.02);
usleep(9467254.42);
touchUp(8, 219.81, 1187.11);
usleep(75132.75);

touchDown(8, 215.72, 1188.12);
usleep(66643.33);
touchUp(8, 215.72, 1188.12);
usleep(30381538.04);

touchDown(8, 193.22, 1190.18);
usleep(112720.17);
touchUp(8, 193.22, 1190.18);
usleep(2704143.00);

touchDown(3, 222.88, 1396.10);
usleep(79573.38);
touchUp(3, 222.88, 1396.10);
usleep(8104427.50);

touchDown(8, 177.88, 1205.53);
usleep(129525.12);
touchUp(8, 177.88, 1205.53);
usleep(5000296.08);

touchDown(7, 191.16, 992.44);
usleep(33496.29);
touchUp(7, 191.16, 992.44);
usleep(6757310.12);

touchDown(1, 168.69, 1363.31);
usleep(118286.25);
touchUp(1, 168.69, 1363.31);
usleep(6446026.17);

touchDown(8, 192.19, 1200.42);
usleep(95965.50);
touchUp(8, 192.19, 1200.42);
usleep(19825259.88);

touchDown(8, 158.47, 1171.73);
usleep(84992.58);
touchUp(8, 158.47, 1171.73);
usleep(7632277.75);

touchDown(1, 195.25, 1384.83);
usleep(134920.71);
touchUp(1, 195.25, 1384.83);
usleep(7415809.67);

touchDown(8, 197.31, 1232.18);
usleep(134690.33);
touchUp(8, 197.31, 1232.18);
usleep(1616713.29);

touchDown(1, 189.12, 1396.10);
usleep(91842.71);
touchUp(1, 189.12, 1396.10);
usleep(4700767.12);

touchDown(7, 216.72, 1007.81);
usleep(149854.08);
touchUp(7, 216.72, 1007.81);
usleep(3351651.88);

touchDown(8, 226.97, 1222.97);
usleep(123372.25);
touchUp(8, 226.97, 1222.97);
usleep(5362908.75);

touchDown(7, 209.56, 985.27);
usleep(87639.38);
touchUp(7, 209.56, 985.27);
usleep(458379.33);

touchDown(7, 218.78, 1036.50);
usleep(68033.88);
touchUp(7, 218.78, 1036.50);
usleep(606849.12);

touchDown(8, 217.75, 1160.46);
usleep(108535.00);
touchUp(8, 217.75, 1160.46);
usleep(1350230.79);

touchDown(1, 196.28, 1392.00);
usleep(50277.75);
touchUp(1, 196.28, 1392.00);
usleep(4010032.42);

touchDown(7, 215.72, 1000.64);
usleep(89832.21);
touchUp(7, 215.72, 1000.64);
usleep(766847.88);

touchDown(7, 225.94, 1003.71);
usleep(116885.17);
touchUp(7, 225.94, 1003.71);
usleep(1051146.83);

touchDown(7, 247.41, 992.44);
usleep(106894.79);
touchUp(7, 247.41, 992.44);
usleep(392302.08);

touchDown(7, 248.44, 989.37);
usleep(83158.79);
touchUp(7, 248.44, 989.37);
usleep(1099899.21);

touchDown(7, 248.44, 1006.78);
usleep(116960.04);
touchUp(7, 248.44, 1006.78);
usleep(516342.21);

touchDown(7, 266.84, 998.58);
usleep(108248.21);
touchUp(7, 266.84, 998.58);
usleep(2945969.08);

touchDown(1, 158.47, 1363.31);
usleep(46059.88);
touchUp(1, 158.47, 1363.31);
usleep(3973868.17);

touchDown(9, 1967.06, 103.15);
usleep(143078.42);
touchUp(9, 1967.06, 103.15);
usleep(1074957.67);

touchDown(6, 1255.47, 1185.05);
usleep(100158.88);
touchUp(6, 1255.47, 1185.05);
usleep(1925340.92);

touchDown(4, 148.22, 1428.89);
usleep(124682.25);
touchUp(4, 148.22, 1428.89);
