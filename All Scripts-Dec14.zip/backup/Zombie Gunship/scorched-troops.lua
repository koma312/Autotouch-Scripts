--------------------------------------
-- Information of recording
-- Time: 2021-03-09 22:49:00
-- Resolution: 1536, 2048
-- Front most app: ZG Survival
-- Orientation of front most app: LandscapeRight;
--------------------------------------

appActivate("com.flaregames.zombiegunship");
usleep(1000000);

touchDown(4, 1142.00, 722.98);
usleep(83209.50);
touchUp(4, 1142.00, 722.98);
usleep(683806.12);

touchDown(10, 1100.06, 970.92);
usleep(50222.42);
touchMove(10, 1121.53, 952.48);
usleep(7681.83);
touchMove(10, 1127.69, 946.34);
usleep(8541.50);
touchMove(10, 1134.84, 939.16);
usleep(8128.12);
touchMove(10, 1144.03, 931.99);
usleep(8501.58);
touchMove(10, 1153.25, 924.82);
usleep(8494.33);
touchMove(10, 1163.47, 916.62);
usleep(8196.71);
touchMove(10, 1174.72, 907.41);
usleep(8307.08);
touchMove(10, 1188.00, 896.13);
usleep(8387.83);
touchMove(10, 1199.25, 885.89);
usleep(8301.29);
touchMove(10, 1208.44, 876.66);
usleep(8591.33);
touchMove(10, 1219.69, 866.41);
usleep(7867.71);
touchMove(10, 1230.94, 855.14);
usleep(8593.17);
touchMove(10, 1242.19, 845.93);
usleep(8249.00);
touchMove(10, 1253.44, 836.72);
usleep(8372.62);
touchMove(10, 1264.69, 827.48);
usleep(8739.46);
touchMove(10, 1275.94, 819.28);
usleep(8160.50);
touchMove(10, 1288.19, 811.10);
usleep(7965.08);
touchMove(10, 1299.44, 802.90);
usleep(8544.38);
touchMove(10, 1312.72, 792.66);
usleep(8295.67);
touchMove(10, 1326.03, 782.41);
usleep(8829.96);
touchMove(10, 1339.31, 771.14);
usleep(11085.92);
touchMove(10, 1353.62, 757.83);
usleep(5108.33);
touchMove(10, 1367.94, 744.49);
usleep(8376.67);
touchMove(10, 1381.22, 733.22);
usleep(8269.62);
touchMove(10, 1395.53, 720.94);
usleep(8743.83);
touchMove(10, 1408.84, 709.66);
usleep(8092.83);
touchMove(10, 1422.12, 698.39);
usleep(8143.21);
touchMove(10, 1436.44, 687.12);
usleep(8439.17);
touchMove(10, 1449.72, 675.84);
usleep(8302.54);
touchMove(10, 1462.00, 665.60);
usleep(8562.54);
touchMove(10, 1476.31, 655.36);
usleep(8138.67);
touchMove(10, 1489.59, 644.09);
usleep(8366.46);
touchMove(10, 1507.00, 628.73);
usleep(8142.00);
touchMove(10, 1525.38, 614.39);
usleep(8599.00);
touchMove(10, 1546.88, 596.98);
usleep(8313.79);
touchMove(10, 1568.34, 579.54);
usleep(8385.29);
touchMove(10, 1597.97, 555.98);
usleep(8057.96);
touchMove(10, 1626.59, 532.43);
usleep(8402.88);
touchMove(10, 1655.22, 506.81);
usleep(8146.00);
touchUp(10, 1683.88, 477.09);
usleep(2017125.79);

touchDown(5, 670.69, 908.41);
usleep(82953.83);
touchUp(5, 670.69, 908.41);
usleep(1675567.38);

touchDown(6, 1900.59, 1365.38);
usleep(58164.79);
touchUp(6, 1900.59, 1365.38);
usleep(19516693.62);

touchDown(8, 124.72, 642.05);
usleep(101231.25);
touchUp(8, 124.72, 642.05);
usleep(127926241.96);

touchDown(11, 1960.94, 88.80);
usleep(76675.38);
touchUp(11, 1960.94, 88.80);
usleep(591557.12);

touchDown(1, 1328.06, 1154.32);
usleep(58441.33);
touchMove(1, 1310.69, 1162.50);
usleep(8202.54);
touchMove(1, 1309.66, 1162.50);
usleep(8324.29);
touchMove(1, 1308.66, 1161.49);
usleep(8325.54);
touchUp(1, 1302.50, 1148.16);
usleep(1992163.67);

touchDown(3, 151.31, 1444.27);
usleep(107706.58);
touchUp(3, 151.31, 1444.27);
