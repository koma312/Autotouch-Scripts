usleep(1000000);

tap(1914, 1358);

usleep(85000000);

toast("10 Seconds before loop");

usleep(10000000);

tap(155, 1483);


