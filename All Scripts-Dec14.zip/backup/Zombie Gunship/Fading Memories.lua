usleep(1000000);

--set camera

touchDown(0, 1370, 801);
usleep(20000);

touchMove(0, 1563, 956);
usleep(20000);

touchUp(0, 1292, 724);
usleep(20000);

--tap map

usleep(1000000);

tap(1346, 876);
usleep(20000);

--deploy

tap(1904, 1356);
usleep(2000000);
--

touchDown(0, 1021, 774);
usleep(20000);

touchMove(0, 1124, 821);
usleep(20000);

touchUp(0, 921, 681);
usleep(20000);

--
usleep(20000000);
--
function guns()

tap(300, 1400);
usleep(500000);

tap(300, 1200);
usleep(500000);

touchDown(1, 300, 1000);
usleep(150000);
touchUp(1, 300, 1000);

usleep(1000000);

end

--do guns

for i=25,1,-1 do guns()
end


--retry
toast("Ending");
usleep(8000000);
tap(153, 1440);

--end
















