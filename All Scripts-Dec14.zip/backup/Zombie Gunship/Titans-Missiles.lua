--appActivate("com.flaregames.zombiegunship");
usleep(1000000);
--
touchDown(0, 1111, 1391);
usleep(50000);
touchMove(0, 1111, 233);
usleep(50000);
touchUp(0, 1111, 233);
usleep(250000);
tap(1493, 518);
usleep(250000);
tap(1902, 1360);
usleep(250000);
tap(143, 646);
usleep(250000);
--
touchDown(0, 1025, 764);
usleep(50000);
touchMove(0, 1135, 640);
usleep(50000);
touchUp(0, 1089, 604);
usleep(250000);
--
--toast("30 seconds");
usleep(6000000);
toast("20 seconds");
usleep(5000000);
toast("15 seconds");
usleep(5000000);
toast("10 seconds");
usleep(5000000);
toast("5 seconds");
usleep(4000000);
toast("Sending");
usleep(1000000);
--
function guns()

	tap(250, 1000);
	usleep(5000000);

	tap(250, 1200);
	usleep(5000000);

	tap(250, 1400);
	usleep(5000000);
	
end
--
for i=11,1,-1 do guns()
end
--
usleep(500000);
tap(1965, 82);
usleep(500000);
tap(1016, 1197);
usleep(1000000);
tap(156, 1441);
usleep(2000000);
