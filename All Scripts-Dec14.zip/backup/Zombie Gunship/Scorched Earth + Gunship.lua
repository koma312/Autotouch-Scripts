--------------------------------------
-- Mission = Scorched Earth (Hard)
-- Weapon 01 = anything
-- Weapon 02 = Rocket68
-- Weapon 03 = hCan105
-- 
-- 
--------------------------------------

toast("Begin Mission");
usleep(500000);

touchDown(0, 1094, 819);
usleep(50000);

touchMove(0, 610, 781);
usleep(50000);

touchUp(0, 610, 781);
usleep(250000);

--Deploy

usleep(500000);
tap(498, 673);
usleep(500000);
tap(1902, 1357);
usleep(500000);

--Position Crosshair

usleep(250000);

touchDown(0, 1023, 762);
usleep(50000);

touchMove(0, 730, 1036);
usleep(250000);

touchUp(0, 657, 1054);
usleep(1000000);

-- touchMove(0, 730, 1036); ON FENCE RIGHT ABOVE TROOP EXIT POSITION
-- touchMove(0, 657, 1054); MIDDLE OF MAP, CROSSHAIRS ON SMALL BUNKER
-- touchMove(0, 781, 1002); CORNER OF BUILDING CLOSE TO DOOR

function bigCan()

	tap(250, 1000);
	--usleep(2000);
	
end

function rock()

	tap(250, 1200);
	--usleep(2000);
	
end

-- Waiting for Zombies

toast("Waiting for Zombies");
usleep(2000000);

--bigCan()

usleep(20000000);

-- Begin Firing Sequence

rock()

toast("18 Seconds");
--usleep(21000000);
usleep(18000000);

rock()

toast("24 Seconds");

usleep(24000000);
--usleep(22000000);

bigCan()

toast("12 Seconds");

--usleep(2000000);
usleep(12000000);

rock()

toast("Ending in (n) Seconds");

usleep(1000000);

bigCan()

usleep(2000000);
toast("End in 10 Seconds", 10);

usleep(10000000);

--End of Mission

tap(156, 1441);
usleep(2500000);

toast("End of Script");



























































