--appActivate("com.flaregames.zombiegunship");
usleep(1000000);
--
touchDown(0, 1111, 1391);
usleep(50000);
touchMove(0, 1111, 233);
usleep(50000);
touchUp(0, 1111, 233);
usleep(250000);
tap(1493, 518);
usleep(250000);
tap(1902, 1360);
usleep(250000);
tap(143, 646);
usleep(250000);
--
touchDown(0, 1025, 764);
usleep(50000);

touchMove(0, 1032, 734);
--touchMove(0, 1235, 550);

usleep(50000);
touchUp(0, 1089, 604);
usleep(250000);
--

toast("Weapons in 60 Seconds",10);
usleep(10000000);
toast("50 seconds",10);
usleep(10000000);
toast("40 seconds",10);
usleep(10000000);
toast("30 seconds",10);
usleep(10000000);
toast("20 seconds",5);
usleep(5000000);
toast("15 seconds",5);
usleep(5000000);
toast("10 seconds",5);
usleep(5000000);
toast("5 seconds",4);
usleep(4000000);
toast("Sending",1);
usleep(1000000);

--

function guns()

tap(250, 1400);
toast("Rocket One",3);
usleep(3000000);

tap(250, 1200);
toast("Rocket Two",4);
usleep(4200000);

tap(250, 1000);
toast("Rocket Three",3);
usleep(4200000);
--usleep(3200000);

end

--

function guns2()

usleep(1000000);

toast("Sending First Rocket");
usleep(1000000);
tap(250, 1200);
usleep(1000000);
toast("Sending First Rocket - 3",1);
usleep(1000000);

toast("Sending First Rocket - 2",1);
usleep(1000000);

toast("Sending First Rocket - 1",1);
usleep(1000000);

--

toast("Sending Second Rocket");
usleep(1000000);

tap(250, 1000);
usleep(1000000);
toast("Sending Second Rocket - 3",1);
usleep(1000000);

toast("Sending Second Rocket - 2",1);
usleep(1000000);

toast("Sending Second Rocket - 1",1);
usleep(1000000);

--

toast("Sending Third Rocket");
usleep(1000000);
tap(250, 1400);
usleep(1000000);
toast("Sending Third Rocket - 3",1);
usleep(1000000);

toast("Sending Third Rocket - 2",1);
usleep(1000000);

toast("Sending Third Rocket - 1",1);
usleep(1000000);

--

toast("Cooling Down - 5",1);
usleep(1000000);

toast("Cooling Down - 4",1);
usleep(1000000);

toast("Cooling Down - 3",1);
usleep(1000000);

toast("Cooling Down - 2",1);
usleep(1000000);

toast("Cooling Down - 1",1);
usleep(1000000);

end

--

for i=5,1,-1 do guns()
end

--Abort Mission

usleep(500000);
tap(1965, 82);
usleep(500000);
tap(1016, 1197);
usleep(1000000);
tap(156, 1441);
usleep(2000000);
















