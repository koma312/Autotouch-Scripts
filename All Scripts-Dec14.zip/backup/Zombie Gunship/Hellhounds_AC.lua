usleep(1000000);

touchDown(0, 1111, 1391);
usleep(50000);
touchMove(0, 1111, 233);
usleep(50000);
touchUp(0, 1111, 233);
usleep(1000000);
tap(1493, 518);
usleep(1000000);
tap(1902, 1360);
usleep(500000);
tap(143, 646);
usleep(1000000);

--

touchDown(0, 1025, 764);
usleep(50000);
touchMove(0, 1135, 640);
usleep(50000);
touchUp(0, 1089, 604);
usleep(15000000);

-- GUNS

touchDown(0, 250, 1400);

usleep(3000000);

touchUp(0, 250, 1400);

usleep(1000000);

touchDown(0, 250, 1200);

usleep(2500000);

touchUp(0, 250, 1200);

usleep(1000000);

-- Guns Repeat

touchDown(0, 250, 1400);
usleep(3000000);
touchUp(0, 250, 1400);
usleep(1000000);
touchDown(0, 250, 1200);
usleep(2500000);
touchUp(0, 250, 1200);
usleep(1000000);
touchDown(0, 250, 1400);
usleep(3000000);
touchUp(0, 250, 1400);
usleep(1000000);
touchDown(0, 250, 1200);
usleep(2500000);
touchUp(0, 250, 1200);
usleep(1000000);

touchDown(0, 250, 1400);
usleep(3000000);
touchUp(0, 250, 1400);
usleep(1000000);
touchDown(0, 250, 1200);
usleep(2500000);
touchUp(0, 250, 1200);
usleep(1000000);
touchDown(0, 250, 1400);
usleep(3000000);
touchUp(0, 250, 1400);
usleep(1000000);
touchDown(0, 250, 1200);
usleep(2500000);
touchUp(0, 250, 1200);
usleep(1000000);

touchDown(0, 250, 1400);
usleep(3000000);
touchUp(0, 250, 1400);
usleep(1000000);
touchDown(0, 250, 1200);
usleep(2500000);
touchUp(0, 250, 1200);
usleep(1000000);
touchDown(0, 250, 1400);
usleep(3000000);
touchUp(0, 250, 1400);
usleep(1000000);
touchDown(0, 250, 1200);
usleep(2500000);
touchUp(0, 250, 1200);
usleep(1000000);

touchDown(0, 250, 1400);
usleep(3000000);
touchUp(0, 250, 1400);
usleep(1000000);
touchDown(0, 250, 1200);
usleep(2500000);
touchUp(0, 250, 1200);
usleep(1000000);
touchDown(0, 250, 1400);
usleep(3000000);
touchUp(0, 250, 1400);
usleep(1000000);
touchDown(0, 250, 1200);
usleep(2500000);
touchUp(0, 250, 1200);
usleep(1000000);

touchDown(0, 250, 1400);
usleep(3000000);
touchUp(0, 250, 1400);
usleep(1000000);
touchDown(0, 250, 1200);
usleep(2500000);
touchUp(0, 250, 1200);
usleep(1000000);
touchDown(0, 250, 1400);
usleep(3000000);
touchUp(0, 250, 1400);
usleep(1000000);
touchDown(0, 250, 1200);
usleep(2500000);
touchUp(0, 250, 1200);
usleep(1000000);

touchDown(0, 250, 1400);
usleep(3000000);
touchUp(0, 250, 1400);
usleep(1000000);
touchDown(0, 250, 1200);
usleep(2500000);
touchUp(0, 250, 1200);
usleep(1000000);
touchDown(0, 250, 1400);
usleep(3000000);
touchUp(0, 250, 1400);
usleep(1000000);
touchDown(0, 250, 1200);
usleep(2500000);
touchUp(0, 250, 1200);
usleep(1000000);

-- END GUNS

tap(1965, 82);
usleep(500000);
tap(1016, 1197);
usleep(2000000);
tap(156, 1441);
usleep(1000000);















































