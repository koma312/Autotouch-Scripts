--------------------------------------
-- Information of recording
-- Time: 2021-02-17 03:15:51
-- Resolution: 1536, 2048
-- Front most app: ZG Survival
-- Orientation of front most app: LandscapeRight;
--------------------------------------

appActivate("com.flaregames.zombiegunship");
usleep(200000);

touchDown(4, 1911.84, 1381.76);
usleep(108372.21);
touchUp(4, 1911.84, 1381.76);
usleep(1058361.00);

touchDown(1, 128.81, 674.84);
usleep(100181.67);
touchUp(1, 128.81, 674.84);
usleep(3079257.21);

touchDown(7, 260.69, 1211.70);
usleep(45990.75);
touchUp(7, 260.69, 1211.70);
usleep(616985.67);

touchDown(8, 230.03, 1396.10);
usleep(66407.83);
touchUp(8, 230.03, 1396.10);
usleep(725033.29);

touchDown(7, 215.72, 1222.97);
usleep(83348.67);
touchUp(7, 215.72, 1222.97);
usleep(692058.29);

touchDown(8, 205.50, 1385.86);
usleep(116356.21);
touchUp(8, 205.50, 1385.86);
usleep(558212.17);

touchDown(7, 222.88, 1205.53);
usleep(75476.88);
touchUp(7, 222.88, 1205.53);
usleep(583349.12);

touchDown(8, 211.62, 1389.96);
usleep(108004.71);
touchUp(8, 211.62, 1389.96);
usleep(599907.21);

touchDown(7, 195.25, 1258.83);
usleep(99915.50);
touchUp(7, 195.25, 1258.83);
usleep(525423.25);

touchDown(8, 215.72, 1381.76);
usleep(83307.50);
touchUp(8, 215.72, 1381.76);
usleep(641460.17);

touchDown(7, 209.56, 1242.42);
usleep(75518.38);
touchUp(7, 209.56, 1242.42);
usleep(616543.71);

touchDown(8, 178.91, 1428.89);
usleep(116588.83);
touchUp(8, 178.91, 1428.89);
usleep(533521.29);

touchDown(7, 193.22, 1221.94);
usleep(82977.50);
touchUp(7, 193.22, 1221.94);
usleep(525001.79);

touchDown(8, 215.72, 1386.89);
usleep(49950.58);
touchUp(8, 215.72, 1386.89);
usleep(558827.21);

touchDown(7, 177.88, 1229.11);
usleep(91296.04);
touchUp(7, 177.88, 1229.11);
usleep(466683.17);

touchDown(8, 191.16, 1406.34);
usleep(66859.33);
touchUp(8, 191.16, 1406.34);
usleep(416732.50);

touchDown(7, 194.25, 1241.39);
usleep(58346.08);
touchUp(7, 194.25, 1241.39);
usleep(400089.92);

touchDown(8, 192.19, 1400.20);
usleep(66679.50);
touchUp(8, 192.19, 1400.20);
usleep(524763.00);

touchDown(8, 194.25, 1396.10);
usleep(75249.00);
touchUp(8, 194.25, 1396.10);
usleep(500188.58);

touchDown(7, 263.75, 1236.28);
usleep(57968.62);
touchUp(7, 263.75, 1236.28);
usleep(733483.33);

touchDown(8, 247.41, 1411.48);
usleep(99845.62);
touchUp(8, 247.41, 1411.48);
usleep(733489.42);

touchDown(7, 238.19, 1233.21);
usleep(66838.25);
touchUp(7, 238.19, 1233.21);
usleep(683155.29);

touchDown(8, 230.03, 1401.23);
usleep(83320.00);
touchUp(8, 230.03, 1401.23);
usleep(626581.71);

touchDown(7, 233.09, 1220.91);
usleep(23447.38);
touchUp(7, 233.09, 1220.91);
usleep(516811.71);

touchDown(8, 238.19, 1412.51);
usleep(125186.50);
touchUp(8, 238.19, 1412.51);
usleep(608043.71);

touchDown(7, 216.72, 1230.14);
usleep(100110.17);
touchUp(7, 216.72, 1230.14);
usleep(483325.08);

touchDown(8, 217.75, 1410.45);
usleep(100017.54);
touchUp(8, 217.75, 1410.45);
usleep(633531.50);

touchDown(7, 222.88, 1227.05);
usleep(91856.08);
touchUp(7, 222.88, 1227.05);
usleep(491468.46);

touchDown(8, 215.72, 1424.79);
usleep(116710.12);
touchUp(8, 215.72, 1424.79);
usleep(583505.12);

touchDown(7, 216.72, 1246.52);
usleep(83114.21);
touchUp(7, 216.72, 1246.52);
usleep(625372.50);

touchDown(8, 253.53, 1402.24);
usleep(66749.75);
touchUp(8, 253.53, 1402.24);
usleep(533569.96);

touchDown(3, 236.16, 1184.02);
usleep(74454.67);
touchUp(3, 236.16, 1184.02);
usleep(516649.08);

touchDown(8, 237.19, 1414.55);
usleep(75764.50);
touchUp(8, 237.19, 1414.55);
usleep(549393.04);

touchDown(3, 225.94, 1227.05);
usleep(75001.21);
touchUp(3, 225.94, 1227.05);
usleep(525267.08);

touchDown(8, 248.44, 1414.55);
usleep(91477.04);
touchUp(8, 248.44, 1414.55);
usleep(599994.67);

touchDown(3, 220.81, 1225.01);
usleep(75272.21);
touchUp(3, 220.81, 1225.01);
usleep(533435.92);

touchDown(8, 235.12, 1408.41);
usleep(91135.00);
touchUp(8, 235.12, 1408.41);
usleep(533638.92);

touchDown(3, 233.09, 1199.39);
usleep(83261.00);
touchUp(3, 233.09, 1199.39);
usleep(541872.83);

touchDown(8, 241.28, 1408.41);
usleep(83141.50);
touchUp(8, 241.28, 1408.41);
usleep(567007.71);

touchDown(3, 224.91, 1228.08);
usleep(66552.88);
touchUp(3, 224.91, 1228.08);
usleep(533587.96);

touchDown(8, 232.06, 1417.62);
usleep(57993.54);
touchUp(8, 232.06, 1417.62);
usleep(475263.67);

touchDown(3, 226.97, 1207.59);
usleep(83280.79);
touchUp(3, 226.97, 1207.59);
usleep(508317.46);

touchDown(8, 236.16, 1426.85);
usleep(66672.75);
touchUp(8, 236.16, 1426.85);
usleep(466691.33);

touchDown(3, 225.94, 1225.01);
usleep(75160.33);
touchUp(3, 225.94, 1225.01);
usleep(366897.29);

touchDown(8, 229.00, 1410.45);
usleep(66366.00);
touchUp(8, 229.00, 1410.45);
usleep(491522.58);

touchDown(8, 229.00, 1379.72);
usleep(75280.79);
touchUp(8, 229.00, 1379.72);
usleep(608257.12);

touchDown(3, 216.72, 1201.45);
usleep(83229.00);
touchUp(3, 216.72, 1201.45);
usleep(408706.96);

touchDown(8, 229.00, 1409.41);
usleep(91271.21);
touchUp(8, 229.00, 1409.41);
usleep(458695.79);

touchDown(3, 221.84, 1223.98);
usleep(66964.67);
touchUp(3, 221.84, 1223.98);
usleep(466420.67);

touchDown(3, 226.97, 1228.08);
usleep(99816.25);
touchUp(3, 226.97, 1228.08);
usleep(534812.25);

touchDown(8, 239.22, 1440.16);
usleep(90190.04);
touchUp(8, 239.22, 1440.16);
usleep(775422.17);

touchDown(3, 222.88, 1229.11);
usleep(99912.50);
touchUp(3, 222.88, 1229.11);
usleep(750040.00);

touchDown(8, 232.06, 1405.34);
usleep(83345.96);
touchUp(8, 232.06, 1405.34);
usleep(600121.12);

touchDown(8, 226.97, 1406.34);
usleep(66840.58);
touchUp(8, 226.97, 1406.34);
usleep(466455.79);

touchDown(8, 224.91, 1397.13);
usleep(75080.96);
touchUp(8, 224.91, 1397.13);
usleep(375491.38);

touchDown(3, 218.78, 1200.42);
usleep(99409.04);
touchUp(3, 218.78, 1200.42);
usleep(528477.54);

touchDown(3, 231.03, 1236.28);
usleep(96402.58);
touchUp(3, 231.03, 1236.28);
usleep(366663.33);

touchDown(8, 220.81, 1430.93);
usleep(91718.79);
touchUp(8, 220.81, 1430.93);
usleep(141935.17);

touchDown(8, 223.88, 1436.06);
usleep(83335.50);
touchUp(8, 223.88, 1436.06);
usleep(341459.17);

touchDown(3, 222.88, 1256.77);
usleep(75141.50);
touchUp(3, 222.88, 1256.77);
usleep(666718.42);

touchDown(8, 219.81, 1418.65);
usleep(108441.96);
touchUp(8, 219.81, 1418.65);
usleep(958145.62);

touchDown(3, 226.97, 1242.42);
usleep(66489.38);
touchUp(3, 226.97, 1242.42);
usleep(608994.67);

touchDown(8, 216.72, 1418.65);
usleep(74641.08);
touchUp(8, 216.72, 1418.65);
usleep(549922.25);

touchDown(3, 212.66, 1231.15);
usleep(75454.58);
touchUp(3, 212.66, 1231.15);
usleep(941508.92);

touchDown(8, 206.50, 1411.48);
usleep(75105.29);
touchUp(8, 206.50, 1411.48);
usleep(433395.38);

touchDown(3, 205.50, 1241.39);
usleep(74696.00);
touchUp(3, 205.50, 1241.39);
usleep(458782.88);

touchDown(8, 215.72, 1410.45);
usleep(83120.42);
touchUp(8, 215.72, 1410.45);
usleep(341910.33);

touchDown(3, 216.72, 1222.97);
usleep(66353.46);
touchUp(3, 216.72, 1222.97);
usleep(358589.50);

touchDown(8, 213.66, 1404.30);
usleep(83349.50);
touchUp(8, 213.66, 1404.30);
usleep(333311.46);

touchDown(3, 214.69, 1236.28);
usleep(74933.42);
touchUp(3, 214.69, 1236.28);
usleep(383242.96);

touchDown(8, 216.72, 1415.58);
usleep(83309.12);
touchUp(8, 216.72, 1415.58);
usleep(325383.12);

touchDown(3, 225.94, 1217.84);
usleep(74943.25);
touchUp(3, 225.94, 1217.84);
usleep(316360.21);

touchDown(8, 220.81, 1386.89);
usleep(75204.38);
touchUp(8, 220.81, 1386.89);
usleep(275269.12);

touchDown(3, 223.88, 1233.21);
usleep(74776.58);
touchUp(3, 223.88, 1233.21);
usleep(308247.88);

touchDown(8, 211.62, 1396.10);
usleep(75424.71);
touchUp(8, 211.62, 1396.10);
usleep(274645.54);

touchDown(3, 211.62, 1225.01);
usleep(83216.00);
touchUp(3, 211.62, 1225.01);
usleep(291978.46);

touchDown(8, 217.75, 1392.00);
usleep(91681.33);
touchUp(8, 217.75, 1392.00);
usleep(258416.42);

touchDown(3, 224.91, 1225.01);
usleep(83219.04);
touchUp(3, 224.91, 1225.01);
usleep(325005.29);

touchDown(8, 217.75, 1408.41);
usleep(83373.04);
touchUp(8, 217.75, 1408.41);
usleep(299946.08);

touchDown(3, 221.84, 1221.94);
usleep(83167.96);
touchUp(3, 221.84, 1221.94);
usleep(275312.88);

touchDown(8, 221.84, 1403.27);
usleep(83474.67);
touchUp(8, 221.84, 1403.27);
usleep(249862.75);

touchDown(3, 211.62, 1213.73);
usleep(91592.29);
touchUp(3, 211.62, 1213.73);
usleep(258314.50);

touchDown(8, 232.06, 1389.96);
usleep(83529.25);
touchUp(8, 232.06, 1389.96);
usleep(224938.62);

touchDown(3, 218.78, 1193.25);
usleep(74936.08);
touchUp(3, 218.78, 1193.25);
usleep(291620.75);

touchDown(8, 236.16, 1389.96);
usleep(83426.62);
touchUp(8, 236.16, 1389.96);
usleep(325162.38);

touchDown(3, 226.97, 1210.66);
usleep(66578.46);
touchUp(3, 226.97, 1210.66);
usleep(258249.58);

touchDown(8, 229.00, 1417.62);
usleep(99900.42);
touchUp(8, 229.00, 1417.62);
usleep(217007.71);

touchDown(3, 225.94, 1221.94);
usleep(91750.54);
touchUp(3, 225.94, 1221.94);
usleep(333423.96);

touchDown(8, 214.69, 1438.10);
usleep(91268.71);
touchUp(8, 214.69, 1438.10);
usleep(458646.12);

touchDown(3, 226.97, 1237.31);
usleep(58083.46);
touchUp(3, 226.97, 1237.31);
usleep(291905.88);

touchDown(8, 232.06, 1382.79);
usleep(66641.96);
touchUp(8, 232.06, 1382.79);
usleep(308016.33);

touchDown(3, 230.03, 1215.80);
usleep(92012.54);
touchUp(3, 230.03, 1215.80);
usleep(233328.08);

touchDown(8, 223.88, 1393.03);
usleep(100113.62);
touchUp(8, 223.88, 1393.03);
usleep(274904.33);

touchDown(3, 243.31, 1213.73);
usleep(83221.00);
touchUp(3, 243.31, 1213.73);
usleep(241709.54);

touchDown(8, 244.34, 1385.86);
usleep(108354.12);
touchUp(8, 244.34, 1385.86);
usleep(241814.62);

touchDown(3, 248.44, 1217.84);
usleep(91743.71);
touchUp(3, 248.44, 1217.84);
usleep(266433.38);

touchDown(8, 250.47, 1405.34);
usleep(75276.04);
touchUp(8, 250.47, 1405.34);
usleep(224664.50);

touchDown(3, 244.34, 1235.25);
usleep(83271.58);
touchUp(3, 244.34, 1235.25);
usleep(166872.33);

touchDown(2, 235.12, 1039.57);
usleep(66570.62);
touchUp(2, 235.12, 1039.57);
usleep(299983.25);

touchDown(3, 252.50, 1264.97);
usleep(66763.75);
touchUp(3, 252.50, 1264.97);
usleep(283657.42);

touchDown(8, 230.03, 1420.69);
usleep(83131.42);
touchUp(8, 230.03, 1420.69);
usleep(275243.00);

touchDown(3, 246.38, 1201.45);
usleep(74693.92);
touchUp(3, 246.38, 1201.45);
usleep(283390.58);

touchDown(8, 236.16, 1412.51);
usleep(66640.08);
touchUp(8, 236.16, 1412.51);
usleep(258799.08);

touchDown(3, 245.34, 1210.66);
usleep(91273.42);
touchUp(3, 245.34, 1210.66);
usleep(300125.17);

touchDown(8, 223.88, 1413.52);
usleep(91699.83);
touchUp(8, 223.88, 1413.52);
usleep(216597.50);

touchDown(3, 225.94, 1208.62);
usleep(100045.17);
touchUp(3, 225.94, 1208.62);
usleep(283378.08);

touchDown(8, 229.00, 1398.16);
usleep(91475.12);
touchUp(8, 229.00, 1398.16);
usleep(233287.12);

touchDown(3, 217.75, 1222.97);
usleep(100027.58);
touchUp(3, 217.75, 1222.97);
usleep(267081.17);

touchDown(7, 231.03, 1287.52);
usleep(32992.33);
touchUp(7, 231.03, 1287.52);
usleep(316803.21);

touchDown(8, 251.50, 1446.30);
usleep(66786.33);
touchUp(8, 251.50, 1446.30);
usleep(291984.58);

touchDown(7, 222.88, 1268.04);
usleep(99795.25);
touchUp(7, 222.88, 1268.04);
usleep(224783.17);

touchDown(8, 214.69, 1406.34);
usleep(75240.50);
touchUp(8, 214.69, 1406.34);
usleep(258183.83);

touchDown(3, 220.81, 1210.66);
usleep(99920.46);
touchUp(3, 220.81, 1210.66);
usleep(199931.62);

touchDown(3, 222.88, 1221.94);
usleep(58715.71);
touchUp(3, 222.88, 1221.94);
usleep(191213.29);

touchDown(8, 238.19, 1409.41);
usleep(66772.71);
touchUp(8, 238.19, 1409.41);
usleep(108557.96);

touchDown(8, 235.12, 1401.23);
usleep(58198.17);
touchUp(8, 235.12, 1401.23);
usleep(233300.83);

touchDown(3, 229.00, 1245.49);
usleep(66755.21);
touchUp(3, 229.00, 1245.49);
usleep(100049.42);

touchDown(3, 219.81, 1225.01);
usleep(75370.83);
touchUp(3, 219.81, 1225.01);
usleep(199667.04);

touchDown(8, 222.88, 1395.07);
usleep(58280.71);
touchUp(8, 222.88, 1395.07);
usleep(108768.92);

touchDown(8, 233.09, 1412.51);
usleep(49778.83);
touchUp(8, 233.09, 1412.51);
usleep(233414.25);

touchDown(3, 234.12, 1229.11);
usleep(41468.04);
touchUp(3, 234.12, 1229.11);
usleep(108489.12);

touchDown(3, 226.97, 1223.98);
usleep(33239.00);
touchUp(3, 226.97, 1223.98);
usleep(300173.54);

touchDown(8, 231.03, 1409.41);
usleep(41389.88);
touchUp(8, 231.03, 1409.41);
usleep(108789.08);

touchDown(8, 220.81, 1403.27);
usleep(57904.21);
touchUp(8, 220.81, 1403.27);
usleep(249877.75);

touchDown(3, 227.97, 1217.84);
usleep(83487.96);
touchUp(3, 227.97, 1217.84);
usleep(66858.00);

touchDown(3, 220.81, 1215.80);
usleep(91636.92);
touchUp(3, 220.81, 1215.80);
usleep(408312.92);

touchDown(3, 224.91, 1230.14);
usleep(83534.33);
touchUp(3, 224.91, 1230.14);
usleep(249667.62);

touchDown(8, 237.19, 1431.96);
usleep(100035.71);
touchUp(8, 237.19, 1431.96);
usleep(300229.58);

touchDown(3, 225.94, 1205.53);
usleep(91733.08);
touchUp(3, 225.94, 1205.53);
usleep(349983.08);

touchDown(8, 233.09, 1417.62);
usleep(58418.62);
touchUp(8, 233.09, 1417.62);
usleep(208659.12);

touchDown(3, 231.03, 1202.46);
usleep(107652.79);
touchUp(3, 231.03, 1202.46);
usleep(350419.83);

touchDown(8, 230.03, 1429.92);
usleep(75006.88);
touchUp(8, 230.03, 1429.92);
usleep(234471.04);

touchDown(3, 236.16, 1183.01);
usleep(99102.75);
touchUp(3, 236.16, 1183.01);
usleep(257932.04);

touchDown(8, 225.94, 1407.38);
usleep(83462.50);
touchUp(8, 225.94, 1407.38);
usleep(316602.25);

touchDown(3, 225.94, 1177.88);
usleep(75061.25);
touchUp(3, 225.94, 1177.88);
usleep(850502.88);

touchDown(8, 240.25, 1423.76);
usleep(74407.96);
touchUp(8, 240.25, 1423.76);
usleep(158419.04);

touchDown(3, 247.41, 1221.94);
usleep(91640.00);
touchUp(3, 247.41, 1221.94);
usleep(316992.04);

touchDown(8, 241.28, 1407.38);
usleep(83098.17);
touchUp(8, 241.28, 1407.38);
usleep(216492.62);

touchDown(3, 216.72, 1186.08);
usleep(58670.00);
touchUp(3, 216.72, 1186.08);
usleep(258214.04);

touchDown(8, 236.16, 1395.07);
usleep(58483.33);
touchUp(8, 236.16, 1395.07);
usleep(174710.38);

touchDown(3, 231.03, 1183.01);
usleep(83414.88);
touchUp(3, 231.03, 1183.01);
usleep(250044.92);

touchDown(8, 242.28, 1408.41);
usleep(66937.67);
touchUp(8, 242.28, 1408.41);
usleep(166564.38);

touchDown(3, 234.12, 1214.77);
usleep(33277.50);
—(3, 231.03, 1195.29);
usleep(8749.50);
—(3, 231.03, 1190.18);
usleep(7842.75);
—(3, 230.03, 1187.11);
usleep(8606.58);
—(3, 227.97, 1186.08);
usleep(8064.58);
—(3, 226.97, 1185.05);
usleep(16798.79);
touchUp(3, 224.91, 1190.18);
usleep(232987.21);

touchDown(8, 230.03, 1418.65);
usleep(75296.58);
touchUp(8, 230.03, 1418.65);
usleep(150085.88);

touchDown(3, 224.91, 1215.80);
usleep(74850.62);
touchUp(3, 224.91, 1215.80);
usleep(225156.75);

touchDown(8, 231.03, 1394.06);
usleep(58157.75);
touchUp(8, 231.03, 1394.06);
usleep(183411.79);

touchDown(3, 235.12, 1191.19);
usleep(83144.00);
touchUp(3, 235.12, 1191.19);
usleep(216849.33);

touchDown(8, 236.16, 1406.34);
usleep(83378.75);
touchUp(8, 236.16, 1406.34);
usleep(158399.83);

touchDown(3, 229.00, 1193.25);
usleep(91506.79);
touchUp(3, 229.00, 1193.25);
usleep(208575.38);

touchDown(8, 234.12, 1395.07);
usleep(74995.46);
touchUp(8, 234.12, 1395.07);
usleep(158402.29);

touchDown(3, 250.47, 1202.46);
usleep(66837.62);
touchUp(3, 250.47, 1202.46);
usleep(199853.71);

touchDown(8, 241.28, 1389.96);
usleep(83261.79);
touchUp(8, 241.28, 1389.96);
usleep(167046.42);

touchDown(3, 233.09, 1155.33);
usleep(83352.33);
touchUp(3, 233.09, 1155.33);
usleep(183032.67);

touchDown(8, 245.34, 1338.73);
usleep(74902.33);
touchUp(8, 245.34, 1338.73);
usleep(166511.46);

touchDown(3, 257.62, 1198.36);
usleep(100091.50);
touchUp(3, 257.62, 1198.36);
usleep(175234.58);

touchDown(8, 256.59, 1386.89);
usleep(83386.12);
touchUp(8, 256.59, 1386.89);
usleep(175062.62);

touchDown(3, 275.00, 1223.98);
usleep(8191.08);
—(3, 266.84, 1205.53);
usleep(8237.12);
—(3, 265.81, 1190.18);
usleep(8535.92);
—(3, 265.81, 1185.05);
usleep(8182.83);
—(3, 265.81, 1184.02);
usleep(41840.08);
—(3, 265.81, 1187.11);
usleep(8413.04);
—(3, 265.81, 1190.18);
usleep(8279.29);
—(3, 265.81, 1195.29);
usleep(8115.62);
—(3, 266.84, 1199.39);
usleep(8543.04);
—(3, 268.88, 1203.49);
usleep(8087.25);
—(3, 275.00, 1206.56);
usleep(8835.88);
touchUp(3, 287.28, 1207.59);
usleep(941131.38);

touchDown(3, 234.12, 1186.08);
usleep(75276.12);
touchUp(3, 234.12, 1186.08);
usleep(141724.75);

touchDown(8, 262.75, 1352.04);
usleep(99681.17);
touchUp(8, 262.75, 1352.04);
usleep(208712.96);

touchDown(3, 250.47, 1197.35);
usleep(83187.96);
touchUp(3, 250.47, 1197.35);
usleep(191706.71);

touchDown(8, 233.09, 1343.86);
usleep(99863.25);
touchUp(8, 233.09, 1343.86);
usleep(133422.29);

touchDown(3, 231.03, 1189.15);
usleep(91818.04);
touchUp(3, 231.03, 1189.15);
usleep(175044.75);

touchDown(8, 250.47, 1344.87);
usleep(75078.92);
touchUp(8, 250.47, 1344.87);
usleep(401262.71);

touchDown(8, 248.44, 1427.86);
usleep(31917.04);
touchUp(8, 248.44, 1427.86);
usleep(183394.33);

touchDown(3, 248.44, 1214.77);
usleep(91665.96);
touchUp(3, 248.44, 1214.77);
usleep(208574.29);

touchDown(8, 231.03, 1421.72);
usleep(91165.00);
touchUp(8, 231.03, 1421.72);
usleep(175489.42);

touchDown(3, 235.12, 1210.66);
usleep(99729.25);
touchUp(3, 235.12, 1210.66);
usleep(458320.71);

touchDown(8, 231.03, 1398.16);
usleep(108524.50);
touchUp(8, 231.03, 1398.16);
usleep(341381.79);

touchDown(3, 241.28, 1213.73);
usleep(100446.54);
touchUp(3, 241.28, 1213.73);
usleep(341549.12);

touchDown(8, 230.03, 1389.96);
usleep(83330.67);
touchUp(8, 230.03, 1389.96);
usleep(349875.17);

touchDown(3, 217.75, 1201.45);
usleep(74990.79);
touchUp(3, 217.75, 1201.45);
usleep(341817.17);

touchDown(8, 209.56, 1436.06);
usleep(58254.42);
touchUp(8, 209.56, 1436.06);
usleep(383303.12);

touchDown(3, 235.12, 1192.22);
usleep(58454.42);
touchUp(3, 235.12, 1192.22);
usleep(484831.00);

touchDown(8, 198.31, 1436.06);
usleep(73327.33);
touchUp(8, 198.31, 1436.06);
usleep(416729.62);

touchDown(3, 224.91, 1229.11);
usleep(92026.96);
touchUp(3, 224.91, 1229.11);
usleep(366629.96);

touchDown(8, 204.47, 1451.44);
usleep(100074.25);
touchUp(8, 204.47, 1451.44);
usleep(341585.71);

touchDown(3, 225.94, 1222.97);
usleep(83420.75);
touchUp(3, 225.94, 1222.97);
usleep(375325.33);

touchDown(8, 200.38, 1458.61);
usleep(83237.38);
touchUp(8, 200.38, 1458.61);
usleep(357983.38);

touchDown(3, 230.03, 1196.32);
usleep(66595.96);
touchUp(3, 230.03, 1196.32);
usleep(316948.04);

touchDown(8, 226.97, 1417.62);
usleep(99664.62);
touchUp(8, 226.97, 1417.62);
usleep(233596.46);

touchDown(3, 246.38, 1201.45);
usleep(91815.00);
touchUp(3, 246.38, 1201.45);
usleep(283702.17);

touchDown(8, 243.31, 1409.41);
usleep(91091.33);
touchUp(8, 243.31, 1409.41);
usleep(200122.75);

touchDown(3, 239.22, 1201.45);
usleep(91817.46);
touchUp(3, 239.22, 1201.45);
usleep(183201.33);

touchDown(8, 224.91, 1387.90);
usleep(100438.58);
touchUp(8, 224.91, 1387.90);
usleep(141044.08);

touchDown(3, 235.12, 1208.62);
usleep(100101.79);
touchUp(3, 235.12, 1208.62);
usleep(125139.38);

touchDown(8, 251.50, 1354.10);
usleep(100118.29);
touchUp(8, 251.50, 1354.10);
usleep(158430.12);

touchDown(3, 257.62, 1181.98);
usleep(83236.33);
touchUp(3, 257.62, 1181.98);
usleep(266477.12);

touchDown(8, 276.03, 1396.10);
usleep(91955.83);
touchUp(8, 276.03, 1396.10);
usleep(141604.92);

touchDown(3, 271.94, 1222.97);
usleep(49750.08);
touchUp(3, 271.94, 1222.97);
usleep(208374.88);

touchDown(8, 268.88, 1381.76);
usleep(91644.92);
touchUp(8, 268.88, 1381.76);
usleep(192246.42);

touchDown(3, 258.66, 1180.95);
usleep(83326.42);
touchUp(3, 258.66, 1180.95);
usleep(174430.25);

touchDown(8, 270.91, 1323.35);
usleep(75542.29);
touchUp(8, 270.91, 1323.35);
usleep(216515.38);

touchDown(3, 271.94, 1158.42);
usleep(49822.38);
touchUp(3, 271.94, 1158.42);
usleep(224962.33);

touchDown(8, 290.34, 1394.06);
usleep(83356.50);
touchUp(8, 290.34, 1394.06);
usleep(199995.58);

touchDown(3, 262.75, 1191.19);
usleep(66668.08);
touchUp(3, 262.75, 1191.19);
usleep(166578.04);

touchDown(8, 257.62, 1397.13);
usleep(83350.54);
touchUp(8, 257.62, 1397.13);
usleep(191931.25);

touchDown(10, 234.12, 956.58);
usleep(74773.33);
touchUp(10, 234.12, 956.58);
usleep(333338.79);

touchDown(3, 274.00, 1215.80);
usleep(66733.46);
touchUp(3, 274.00, 1215.80);
usleep(449904.46);

touchDown(11, 248.44, 1446.30);
usleep(83472.96);
touchUp(11, 248.44, 1446.30);
usleep(183375.46);

touchDown(3, 262.75, 1213.73);
usleep(83279.92);
touchUp(3, 262.75, 1213.73);
usleep(191761.58);

touchDown(8, 244.34, 1352.04);
usleep(41766.58);
—(8, 251.50, 1374.59);
usleep(8480.79);
—(8, 251.50, 1377.66);
usleep(8081.04);
—(8, 251.50, 1381.76);
usleep(8388.67);
—(8, 251.50, 1384.83);
usleep(8604.75);
—(8, 251.50, 1388.93);
usleep(8091.50);
—(8, 251.50, 1392.00);
usleep(8321.96);
touchUp(8, 250.47, 1398.16);
usleep(191919.96);

touchDown(3, 239.22, 1221.94);
usleep(74697.75);
touchUp(3, 239.22, 1221.94);
usleep(233472.96);

touchDown(8, 255.59, 1400.20);
usleep(58228.21);
touchUp(8, 255.59, 1400.20);
usleep(141641.54);

touchDown(3, 259.66, 1229.11);
usleep(100019.83);
touchUp(3, 259.66, 1229.11);
usleep(166662.67);

touchDown(8, 243.31, 1395.07);
usleep(91607.25);
touchUp(8, 243.31, 1395.07);
usleep(150236.00);

touchDown(3, 243.31, 1216.80);
usleep(58100.58);
touchUp(3, 243.31, 1216.80);
usleep(250072.08);

touchDown(8, 239.22, 1363.31);
usleep(91950.79);
touchUp(8, 239.22, 1363.31);
usleep(166614.38);

touchDown(3, 252.50, 1208.62);
usleep(83259.12);
touchUp(3, 252.50, 1208.62);
usleep(250054.79);

touchDown(11, 242.28, 1432.99);
usleep(41539.96);
touchUp(11, 242.28, 1432.99);
usleep(199960.75);

touchDown(3, 258.66, 1239.35);
usleep(75161.29);
touchUp(3, 258.66, 1239.35);
usleep(233451.54);

touchDown(8, 245.34, 1387.90);
usleep(58134.62);
touchUp(8, 245.34, 1387.90);
usleep(183305.79);

touchDown(3, 246.38, 1187.11);
usleep(74955.71);
touchUp(3, 246.38, 1187.11);
usleep(183544.58);

touchDown(8, 248.44, 1404.30);
usleep(66676.04);
touchUp(8, 248.44, 1404.30);
usleep(233474.38);

touchDown(3, 244.34, 1198.36);
usleep(50040.21);
touchUp(3, 244.34, 1198.36);
usleep(208020.21);

touchDown(8, 239.22, 1386.89);
usleep(66968.58);
touchUp(8, 239.22, 1386.89);
usleep(199670.92);

touchDown(3, 244.34, 1206.56);
usleep(83423.08);
touchUp(3, 244.34, 1206.56);
usleep(208793.25);

touchDown(8, 265.81, 1393.03);
usleep(74523.54);
touchUp(8, 265.81, 1393.03);
usleep(175508.58);

touchDown(3, 262.75, 1169.67);
usleep(50091.96);
—(3, 267.84, 1183.01);
usleep(7973.50);
—(3, 267.84, 1189.15);
usleep(8457.12);
—(3, 267.84, 1193.25);
usleep(8139.75);
—(3, 268.88, 1194.28);
usleep(8357.58);
touchUp(3, 276.03, 1197.35);
usleep(258522.25);

touchDown(8, 253.53, 1397.13);
usleep(83275.08);
touchUp(8, 253.53, 1397.13);
usleep(516438.96);

touchDown(3, 239.22, 1215.80);
usleep(66726.75);
touchUp(3, 239.22, 1215.80);
usleep(233260.79);

touchDown(8, 217.75, 1419.68);
usleep(92238.00);
touchUp(8, 217.75, 1419.68);
usleep(174429.17);

touchDown(3, 240.25, 1221.94);
usleep(100104.62);
touchUp(3, 240.25, 1221.94);
usleep(225554.75);

touchDown(8, 233.09, 1398.16);
usleep(91167.04);
touchUp(8, 233.09, 1398.16);
usleep(133329.83);

touchDown(3, 247.41, 1191.19);
usleep(66930.54);
touchUp(3, 247.41, 1191.19);
usleep(175016.08);

touchDown(3, 231.03, 1186.08);
usleep(50039.00);
—(3, 226.97, 1199.39);
usleep(8201.25);
—(3, 224.91, 1209.63);
usleep(8515.54);
—(3, 221.84, 1221.94);
usleep(8329.71);
—(3, 218.78, 1233.21);
usleep(8297.38);
—(3, 217.75, 1245.49);
usleep(7972.62);
touchUp(3, 212.66, 1256.77);
usleep(299988.33);

touchDown(8, 244.34, 1414.55);
usleep(83507.33);
—(8, 245.34, 1400.20);
usleep(8682.96);
—(8, 245.34, 1398.16);
usleep(8204.92);
—(8, 245.34, 1397.13);
usleep(8416.54);
—(8, 244.34, 1397.13);
usleep(7943.92);
touchUp(8, 242.28, 1395.07);
usleep(216811.42);

touchDown(3, 245.34, 1213.73);
usleep(75224.04);
touchUp(3, 245.34, 1213.73);
usleep(216668.04);

touchDown(8, 247.41, 1341.80);
usleep(58145.25);
—(8, 246.38, 1364.34);
usleep(8397.92);
—(8, 246.38, 1367.41);
usleep(8257.42);
—(8, 246.38, 1371.52);
usleep(8310.33);
—(8, 247.41, 1371.52);
usleep(8611.54);
touchUp(8, 253.53, 1374.59);
usleep(224767.33);

touchDown(8, 256.59, 1366.38);
usleep(74875.92);
touchUp(8, 256.59, 1366.38);
usleep(158805.08);

touchDown(3, 251.50, 1165.59);
usleep(74600.04);
touchUp(3, 251.50, 1165.59);
usleep(142094.58);

touchDown(3, 261.72, 1205.53);
usleep(74787.96);
touchUp(3, 261.72, 1205.53);
usleep(225161.08);

touchDown(8, 262.75, 1396.10);
usleep(49885.17);
touchUp(8, 262.75, 1396.10);
usleep(100282.46);

touchDown(8, 258.66, 1398.16);
usleep(57756.00);
touchUp(8, 258.66, 1398.16);
usleep(83431.50);

touchDown(8, 262.75, 1383.82);
usleep(49953.17);
touchUp(8, 262.75, 1383.82);
usleep(186732.00);

touchDown(3, 247.41, 1190.18);
usleep(88417.17);
touchUp(3, 247.41, 1190.18);
usleep(50093.21);

touchDown(3, 238.19, 1184.02);
usleep(91454.33);
touchUp(3, 238.19, 1184.02);
usleep(208687.46);

touchDown(8, 282.16, 1379.72);
usleep(41427.79);
touchUp(8, 282.16, 1379.72);
usleep(75266.79);

touchDown(8, 269.91, 1388.93);
usleep(83255.33);
touchUp(8, 269.91, 1388.93);
usleep(74824.83);

touchDown(8, 272.97, 1386.89);
usleep(66847.79);
touchUp(8, 272.97, 1386.89);
usleep(458390.46);

touchDown(7, 253.53, 1283.41);
usleep(66743.33);
touchUp(7, 253.53, 1283.41);
usleep(974781.54);

touchDown(7, 261.72, 1290.59);
usleep(383443.29);
—(7, 247.41, 1290.59);
usleep(8424.33);
—(7, 246.38, 1290.59);
usleep(8197.42);
—(7, 244.34, 1290.59);
usleep(8847.17);
—(7, 242.28, 1290.59);
usleep(7799.50);
—(7, 240.25, 1290.59);
usleep(8576.04);
—(7, 239.22, 1290.59);
usleep(8159.67);
—(7, 238.19, 1290.59);
usleep(8422.54);
—(7, 237.19, 1290.59);
usleep(66814.79);
—(7, 236.16, 1290.59);
usleep(8098.83);
—(7, 235.12, 1290.59);
usleep(8530.58);
—(7, 234.12, 1290.59);
usleep(8462.38);
—(7, 233.09, 1290.59);
usleep(8147.04);
—(7, 231.03, 1290.59);
usleep(16769.83);
—(7, 229.00, 1290.59);
usleep(16866.54);
—(7, 227.97, 1290.59);
usleep(7875.54);
—(7, 226.97, 1290.59);
usleep(8554.33);
—(7, 225.94, 1290.59);
usleep(8068.83);
—(7, 224.91, 1290.59);
usleep(8611.46);
—(7, 222.88, 1290.59);
usleep(8300.58);
—(7, 221.84, 1290.59);
usleep(8400.04);
—(7, 220.81, 1290.59);
usleep(41408.79);
—(7, 219.81, 1289.55);
usleep(350045.08);
—(7, 220.81, 1289.55);
usleep(16958.29);
—(7, 221.84, 1289.55);
usleep(8095.29);
—(7, 222.88, 1289.55);
usleep(16750.46);
—(7, 223.88, 1289.55);
usleep(8180.42);
—(7, 224.91, 1289.55);
usleep(8685.83);
—(7, 225.94, 1289.55);
usleep(8182.96);
—(7, 226.97, 1289.55);
usleep(16524.67);
—(7, 227.97, 1289.55);
usleep(25243.38);
—(7, 229.00, 1289.55);
usleep(16528.62);
—(7, 230.03, 1289.55);
usleep(33540.50);
—(7, 231.03, 1289.55);
usleep(49972.00);
—(7, 232.06, 1289.55);
usleep(16837.62);
—(7, 233.09, 1289.55);
usleep(16424.67);
—(7, 234.12, 1289.55);
usleep(8108.00);
—(7, 235.12, 1289.55);
usleep(8538.17);
—(7, 236.16, 1289.55);
usleep(8302.21);
—(7, 237.19, 1289.55);
usleep(8390.04);
—(7, 238.19, 1289.55);
usleep(8029.75);
—(7, 239.22, 1289.55);
usleep(8620.17);
—(7, 240.25, 1289.55);
usleep(116677.71);
touchUp(7, 245.34, 1286.48);
usleep(483165.50);

touchDown(3, 226.97, 1226.04);
usleep(58269.58);
touchUp(3, 226.97, 1226.04);
usleep(200119.62);

touchDown(8, 234.12, 1378.69);
usleep(91861.00);
touchUp(8, 234.12, 1378.69);
usleep(166387.67);

touchDown(3, 251.50, 1196.32);
usleep(83634.17);
touchUp(3, 251.50, 1196.32);
usleep(183255.21);

touchDown(11, 233.09, 1444.27);
usleep(74866.83);
touchUp(11, 233.09, 1444.27);
usleep(149953.54);

touchDown(3, 244.34, 1245.49);
usleep(58628.00);
touchUp(3, 244.34, 1245.49);
usleep(157981.88);

touchDown(8, 257.62, 1366.38);
usleep(91966.62);
touchUp(8, 257.62, 1366.38);
usleep(58127.42);

touchDown(8, 237.19, 1387.90);
usleep(58674.42);
—(8, 246.38, 1377.66);
usleep(8070.38);
—(8, 246.38, 1371.52);
usleep(8786.08);
—(8, 246.38, 1362.30);
usleep(7794.12);
—(8, 247.41, 1353.07);
usleep(8266.04);
touchUp(8, 251.50, 1348.97);
usleep(124948.33);

touchDown(3, 237.19, 1230.14);
usleep(58521.25);
touchUp(3, 237.19, 1230.14);
usleep(241400.96);
touchUp(7, 237.19, 1292.62);
usleep(100180.42);

touchDown(3, 214.69, 1236.28);
usleep(83344.38);
touchUp(3, 214.69, 1236.28);
usleep(1492258.79);

touchDown(8, 261.72, 1379.72);
usleep(8071.17);

touchDown(9, 218.78, 1168.66);
usleep(50194.71);
—(9, 213.66, 1181.98);
usleep(8512.29);
—(9, 213.66, 1185.05);
usleep(7678.75);
—(9, 213.66, 1187.11);
usleep(8807.88);
—(9, 213.66, 1189.15);
usleep(7938.33);
—(9, 213.66, 1191.19);
usleep(8351.25);
—(9, 213.66, 1192.22);
usleep(8280.62);
—(9, 213.66, 1193.25);
usleep(8393.12);
touchUp(9, 210.59, 1197.35);
usleep(8406.62);
touchUp(8, 261.72, 1379.72);
usleep(399874.58);

touchDown(8, 244.34, 1381.76);
usleep(16959.83);

touchDown(9, 240.25, 1202.46);
usleep(82972.04);
touchUp(8, 244.34, 1381.76);
touchUp(9, 240.25, 1202.46);
usleep(425467.33);

touchDown(9, 263.75, 1189.15);
usleep(8356.46);

touchDown(8, 287.28, 1400.20);
usleep(91525.67);
touchUp(8, 287.28, 1400.20);
usleep(8510.25);
touchUp(9, 263.75, 1189.15);
usleep(308340.58);

touchDown(8, 267.84, 1390.99);
usleep(133355.62);
touchUp(8, 267.84, 1390.99);
usleep(283483.83);

touchDown(8, 266.84, 1388.93);

touchDown(9, 248.44, 1180.95);
usleep(150079.62);
touchUp(9, 248.44, 1180.95);
usleep(16539.88);
touchUp(8, 266.84, 1388.93);
usleep(341342.96);

touchDown(9, 264.78, 1215.80);
usleep(8743.67);

touchDown(8, 279.09, 1381.76);
—(9, 265.81, 1190.18);
usleep(11742.17);
—(9, 267.84, 1185.05);
usleep(56381.62);
—(9, 269.91, 1186.08);
usleep(31694.58);
—(9, 269.91, 1187.11);
usleep(8027.58);
—(9, 269.91, 1188.12);
usleep(8368.54);
touchUp(8, 279.09, 1381.76);
touchUp(9, 267.84, 1181.98);
usleep(267176.21);

touchDown(8, 266.84, 1371.52);
usleep(8170.42);

touchDown(9, 271.94, 1183.01);
usleep(108491.04);
touchUp(8, 266.84, 1371.52);
usleep(7826.75);
touchUp(9, 271.94, 1183.01);
usleep(283613.75);

touchDown(9, 248.44, 1173.77);
usleep(58353.46);
touchUp(9, 248.44, 1173.77);
usleep(41460.92);

touchDown(8, 287.28, 1376.65);
usleep(116646.58);
touchUp(8, 287.28, 1376.65);
usleep(41834.00);

touchDown(9, 255.59, 1158.42);
usleep(100101.50);
touchUp(9, 255.59, 1158.42);
usleep(124766.33);

touchDown(8, 282.16, 1389.96);
usleep(100397.42);
touchUp(8, 282.16, 1389.96);
usleep(8368.50);

touchDown(8, 274.00, 1203.49);

touchDown(9, 267.84, 1159.43);
usleep(8102.38);
touchUp(8, 270.91, 1199.39);
usleep(83395.79);

touchDown(11, 276.03, 1389.96);
usleep(8577.67);
touchUp(9, 267.84, 1159.43);
usleep(66603.92);

touchDown(9, 262.75, 1161.49);
usleep(16569.58);
touchUp(11, 276.03, 1389.96);
usleep(91578.00);
touchUp(9, 262.75, 1161.49);

touchDown(11, 278.06, 1388.93);
usleep(50056.46);
touchUp(11, 278.06, 1388.93);
usleep(24842.08);

touchDown(9, 274.00, 1147.15);
usleep(74935.08);
touchUp(9, 274.00, 1147.15);
usleep(8557.17);

touchDown(11, 295.47, 1379.72);
usleep(49992.12);
touchUp(11, 295.47, 1379.72);
usleep(50141.42);

touchDown(9, 295.47, 1140.98);
usleep(41556.71);
touchUp(9, 295.47, 1140.98);
usleep(24741.58);

touchDown(11, 304.66, 1379.72);
usleep(41493.04);
touchUp(11, 304.66, 1379.72);
usleep(92293.08);

touchDown(11, 307.72, 1376.65);
usleep(57882.38);
touchUp(11, 307.72, 1376.65);
usleep(49961.17);

touchDown(9, 290.34, 1150.22);
usleep(92019.83);

touchDown(11, 292.38, 1394.06);
usleep(8280.12);
touchUp(9, 290.34, 1150.22);
touchUp(11, 292.38, 1394.06);
usleep(99759.33);

touchDown(9, 283.19, 1162.50);
usleep(75483.88);
touchUp(9, 283.19, 1162.50);
usleep(41079.25);

touchDown(11, 279.09, 1374.59);
usleep(108610.04);
touchUp(11, 279.09, 1374.59);
usleep(41439.29);

touchDown(9, 283.19, 1144.08);
usleep(66994.21);

touchDown(11, 278.06, 1392.00);
usleep(8356.25);
touchUp(9, 283.19, 1144.08);
usleep(66569.54);
touchUp(11, 278.06, 1392.00);
usleep(16672.25);

touchDown(9, 266.84, 1159.43);
usleep(83684.25);
touchUp(9, 266.84, 1159.43);

touchDown(11, 286.25, 1383.82);
usleep(100366.38);

touchDown(9, 277.06, 1142.02);
usleep(24435.50);
touchUp(11, 286.25, 1383.82);
usleep(66323.42);
touchUp(9, 277.06, 1142.02);
usleep(42030.88);

touchDown(11, 282.16, 1375.62);
usleep(57956.21);
touchUp(11, 282.16, 1375.62);
usleep(16987.12);

touchDown(9, 274.00, 1134.84);
usleep(91893.71);
touchUp(9, 274.00, 1134.84);

touchDown(11, 278.06, 1376.65);
usleep(57766.42);
touchUp(11, 278.06, 1376.65);
usleep(25235.29);

touchDown(9, 278.06, 1139.98);
usleep(58508.50);

touchDown(11, 275.00, 1387.90);
usleep(8517.67);
touchUp(9, 278.06, 1139.98);
usleep(57666.33);
touchUp(11, 275.00, 1387.90);
usleep(42068.54);

touchDown(9, 259.66, 1137.91);
usleep(75285.33);

touchDown(11, 272.97, 1387.90);
usleep(8285.17);
touchUp(9, 259.66, 1137.91);
usleep(41034.38);
touchUp(11, 272.97, 1387.90);
usleep(25394.96);

touchDown(9, 275.00, 1135.88);
usleep(74819.17);
touchUp(9, 275.00, 1135.88);
usleep(8636.46);

touchDown(11, 269.91, 1392.00);
usleep(41153.00);
touchUp(11, 269.91, 1392.00);
usleep(25412.58);

touchDown(9, 268.88, 1133.81);
usleep(74772.25);
touchUp(9, 268.88, 1133.81);
usleep(75561.62);

touchDown(11, 264.78, 1372.55);
usleep(83418.33);
touchUp(11, 264.78, 1372.55);
usleep(116224.50);

touchDown(11, 280.12, 1379.72);
usleep(16793.96);

touchDown(9, 282.16, 1143.05);
usleep(8724.54);
touchUp(11, 280.12, 1379.72);
usleep(82949.46);
touchUp(9, 282.16, 1143.05);
usleep(8384.79);

touchDown(11, 280.12, 1380.73);
usleep(66463.29);
touchUp(11, 280.12, 1380.73);
usleep(24802.96);

touchDown(9, 293.41, 1142.02);
usleep(83413.58);
touchUp(9, 293.41, 1142.02);
usleep(566874.96);

touchDown(8, 272.97, 1226.04);
usleep(74941.54);
touchUp(8, 272.97, 1226.04);
usleep(58383.71);

touchDown(11, 292.38, 1395.07);
usleep(75201.25);
touchUp(11, 292.38, 1395.07);
usleep(258163.79);

touchDown(8, 285.22, 1181.98);
usleep(58424.54);
touchUp(8, 285.22, 1181.98);
usleep(25039.67);

touchDown(11, 264.78, 1406.34);
usleep(75147.25);
—(11, 265.81, 1406.34);
usleep(8070.25);
—(11, 267.84, 1406.34);
usleep(8136.58);
touchUp(11, 271.94, 1404.30);
usleep(166914.12);

touchDown(8, 277.06, 1168.66);
usleep(67033.12);
touchUp(8, 277.06, 1168.66);

touchDown(11, 285.22, 1415.58);
usleep(149481.96);
touchUp(11, 285.22, 1415.58);
usleep(167033.46);

touchDown(11, 275.00, 1393.03);
usleep(66454.25);
touchUp(11, 275.00, 1393.03);
usleep(33371.96);

touchDown(8, 271.94, 1142.02);
usleep(108113.67);
touchUp(8, 271.94, 1142.02);
usleep(25287.12);

touchDown(11, 281.16, 1397.13);
usleep(41422.58);
touchUp(11, 281.16, 1397.13);
usleep(49953.17);

touchDown(8, 288.31, 1131.77);
usleep(66535.92);
touchUp(8, 288.31, 1131.77);
usleep(8614.17);

touchDown(11, 282.16, 1380.73);
usleep(41733.58);
touchUp(11, 282.16, 1380.73);
usleep(75083.42);

touchDown(8, 269.91, 1145.09);
usleep(166700.83);
touchUp(8, 269.91, 1145.09);
usleep(16669.46);

touchDown(11, 279.09, 1388.93);
usleep(49790.79);
touchUp(11, 279.09, 1388.93);
usleep(50520.29);

touchDown(8, 272.97, 1137.91);
usleep(66229.88);
touchUp(8, 272.97, 1137.91);
usleep(17137.08);

touchDown(11, 254.56, 1395.07);
usleep(32942.12);
touchUp(11, 254.56, 1395.07);
usleep(74834.25);

touchDown(8, 279.09, 1150.22);
usleep(58683.38);
touchUp(8, 279.09, 1150.22);
usleep(16712.96);

touchDown(11, 265.81, 1397.13);
usleep(24582.21);
touchUp(11, 265.81, 1397.13);
usleep(75267.67);

touchDown(8, 282.16, 1152.26);
usleep(57915.58);
touchUp(8, 282.16, 1152.26);
usleep(108689.79);

touchDown(8, 286.25, 1143.05);
usleep(33634.58);
touchUp(8, 286.25, 1143.05);
usleep(8009.04);

touchDown(11, 278.06, 1392.00);
usleep(50077.83);
touchUp(11, 278.06, 1392.00);
usleep(99834.96);

touchDown(11, 286.25, 1386.89);
usleep(25539.00);

touchDown(8, 294.44, 1157.39);
touchUp(11, 286.25, 1386.89);
usleep(83091.75);
touchUp(8, 294.44, 1157.39);
usleep(33257.33);

touchDown(11, 268.88, 1382.79);
usleep(83355.38);
touchUp(11, 268.88, 1382.79);
usleep(16588.62);

touchDown(8, 284.22, 1145.09);
usleep(41323.08);
touchUp(8, 284.22, 1145.09);
usleep(33695.79);

touchDown(11, 262.75, 1382.79);
usleep(66311.71);
touchUp(11, 262.75, 1382.79);
usleep(76838.96);

touchDown(8, 293.41, 1142.02);
usleep(39809.33);
touchUp(8, 293.41, 1142.02);
usleep(17163.12);

touchDown(11, 261.72, 1407.38);
usleep(41925.62);
—(11, 263.75, 1407.38);
usleep(7582.50);
touchUp(11, 267.84, 1409.41);
usleep(58749.12);

touchDown(8, 289.31, 1143.05);
usleep(83206.75);
touchUp(8, 289.31, 1143.05);
usleep(91479.33);

touchDown(8, 304.66, 1149.19);
usleep(41824.46);
touchUp(8, 304.66, 1149.19);
usleep(24929.67);

touchDown(11, 282.16, 1397.13);
usleep(50030.00);
touchUp(11, 282.16, 1397.13);
usleep(125150.12);

touchDown(8, 261.72, 1147.15);
usleep(66646.17);
touchUp(8, 261.72, 1147.15);
usleep(66798.88);

touchDown(11, 260.69, 1388.93);
usleep(58078.42);
touchUp(11, 260.69, 1388.93);
usleep(66759.38);

touchDown(8, 288.31, 1140.98);
usleep(50174.75);
touchUp(8, 288.31, 1140.98);
usleep(16487.71);

touchDown(11, 279.09, 1398.16);
usleep(41726.12);
touchUp(11, 279.09, 1398.16);
usleep(83464.62);

touchDown(8, 278.06, 1144.08);
usleep(57936.17);
touchUp(8, 278.06, 1144.08);
usleep(108724.92);

touchDown(8, 254.56, 1132.80);
usleep(66752.29);
touchUp(8, 254.56, 1132.80);
usleep(99927.38);

touchDown(11, 277.06, 1384.83);
usleep(16483.12);
touchUp(11, 277.06, 1384.83);
usleep(2457333.75);

touchDown(3, 195.25, 1184.02);
usleep(76435.50);
touchUp(3, 195.25, 1184.02);
usleep(58116.38);

touchDown(6, 202.41, 1406.34);
usleep(108468.04);
touchUp(6, 202.41, 1406.34);
usleep(68193.50);

touchDown(3, 212.66, 1150.22);
usleep(81744.08);
touchUp(3, 212.66, 1150.22);
usleep(108422.62);

touchDown(3, 239.22, 1151.25);
usleep(58463.62);
touchUp(3, 239.22, 1151.25);
usleep(16715.83);

touchDown(6, 234.12, 1411.48);
usleep(16267.12);
touchUp(6, 234.12, 1411.48);
usleep(91665.50);

touchDown(3, 242.28, 1156.36);
usleep(42034.38);
touchUp(3, 242.28, 1156.36);
usleep(24789.58);

touchDown(6, 243.31, 1414.55);
usleep(33661.12);
touchUp(6, 243.31, 1414.55);
usleep(58269.83);

touchDown(3, 256.59, 1158.42);
usleep(49860.46);
touchUp(3, 256.59, 1158.42);
usleep(8127.58);

touchDown(6, 242.28, 1411.48);
usleep(16700.75);
touchUp(6, 242.28, 1411.48);
usleep(75436.83);

touchDown(3, 261.72, 1158.42);
usleep(57850.58);
touchUp(3, 261.72, 1158.42);
usleep(100000.38);

touchDown(3, 250.47, 1163.53);
usleep(66555.00);
touchUp(3, 250.47, 1163.53);
usleep(33465.50);

touchDown(6, 245.34, 1415.58);
usleep(133186.33);
touchUp(6, 245.34, 1415.58);
usleep(100118.29);

touchDown(3, 227.97, 1159.43);
usleep(149879.96);
touchUp(3, 227.97, 1159.43);
usleep(17014.12);

touchDown(6, 240.25, 1411.48);
usleep(66559.12);
touchUp(6, 240.25, 1411.48);
usleep(66837.75);

touchDown(3, 217.75, 1164.56);
usleep(91647.92);
touchUp(3, 217.75, 1164.56);
usleep(24800.79);

touchDown(6, 243.31, 1421.72);
usleep(66785.79);
touchUp(6, 243.31, 1421.72);
usleep(33190.29);

touchDown(3, 224.91, 1156.36);
usleep(75421.04);
touchUp(3, 224.91, 1156.36);
usleep(16781.12);

touchDown(6, 244.34, 1403.27);
usleep(57715.38);
touchUp(6, 245.34, 1400.20);
usleep(42008.75);

touchDown(3, 233.09, 1146.12);
usleep(74693.21);
touchUp(3, 233.09, 1146.12);
usleep(20447.50);

touchDown(6, 237.19, 1411.48);
usleep(56243.12);
touchUp(6, 237.19, 1411.48);
usleep(15597.67);

touchDown(3, 233.09, 1144.08);
usleep(91088.67);
touchUp(3, 233.09, 1144.08);
usleep(33731.04);

touchDown(6, 248.44, 1405.34);
usleep(83367.54);
touchUp(6, 248.44, 1405.34);
usleep(8258.96);

touchDown(3, 247.41, 1149.19);
usleep(108370.58);
touchUp(3, 247.41, 1149.19);

touchDown(6, 218.78, 1414.55);
usleep(41718.96);
—(6, 219.81, 1414.55);
usleep(8215.71);
—(6, 220.81, 1414.55);
usleep(8289.17);
touchUp(6, 231.03, 1414.55);
usleep(91492.50);

touchDown(3, 230.03, 1146.12);
usleep(50426.62);

touchDown(6, 218.78, 1431.96);
usleep(8358.42);
touchUp(3, 230.03, 1146.12);
touchUp(6, 218.78, 1431.96);
usleep(1683426.17);

touchDown(3, 255.59, 1203.49);
usleep(124709.42);
—(3, 252.50, 1195.29);
usleep(8921.04);
—(3, 252.50, 1192.22);

touchDown(6, 233.09, 1443.23);
usleep(8254.92);
—(3, 252.50, 1189.15);
usleep(8533.54);
—(3, 252.50, 1187.11);
usleep(7984.79);
—(3, 255.59, 1183.01);
usleep(8310.46);
touchUp(3, 259.66, 1178.91);
usleep(74630.67);
touchUp(6, 233.09, 1443.23);
usleep(33495.25);

touchDown(3, 235.12, 1159.43);
usleep(75073.75);
touchUp(3, 235.12, 1159.43);

touchDown(6, 240.25, 1422.75);
usleep(49959.62);
touchUp(6, 240.25, 1422.75);
usleep(58132.50);

touchDown(3, 245.34, 1144.08);
usleep(67081.38);
touchUp(3, 245.34, 1144.08);

touchDown(6, 252.50, 1397.13);
usleep(24726.42);
touchUp(6, 252.50, 1397.13);
usleep(58360.42);

touchDown(3, 231.03, 1150.22);
usleep(75137.42);
touchUp(3, 231.03, 1150.22);
usleep(33407.42);

touchDown(6, 266.84, 1387.90);
usleep(58211.88);
touchUp(6, 266.84, 1387.90);
usleep(25094.92);

touchDown(3, 265.81, 1145.09);
usleep(74598.00);
touchUp(3, 265.81, 1145.09);
usleep(42003.58);

touchDown(6, 241.28, 1384.83);
usleep(41348.67);
touchUp(6, 241.28, 1384.83);
usleep(108995.96);

touchDown(3, 262.75, 1149.19);
usleep(91311.58);
touchUp(3, 262.75, 1149.19);
usleep(8661.83);

touchDown(6, 237.19, 1404.30);
usleep(24911.08);
touchUp(6, 237.19, 1404.30);
usleep(83081.38);

touchDown(3, 256.59, 1155.33);
usleep(41951.96);
touchUp(3, 256.59, 1155.33);
touchUp(6, 267.84, 1399.17);
usleep(733077.92);

touchDown(3, 230.03, 1164.56);
usleep(33774.54);

touchDown(6, 234.12, 1413.52);
usleep(33333.83);
touchUp(6, 234.12, 1413.52);
usleep(107755.62);
touchUp(3, 230.03, 1164.56);
usleep(8428.42);

touchDown(6, 220.81, 1415.58);
usleep(66829.17);
touchUp(6, 220.81, 1415.58);
usleep(66632.38);

touchDown(3, 250.47, 1162.50);
usleep(49924.12);
touchUp(3, 250.47, 1162.50);
usleep(66641.62);
touchUp(6, 257.62, 1394.06);
usleep(24932.58);

touchDown(3, 238.19, 1160.46);
usleep(66494.75);
touchUp(3, 238.19, 1160.46);
usleep(25719.46);

touchDown(6, 248.44, 1413.52);
usleep(49730.38);
touchUp(6, 248.44, 1413.52);
usleep(16770.58);

touchDown(6, 248.44, 1413.52);
usleep(66395.38);
touchUp(6, 248.44, 1413.52);
usleep(108228.71);

touchDown(6, 260.69, 1396.10);
usleep(58611.21);
touchUp(6, 260.69, 1396.10);
usleep(66621.17);

touchDown(3, 235.12, 1154.32);
usleep(99945.38);
touchUp(3, 235.12, 1154.32);
usleep(24926.71);

touchDown(6, 236.16, 1418.65);
usleep(66634.42);
touchUp(6, 236.16, 1418.65);
usleep(50014.88);

touchDown(3, 244.34, 1146.12);
usleep(59031.25);
touchUp(3, 244.34, 1146.12);

touchDown(6, 258.66, 1395.07);
usleep(32997.12);
touchUp(6, 258.66, 1395.07);
usleep(74534.54);

touchDown(3, 247.41, 1148.16);
usleep(17178.92);

touchDown(6, 263.75, 1390.99);
usleep(42013.96);
touchUp(6, 263.75, 1390.99);
usleep(7447.79);
touchUp(3, 247.41, 1148.16);
usleep(116953.33);

touchDown(6, 262.75, 1389.96);
usleep(41937.71);
touchUp(6, 262.75, 1389.96);
usleep(91212.00);

touchDown(6, 248.44, 1376.65);
usleep(49953.04);
touchUp(6, 248.44, 1376.65);
usleep(126782.83);

touchDown(3, 260.69, 1175.84);
usleep(106457.92);
touchUp(3, 260.69, 1175.84);
usleep(16850.88);

touchDown(6, 263.75, 1403.27);
usleep(83274.42);
touchUp(6, 263.75, 1403.27);
usleep(8600.17);

touchDown(3, 234.12, 1171.73);
usleep(91975.29);

touchDown(6, 233.09, 1412.51);
usleep(8084.38);
touchUp(3, 234.12, 1171.73);
usleep(33618.12);
—(6, 234.12, 1412.51);
usleep(7824.62);
—(6, 238.19, 1412.51);
usleep(8194.29);
touchUp(6, 242.28, 1410.45);
usleep(41756.17);

touchDown(3, 232.06, 1164.56);
usleep(58524.71);
touchUp(3, 232.06, 1164.56);
usleep(141885.79);

touchDown(3, 258.66, 1168.66);

touchDown(6, 253.53, 1419.68);
usleep(16592.25);
touchUp(3, 258.66, 1168.66);
usleep(16326.29);
touchUp(6, 253.53, 1419.68);
usleep(558720.38);

touchDown(3, 226.97, 1187.11);
usleep(33555.67);

touchDown(6, 244.34, 1427.86);
usleep(33704.21);
touchUp(3, 226.97, 1187.11);
usleep(32587.83);
touchUp(6, 244.34, 1427.86);
usleep(50277.08);

touchDown(3, 222.88, 1146.12);
usleep(41768.79);
touchUp(3, 222.88, 1146.12);

touchDown(6, 243.31, 1418.65);
usleep(91049.92);
touchUp(6, 243.31, 1418.65);
usleep(41739.92);

touchDown(3, 202.41, 1152.26);
usleep(75381.50);
touchUp(3, 202.41, 1152.26);
usleep(91319.33);

touchDown(6, 230.03, 1404.30);
usleep(75200.83);
touchUp(6, 230.03, 1404.30);
usleep(1483485.83);

touchDown(3, 231.03, 1167.63);
usleep(25117.92);

touchDown(6, 222.88, 1421.72);
usleep(42075.42);
touchUp(6, 222.88, 1421.72);
usleep(7763.08);
touchUp(3, 231.03, 1167.63);
usleep(233194.42);

touchDown(6, 226.97, 1419.68);
usleep(100079.62);
touchUp(6, 226.97, 1419.68);
usleep(100162.42);

touchDown(3, 225.94, 1198.36);
usleep(83260.96);
touchUp(3, 225.94, 1198.36);
usleep(33328.67);

touchDown(6, 238.19, 1406.34);
usleep(83143.04);
touchUp(6, 238.19, 1406.34);
usleep(16947.96);

touchDown(3, 231.03, 1170.70);
usleep(91647.25);
touchUp(3, 231.03, 1170.70);
usleep(11528.54);

touchDown(6, 223.88, 1402.24);
usleep(56427.67);
touchUp(6, 223.88, 1402.24);
usleep(40182.29);

touchDown(3, 233.09, 1162.50);
usleep(75334.42);
touchUp(3, 233.09, 1162.50);
usleep(41420.75);

touchDown(6, 237.19, 1390.99);
usleep(25286.00);
touchUp(6, 237.19, 1390.99);
usleep(41500.00);

touchDown(6, 247.41, 1394.06);
usleep(91581.62);
touchUp(6, 247.41, 1394.06);
usleep(91542.83);

touchDown(3, 231.03, 1153.29);
usleep(100069.92);
touchUp(3, 231.03, 1153.29);
usleep(41878.00);

touchDown(6, 216.72, 1403.27);
usleep(91516.92);
touchUp(6, 216.72, 1403.27);
usleep(175073.92);

touchDown(3, 241.28, 1177.88);
usleep(34089.96);

touchDown(6, 230.03, 1421.72);
usleep(49509.38);
touchUp(6, 230.03, 1421.72);
usleep(33357.67);
touchUp(3, 241.28, 1177.88);
usleep(157951.00);

touchDown(6, 229.00, 1405.34);
usleep(66548.17);
touchUp(6, 229.00, 1405.34);
usleep(92066.50);

touchDown(3, 232.06, 1171.73);
usleep(83333.75);
touchUp(3, 232.06, 1171.73);
usleep(24809.46);

touchDown(6, 217.75, 1399.17);
usleep(49958.17);
touchUp(6, 217.75, 1399.17);
usleep(791993.75);

touchDown(6, 208.56, 1439.13);
usleep(58075.42);
touchUp(6, 208.56, 1439.13);
usleep(325309.96);

touchDown(3, 229.00, 1171.73);
usleep(66451.17);
touchUp(3, 229.00, 1171.73);
usleep(258284.71);

touchDown(11, 265.81, 1365.38);
usleep(66470.42);
touchUp(11, 265.81, 1365.38);
usleep(175346.67);

touchDown(3, 255.59, 1230.14);
usleep(50121.04);
—(3, 239.22, 1214.77);
usleep(8161.38);
—(3, 235.12, 1214.77);
usleep(8697.88);
—(3, 231.03, 1215.80);
usleep(7848.21);
touchUp(3, 225.94, 1220.91);
usleep(225183.92);

touchDown(6, 251.50, 1415.58);
usleep(91683.96);
touchUp(6, 251.50, 1415.58);
usleep(175320.88);

touchDown(3, 233.09, 1219.88);
usleep(74622.33);
touchUp(3, 233.09, 1219.88);
usleep(276409.58);

touchDown(6, 234.12, 1393.03);
usleep(40116.79);
touchUp(6, 234.12, 1393.03);
usleep(225567.33);

touchDown(3, 241.28, 1233.21);
usleep(74378.50);
touchUp(3, 241.28, 1233.21);
usleep(225279.04);

touchDown(6, 233.09, 1381.76);
usleep(91645.46);
touchUp(6, 233.09, 1381.76);
usleep(175156.83);

touchDown(3, 232.06, 1170.70);
usleep(74635.96);
touchUp(3, 232.06, 1170.70);
usleep(225426.04);

touchDown(6, 234.12, 1411.48);
usleep(99871.12);
touchUp(6, 234.12, 1411.48);
usleep(166812.12);

touchDown(6, 243.31, 1385.86);
usleep(58068.54);
touchUp(6, 243.31, 1385.86);
usleep(183601.62);

touchDown(3, 227.97, 1226.04);
usleep(66276.96);
touchUp(3, 227.97, 1226.04);
usleep(233466.33);

touchDown(3, 247.41, 1197.35);
usleep(25265.88);
touchUp(3, 247.41, 1197.35);
usleep(266765.33);

touchDown(6, 219.81, 1394.06);
usleep(83371.29);
touchUp(6, 219.81, 1394.06);
usleep(183187.42);

touchDown(6, 240.25, 1377.66);
usleep(66641.67);
touchUp(6, 240.25, 1377.66);
usleep(266872.88);

touchDown(3, 226.97, 1235.25);
usleep(16545.83);
touchUp(3, 226.97, 1235.25);
usleep(216787.79);

touchDown(3, 247.41, 1231.15);
usleep(49713.12);
touchUp(3, 247.41, 1231.15);
usleep(208361.67);

touchDown(3, 265.81, 1215.80);
usleep(41985.75);
touchUp(3, 265.81, 1215.80);
usleep(483208.67);

touchDown(3, 249.44, 1236.28);
usleep(50135.04);
touchUp(3, 249.44, 1236.28);
usleep(533219.12);

touchDown(3, 252.50, 1245.49);
usleep(50121.42);
touchUp(3, 252.50, 1245.49);
usleep(116537.42);

touchDown(3, 251.50, 1191.19);
usleep(66982.04);
touchUp(3, 251.50, 1191.19);
usleep(216346.92);

touchDown(11, 270.91, 1418.65);
usleep(33599.17);
touchUp(11, 270.91, 1418.65);
usleep(99952.83);

touchDown(11, 268.88, 1392.00);
usleep(50031.88);
touchUp(11, 268.88, 1392.00);
usleep(149997.71);

touchDown(3, 266.84, 1233.21);
usleep(57898.96);
touchUp(3, 266.84, 1233.21);
usleep(75417.00);

touchDown(3, 258.66, 1231.15);
usleep(91460.58);
touchUp(3, 258.66, 1231.15);
usleep(283301.71);

touchDown(11, 264.78, 1410.45);
usleep(66934.83);
touchUp(11, 264.78, 1410.45);
usleep(374969.96);

touchDown(3, 265.81, 1234.22);
usleep(141598.38);
—(3, 277.06, 1220.91);
usleep(8568.00);
—(3, 277.06, 1217.84);
usleep(8370.79);
—(3, 277.06, 1213.73);
usleep(8266.33);
—(3, 280.12, 1208.62);
usleep(7968.04);
touchUp(3, 291.38, 1200.42);
usleep(50031.33);

touchDown(11, 274.00, 1408.41);
usleep(125234.62);
touchUp(11, 274.00, 1408.41);
usleep(41652.67);

touchDown(3, 289.31, 1196.32);
usleep(92139.25);

touchDown(11, 267.84, 1411.48);
usleep(8291.08);
touchUp(3, 289.31, 1196.32);
usleep(116020.96);
touchUp(11, 267.84, 1411.48);
usleep(25623.54);

touchDown(3, 284.22, 1199.39);
usleep(91170.46);
touchUp(3, 284.22, 1199.39);
usleep(42050.88);

touchDown(11, 283.19, 1413.52);
usleep(24946.67);
touchUp(11, 283.19, 1413.52);
usleep(41641.62);

touchDown(3, 282.16, 1188.12);
usleep(83608.42);

touchDown(11, 274.00, 1402.24);
usleep(8092.88);
touchUp(3, 282.16, 1188.12);
usleep(66616.21);
touchUp(11, 274.00, 1402.24);
usleep(33012.92);

touchDown(3, 295.47, 1183.01);
usleep(75447.42);

touchDown(11, 286.25, 1394.06);
usleep(16811.00);
touchUp(3, 295.47, 1183.01);
usleep(41226.08);
touchUp(11, 286.25, 1394.06);
usleep(83590.29);

touchDown(3, 267.84, 1176.84);
usleep(66614.75);

touchDown(11, 274.00, 1409.41);
usleep(8527.25);
touchUp(3, 267.84, 1176.84);
usleep(41245.58);
touchUp(11, 274.00, 1409.41);
usleep(25094.67);

touchDown(3, 275.00, 1173.77);
usleep(99927.12);
touchUp(3, 275.00, 1173.77);
usleep(17099.21);

touchDown(11, 271.94, 1410.45);
usleep(66465.21);
touchUp(11, 271.94, 1410.45);
usleep(16594.54);

touchDown(3, 290.34, 1169.67);
usleep(75055.33);
touchUp(3, 290.34, 1169.67);
usleep(24825.71);

touchDown(11, 272.97, 1409.41);
usleep(75070.33);
touchUp(11, 272.97, 1409.41);
usleep(8458.25);

touchDown(3, 281.16, 1165.59);

touchDown(11, 281.16, 1210.66);
usleep(8233.29);
touchUp(11, 281.16, 1206.56);
usleep(66564.12);
touchUp(3, 281.16, 1165.59);
usleep(25405.38);

touchDown(6, 270.91, 1406.34);
usleep(57802.54);
touchUp(6, 270.91, 1406.34);
usleep(8653.67);

touchDown(3, 288.31, 1169.67);
usleep(83468.29);
touchUp(3, 288.31, 1169.67);
usleep(16485.54);

touchDown(6, 255.59, 1400.20);
usleep(74824.21);
touchUp(6, 255.59, 1400.20);
usleep(16709.58);

touchDown(3, 281.16, 1161.49);
usleep(58649.33);
touchUp(3, 281.16, 1161.49);
usleep(24698.50);

touchDown(6, 252.50, 1404.30);
usleep(58543.83);
touchUp(6, 252.50, 1404.30);
usleep(24570.62);

touchDown(3, 282.16, 1163.53);
usleep(75234.17);
touchUp(3, 282.16, 1163.53);
usleep(8256.17);

touchDown(6, 258.66, 1413.52);
usleep(58658.17);
touchUp(6, 258.66, 1413.52);
usleep(33287.25);

touchDown(3, 277.06, 1165.59);
usleep(99927.96);
touchUp(3, 277.06, 1165.59);
usleep(24725.96);
touchUp(6, 269.91, 1402.24);
usleep(50243.04);

touchDown(3, 269.91, 1166.60);
usleep(83515.83);
touchUp(3, 269.91, 1166.60);

touchDown(6, 247.41, 1414.55);
usleep(41774.04);
touchUp(6, 247.41, 1414.55);
usleep(66441.54);

touchDown(6, 262.75, 1401.23);
usleep(75104.00);
touchUp(6, 262.75, 1401.23);
usleep(8465.21);

touchDown(3, 262.75, 1169.67);
usleep(91228.88);
—(3, 263.75, 1169.67);
usleep(9060.12);
—(3, 276.03, 1168.66);

touchDown(6, 243.31, 1416.59);
usleep(7790.92);
touchUp(3, 280.12, 1164.56);
usleep(91948.33);
touchUp(6, 243.31, 1416.59);
usleep(7989.71);

touchDown(3, 272.97, 1174.80);
usleep(83390.00);
touchUp(3, 272.97, 1174.80);
usleep(8522.71);

touchDown(6, 242.28, 1429.92);
usleep(41298.21);
touchUp(6, 242.28, 1429.92);
usleep(58422.17);

touchDown(3, 262.75, 1170.70);
usleep(91689.42);
touchUp(3, 262.75, 1170.70);
usleep(91741.62);

touchDown(6, 246.38, 1429.92);
usleep(25157.50);

touchDown(3, 266.84, 1178.91);
usleep(25125.88);
touchUp(3, 266.84, 1178.91);
usleep(32915.04);
touchUp(6, 246.38, 1429.92);
usleep(133391.83);
touchUp(3, 276.03, 1174.80);
usleep(318032.42);

touchDown(6, 252.50, 1413.52);
usleep(32315.79);
touchUp(6, 252.50, 1413.52);
usleep(141194.29);

touchDown(3, 265.81, 1189.15);
usleep(58511.12);
touchUp(3, 265.81, 1189.15);
usleep(233641.12);

touchDown(6, 271.94, 1398.16);
usleep(99590.79);
touchUp(6, 271.94, 1398.16);
usleep(841833.79);

touchDown(3, 237.19, 1196.32);
usleep(66706.25);
touchUp(3, 237.19, 1196.32);
usleep(216569.58);

touchDown(6, 261.72, 1416.59);
usleep(42045.96);
—(6, 248.44, 1423.76);
usleep(8098.17);
—(6, 242.28, 1423.76);
usleep(8515.54);
—(6, 234.12, 1423.76);
usleep(8296.71);
—(6, 227.97, 1423.76);
usleep(8546.92);
touchUp(6, 218.78, 1418.65);
usleep(211680.75);

touchDown(3, 237.19, 1223.98);
usleep(56204.79);
touchUp(3, 237.19, 1223.98);
usleep(206676.21);

touchDown(6, 213.66, 1372.55);
usleep(75167.96);
touchUp(6, 213.66, 1372.55);
usleep(166675.71);

touchDown(3, 242.28, 1196.32);
usleep(58207.33);
touchUp(3, 242.28, 1196.32);
usleep(200049.33);

touchDown(6, 203.44, 1380.73);
usleep(75182.33);
touchUp(6, 203.44, 1380.73);
usleep(166702.38);

touchDown(3, 211.62, 1227.05);
usleep(83392.46);
touchUp(3, 211.62, 1227.05);
usleep(200095.54);

touchDown(6, 211.62, 1360.24);
usleep(83355.33);
touchUp(6, 211.62, 1360.24);
usleep(150002.79);

touchDown(8, 249.44, 1165.59);
usleep(50140.88);
touchUp(8, 249.44, 1165.59);
usleep(208246.12);

touchDown(6, 221.84, 1358.20);
usleep(74726.71);
touchUp(6, 221.84, 1358.20);
usleep(178405.96);

touchDown(3, 230.03, 1212.70);
usleep(72024.62);
touchUp(3, 230.03, 1212.70);
usleep(191298.62);

touchDown(6, 230.03, 1363.31);
usleep(75143.08);
touchUp(6, 230.03, 1363.31);
usleep(141476.54);

touchDown(3, 235.12, 1192.22);
usleep(66649.04);
touchUp(3, 235.12, 1192.22);
usleep(216755.12);

touchDown(6, 241.28, 1385.86);
usleep(75154.42);
touchUp(6, 241.28, 1385.86);
usleep(158258.75);

touchDown(3, 254.56, 1174.80);
usleep(66565.17);
touchUp(3, 254.56, 1174.80);
usleep(175429.08);

touchDown(6, 254.56, 1358.20);
usleep(83366.62);
touchUp(6, 254.56, 1358.20);
usleep(149743.62);

touchDown(3, 260.69, 1167.63);
usleep(66460.17);
touchUp(3, 260.69, 1167.63);
usleep(200483.75);

touchDown(6, 248.44, 1350.00);
usleep(83185.25);
touchUp(6, 248.44, 1350.00);
usleep(157994.75);

touchDown(3, 264.78, 1168.66);
usleep(66789.75);
touchUp(3, 264.78, 1168.66);
usleep(208379.12);

touchDown(6, 261.72, 1357.17);
usleep(74965.54);
touchUp(6, 261.72, 1357.17);
usleep(141844.62);

touchDown(3, 252.50, 1188.12);
usleep(74650.54);
touchUp(3, 252.50, 1188.12);
usleep(216752.33);

touchDown(6, 250.47, 1331.55);
usleep(83393.21);
touchUp(6, 250.47, 1331.55);
usleep(309010.25);

touchDown(5, 243.31, 988.34);
usleep(41281.29);
touchUp(5, 243.31, 988.34);
usleep(449806.75);

touchDown(3, 229.00, 1203.49);
usleep(66694.50);
touchUp(3, 229.00, 1203.49);
usleep(675398.75);

touchDown(3, 217.75, 1159.43);
usleep(74511.38);
touchUp(3, 217.75, 1159.43);
usleep(533430.50);

touchDown(6, 230.03, 1374.59);
usleep(75307.92);
touchUp(6, 230.03, 1374.59);
usleep(850159.67);

touchDown(3, 258.66, 1195.29);
usleep(33276.00);
touchUp(3, 258.66, 1195.29);
usleep(424810.08);

touchDown(6, 251.50, 1361.27);
usleep(83379.62);
touchUp(6, 251.50, 1361.27);
usleep(483372.83);

touchDown(3, 214.69, 1229.11);
usleep(58389.96);
touchUp(3, 214.69, 1229.11);
usleep(191621.38);

touchDown(4, 202.41, 1414.55);
usleep(75195.08);
touchUp(4, 202.41, 1414.55);
usleep(299937.38);

touchDown(3, 199.34, 1217.84);
usleep(66897.25);
touchUp(3, 199.34, 1217.84);
usleep(133199.54);

touchDown(4, 199.34, 1398.16);
usleep(100064.33);
touchUp(4, 199.34, 1398.16);
usleep(216733.42);

touchDown(3, 214.69, 1177.88);
usleep(33244.29);
touchUp(3, 214.69, 1177.88);
usleep(266661.08);

touchDown(4, 217.75, 1389.96);
usleep(50101.25);
touchUp(4, 217.75, 1389.96);
usleep(274803.38);

touchDown(3, 206.50, 1177.88);
usleep(58554.62);
touchUp(3, 206.50, 1177.88);
usleep(249688.75);
touchUp(4, 245.34, 1382.79);
usleep(300193.33);

touchDown(4, 237.19, 1408.41);
usleep(41527.83);
touchUp(4, 237.19, 1408.41);
usleep(216607.29);

touchDown(3, 205.50, 1205.53);
usleep(92052.96);
touchUp(3, 205.50, 1205.53);
usleep(200093.12);

touchDown(4, 213.66, 1423.76);
usleep(74575.83);
touchUp(4, 213.66, 1423.76);
usleep(166795.67);

touchDown(3, 219.81, 1175.84);
usleep(42017.50);
touchUp(3, 219.81, 1175.84);
usleep(174861.21);

touchDown(4, 213.66, 1364.34);
usleep(66482.71);
touchUp(4, 213.66, 1364.34);
usleep(183592.46);

touchDown(3, 217.75, 1218.87);
usleep(58112.21);
touchUp(3, 217.75, 1218.87);
usleep(241680.54);

touchDown(4, 222.88, 1440.16);
usleep(75407.21);
touchUp(4, 222.88, 1440.16);
usleep(1483137.75);

touchDown(3, 235.12, 1184.02);
usleep(74836.00);
touchUp(3, 235.12, 1184.02);
usleep(333288.79);

touchDown(4, 247.41, 1416.59);
usleep(83256.62);
touchUp(4, 247.41, 1416.59);
usleep(375345.50);

touchDown(3, 219.81, 1196.32);
usleep(74892.04);
touchUp(3, 219.81, 1196.32);
usleep(366684.58);

touchDown(4, 217.75, 1417.62);
usleep(75311.33);
touchUp(4, 217.75, 1417.62);
usleep(324680.92);

touchDown(3, 218.78, 1198.36);
usleep(33370.58);
touchUp(3, 218.78, 1198.36);
usleep(449993.25);

touchDown(4, 210.59, 1412.51);
usleep(66751.17);
touchUp(4, 210.59, 1412.51);
usleep(308350.83);

touchDown(3, 222.88, 1234.22);
usleep(66704.79);
touchUp(3, 222.88, 1234.22);
usleep(258287.62);

touchDown(4, 227.97, 1403.27);
usleep(75274.38);
touchUp(4, 227.97, 1403.27);
usleep(208111.92);

touchDown(3, 208.56, 1181.98);
usleep(41760.12);
touchUp(3, 208.56, 1181.98);
usleep(216921.17);

touchDown(4, 221.84, 1397.13);
usleep(57935.83);
touchUp(4, 221.84, 1397.13);
usleep(158567.50);

touchDown(3, 206.50, 1199.39);
usleep(66604.38);
touchUp(3, 206.50, 1199.39);
usleep(218088.58);

touchDown(4, 209.56, 1417.62);
usleep(65447.21);
touchUp(4, 209.56, 1417.62);
usleep(174670.08);

touchDown(3, 220.81, 1247.55);
usleep(16763.62);
—(3, 220.81, 1230.14);
usleep(8804.62);
—(3, 220.81, 1223.98);
usleep(7829.92);
—(3, 218.78, 1220.91);
usleep(8493.67);
—(3, 216.72, 1218.87);
usleep(8296.04);
—(3, 215.72, 1218.87);
usleep(8377.83);
—(3, 214.69, 1218.87);
usleep(8345.83);
touchUp(3, 213.66, 1227.05);
usleep(225159.83);

touchDown(4, 217.75, 1410.45);
usleep(58068.54);
touchUp(4, 217.75, 1410.45);
usleep(175494.79);

touchDown(3, 207.53, 1165.59);
usleep(41269.75);
touchUp(3, 207.53, 1165.59);
usleep(216523.17);

touchDown(4, 207.53, 1384.83);
usleep(66790.50);
touchUp(4, 207.53, 1384.83);
usleep(208405.67);

touchDown(3, 199.34, 1177.88);
usleep(91792.62);
touchUp(3, 199.34, 1177.88);
usleep(191739.08);

touchDown(4, 209.56, 1382.79);
usleep(91368.46);
touchUp(4, 209.56, 1382.79);
usleep(166612.46);

touchDown(3, 225.94, 1213.73);
usleep(92057.92);
touchUp(3, 225.94, 1213.73);
usleep(174690.62);

touchDown(4, 229.00, 1410.45);
usleep(83479.71);
touchUp(4, 229.00, 1410.45);
usleep(158180.38);

touchDown(3, 204.47, 1183.01);
usleep(58244.67);
touchUp(3, 204.47, 1183.01);
usleep(208579.92);

touchDown(4, 226.97, 1403.27);
usleep(83314.42);
touchUp(4, 226.97, 1403.27);
usleep(166651.29);

touchDown(3, 237.19, 1180.95);
usleep(66957.25);
touchUp(3, 237.19, 1180.95);
usleep(766763.00);

touchDown(1, 233.09, 1457.58);
usleep(74635.58);
touchUp(1, 233.09, 1457.58);
usleep(293210.42);

touchDown(3, 229.00, 1246.52);
usleep(48946.21);
touchUp(3, 229.00, 1246.52);
usleep(216650.96);

touchDown(1, 217.75, 1400.20);
usleep(83415.04);
touchUp(1, 217.75, 1400.20);
usleep(141131.00);

touchDown(3, 218.78, 1237.31);
usleep(75293.75);
touchUp(3, 218.78, 1237.31);
usleep(216720.04);

touchDown(1, 219.81, 1432.99);
usleep(74723.62);
touchUp(1, 219.81, 1432.99);
usleep(158848.58);

touchDown(3, 231.03, 1215.80);
usleep(66457.50);
touchUp(3, 231.03, 1215.80);
usleep(208036.96);

touchDown(1, 218.78, 1446.30);
usleep(83411.83);
touchUp(1, 218.78, 1446.30);
usleep(166714.33);

touchDown(3, 237.19, 1225.01);
usleep(75181.62);
touchUp(3, 237.19, 1225.01);
usleep(224815.88);

touchDown(1, 246.38, 1427.86);
usleep(83301.00);
touchUp(1, 246.38, 1427.86);
usleep(175117.21);

touchDown(3, 230.03, 1214.77);
usleep(83513.42);
touchUp(3, 230.03, 1214.77);
usleep(183139.12);

touchDown(1, 243.31, 1431.96);
usleep(74913.08);
touchUp(1, 243.31, 1431.96);
usleep(166679.38);

touchDown(3, 231.03, 1230.14);
usleep(75304.62);
touchUp(3, 231.03, 1230.14);
usleep(224713.21);

touchDown(1, 215.72, 1442.20);
usleep(91897.33);
touchUp(1, 215.72, 1442.20);
usleep(150146.96);

touchDown(3, 225.94, 1215.80);
usleep(66856.92);
touchUp(3, 225.94, 1215.80);
usleep(199731.08);

touchDown(1, 232.06, 1385.86);
usleep(83367.04);
touchUp(1, 232.06, 1385.86);
usleep(191344.88);

touchDown(3, 240.25, 1178.91);
usleep(66937.67);
touchUp(3, 240.25, 1178.91);
usleep(225038.79);

touchDown(1, 241.28, 1414.55);
usleep(66966.75);
touchUp(1, 241.28, 1414.55);
usleep(157808.71);

touchDown(3, 230.03, 1202.46);
usleep(83470.04);
touchUp(3, 230.03, 1202.46);
usleep(199939.08);

touchDown(1, 240.25, 1414.55);
usleep(58757.33);
touchUp(1, 240.25, 1414.55);
usleep(224853.46);

touchDown(3, 254.56, 1214.77);
usleep(66273.96);
touchUp(3, 254.56, 1214.77);
usleep(233418.58);

touchDown(1, 243.31, 1400.20);
usleep(58537.04);
touchUp(1, 243.31, 1400.20);
usleep(183778.33);

touchDown(3, 240.25, 1198.36);
usleep(74451.67);
touchUp(3, 240.25, 1198.36);
usleep(191724.25);

touchDown(1, 226.97, 1425.82);
usleep(83413.33);
touchUp(1, 226.97, 1425.82);
usleep(250286.83);

touchDown(3, 242.28, 1227.05);
usleep(66684.50);
touchUp(3, 242.28, 1227.05);
usleep(658047.08);

touchDown(1, 225.94, 1420.69);
usleep(100099.21);
touchUp(1, 225.94, 1420.69);
usleep(333397.71);

touchDown(3, 213.66, 1220.91);
usleep(99798.54);
touchUp(3, 213.66, 1220.91);
usleep(441946.04);

touchDown(1, 220.81, 1426.85);
usleep(74850.54);
touchUp(1, 220.81, 1426.85);
usleep(258628.71);

touchDown(3, 235.12, 1197.35);
usleep(74670.00);
touchUp(3, 235.12, 1197.35);
usleep(275345.62);

touchDown(3, 229.00, 1209.63);
usleep(74698.38);
touchUp(3, 229.00, 1209.63);
usleep(342358.12);

touchDown(3, 224.91, 1219.88);
usleep(82987.25);
touchUp(3, 224.91, 1219.88);
usleep(274733.58);

touchDown(1, 238.19, 1428.89);
usleep(91764.62);
touchUp(1, 238.19, 1428.89);
usleep(425163.33);

touchDown(3, 246.38, 1212.70);
usleep(74818.79);
touchUp(3, 246.38, 1212.70);
usleep(291754.00);

touchDown(1, 238.19, 1453.48);
usleep(91907.12);
touchUp(1, 238.19, 1453.48);
usleep(308067.25);

touchDown(3, 233.09, 1259.84);
usleep(83268.92);
touchUp(3, 233.09, 1259.84);
usleep(375352.29);

touchDown(1, 240.25, 1431.96);
usleep(83301.04);
touchUp(1, 240.25, 1431.96);
usleep(174754.75);

touchDown(3, 222.88, 1242.42);
usleep(83302.96);
touchUp(3, 222.88, 1242.42);
usleep(433483.29);

touchDown(1, 221.84, 1422.75);
usleep(99883.38);
touchUp(1, 221.84, 1422.75);
usleep(383339.79);

touchDown(3, 216.72, 1213.73);
usleep(92088.58);
touchUp(3, 216.72, 1213.73);
usleep(258073.38);

touchDown(1, 226.97, 1431.96);
usleep(116658.46);
touchUp(1, 226.97, 1431.96);
usleep(191875.96);

touchDown(3, 245.34, 1218.87);
usleep(83224.79);
touchUp(3, 245.34, 1218.87);
usleep(283442.88);

touchDown(1, 232.06, 1440.16);
usleep(116757.83);
touchUp(1, 232.06, 1440.16);
usleep(224613.25);

touchDown(3, 222.88, 1255.73);
usleep(75386.29);
touchUp(3, 222.88, 1255.73);
usleep(233403.75);

touchDown(1, 220.81, 1370.48);
usleep(83137.08);
touchUp(1, 220.81, 1370.48);
usleep(183449.58);

touchDown(3, 221.84, 1197.35);
usleep(74727.83);
touchUp(3, 221.84, 1197.35);
usleep(210003.79);

touchDown(1, 226.97, 1388.93);
usleep(98841.38);
touchUp(1, 226.97, 1388.93);
usleep(191358.50);

touchDown(3, 220.81, 1229.11);
usleep(83295.12);
touchUp(3, 220.81, 1229.11);
usleep(166598.17);

touchDown(1, 223.88, 1360.24);
usleep(83334.29);
touchUp(1, 223.88, 1360.24);
usleep(208578.75);

touchDown(3, 220.81, 1231.15);
usleep(74850.62);
touchUp(3, 220.81, 1231.15);
usleep(166476.38);

touchDown(1, 236.16, 1399.17);
usleep(91964.58);
touchUp(1, 236.16, 1399.17);
usleep(191456.54);

touchDown(2, 229.00, 1053.91);
usleep(66809.25);
touchUp(2, 229.00, 1053.91);
usleep(450050.71);

touchDown(3, 238.19, 1222.97);
usleep(75236.62);
touchUp(3, 238.19, 1222.97);
usleep(199960.46);

touchDown(1, 240.25, 1385.86);
usleep(91357.92);
touchUp(1, 240.25, 1385.86);
usleep(208771.58);

touchDown(3, 259.66, 1208.62);
usleep(91228.50);
touchUp(3, 259.66, 1208.62);
usleep(225316.00);

touchDown(1, 242.28, 1411.48);
usleep(100097.62);
touchUp(1, 242.28, 1411.48);
usleep(149954.25);

touchDown(3, 229.00, 1194.28);
usleep(91454.71);
touchUp(3, 229.00, 1194.28);
usleep(225113.88);

touchDown(10, 252.50, 1298.77);
usleep(83551.62);
touchUp(10, 252.50, 1298.77);
usleep(158120.38);

touchDown(1, 259.66, 1438.10);
usleep(91741.29);
touchUp(1, 259.66, 1438.10);
usleep(216816.21);

touchDown(3, 240.25, 1233.21);
usleep(74992.71);
touchUp(3, 240.25, 1233.21);
usleep(1066410.62);

touchDown(3, 205.50, 1202.46);
usleep(75230.21);
touchUp(3, 205.50, 1202.46);
usleep(191826.88);

touchDown(4, 217.75, 1361.27);
usleep(91599.42);
touchUp(4, 217.75, 1361.27);
usleep(200257.62);

touchDown(3, 212.66, 1223.98);
usleep(74583.58);
touchUp(3, 212.66, 1223.98);
usleep(200088.08);

touchDown(4, 219.81, 1380.73);
usleep(100202.12);
touchUp(4, 219.81, 1380.73);
usleep(174927.46);

touchDown(3, 219.81, 1180.95);
usleep(66840.08);
touchUp(3, 219.81, 1180.95);
usleep(208345.12);

touchDown(4, 231.03, 1399.17);
usleep(99693.04);
touchUp(4, 231.03, 1399.17);
usleep(175307.50);

touchDown(3, 210.59, 1226.04);
usleep(58259.12);
touchUp(3, 210.59, 1226.04);
usleep(741700.79);

touchDown(3, 207.53, 1245.49);
usleep(74703.58);
touchUp(3, 207.53, 1245.49);
usleep(175177.21);

touchDown(4, 210.59, 1383.82);
usleep(83426.71);
touchUp(4, 210.59, 1383.82);
usleep(317868.00);
touchUp(3, 219.81, 1208.62);
usleep(107062.54);

touchDown(3, 199.34, 1253.70);
usleep(58479.46);
touchUp(3, 199.34, 1253.70);
usleep(350235.75);

touchDown(4, 216.72, 1398.16);
usleep(83363.54);
touchUp(4, 216.72, 1398.16);
usleep(266582.71);

touchDown(3, 219.81, 1205.53);
usleep(74672.75);
touchUp(3, 219.81, 1205.53);
usleep(308667.62);

touchDown(4, 248.44, 1411.48);
usleep(83133.08);
touchUp(4, 248.44, 1411.48);
usleep(308596.04);

touchDown(3, 205.50, 1196.32);
usleep(74975.46);
—(3, 206.50, 1210.66);
usleep(8278.12);
—(3, 206.50, 1217.84);
usleep(8362.25);
—(3, 208.56, 1226.04);
usleep(8003.62);
touchUp(3, 217.75, 1235.25);
usleep(237001.92);

touchDown(4, 240.25, 1402.24);
usleep(88214.54);
touchUp(4, 240.25, 1402.24);
usleep(258122.00);

touchDown(3, 203.44, 1174.80);
usleep(108556.33);
touchUp(3, 203.44, 1174.80);
usleep(308384.12);

touchDown(4, 246.38, 1408.41);
usleep(100194.46);
touchUp(4, 246.38, 1408.41);
usleep(174782.92);

touchDown(3, 221.84, 1215.80);
usleep(66708.29);
touchUp(3, 221.84, 1215.80);
usleep(274811.62);

touchDown(1, 239.22, 1417.62);
usleep(108813.71);
touchUp(1, 239.22, 1417.62);
usleep(133160.50);

touchDown(3, 231.03, 1235.25);
usleep(91476.42);
touchUp(3, 231.03, 1235.25);
usleep(275597.62);

touchDown(1, 225.94, 1429.92);
usleep(99668.83);
touchUp(1, 225.94, 1429.92);
usleep(124898.96);

touchDown(3, 214.69, 1222.97);
usleep(66519.12);
touchUp(3, 214.69, 1222.97);
usleep(283299.79);

touchDown(1, 218.78, 1438.10);
usleep(91929.38);
touchUp(1, 218.78, 1438.10);
usleep(133390.83);

touchDown(3, 214.69, 1248.56);
usleep(41532.21);
—(3, 220.81, 1229.11);
usleep(8777.21);
—(3, 220.81, 1225.01);
usleep(7797.71);
—(3, 220.81, 1223.98);
usleep(8403.67);
touchUp(3, 223.88, 1217.84);
usleep(266828.33);

touchDown(1, 224.91, 1380.73);
usleep(91664.58);
touchUp(1, 224.91, 1380.73);
usleep(125260.29);

touchDown(3, 218.78, 1212.70);
usleep(66492.67);
touchUp(3, 218.78, 1212.70);
usleep(333299.50);

touchDown(1, 227.97, 1435.03);
usleep(58490.25);
—(1, 241.28, 1428.89);
usleep(8270.83);
—(1, 241.28, 1421.72);
usleep(8176.71);
—(1, 242.28, 1412.51);
usleep(8316.46);
—(1, 246.38, 1401.23);
usleep(8286.75);
touchUp(1, 252.50, 1385.86);
usleep(133463.17);

touchDown(3, 211.62, 1200.42);
usleep(74943.04);
touchUp(3, 211.62, 1200.42);
usleep(308104.62);

touchDown(1, 219.81, 1413.52);
usleep(92111.38);
touchUp(1, 219.81, 1413.52);
usleep(116459.67);

touchDown(3, 226.97, 1222.97);
usleep(91618.83);
touchUp(3, 226.97, 1222.97);
usleep(283372.50);

touchDown(1, 246.38, 1414.55);
usleep(58636.58);
—(1, 257.62, 1402.24);
usleep(8314.42);
—(1, 257.62, 1397.13);
usleep(8210.46);
—(1, 257.62, 1388.93);
usleep(8107.25);
touchUp(1, 261.72, 1378.69);
usleep(116643.75);

touchDown(3, 227.97, 1214.77);
usleep(75456.62);
touchUp(3, 227.97, 1214.77);
usleep(291501.58);

touchDown(1, 233.09, 1401.23);
usleep(75080.83);
touchUp(1, 233.09, 1401.23);
usleep(133483.75);

touchDown(3, 232.06, 1217.84);
usleep(66555.21);
touchUp(3, 232.06, 1217.84);
usleep(333146.42);

touchDown(1, 230.03, 1434.02);
usleep(83570.71);
touchUp(1, 230.03, 1434.02);
usleep(150075.25);

touchDown(3, 226.97, 1241.39);
usleep(57954.21);
touchUp(3, 226.97, 1241.39);
usleep(291875.42);

touchDown(1, 229.00, 1392.00);
usleep(100311.79);
touchUp(1, 229.00, 1392.00);
usleep(116555.29);

touchDown(3, 220.81, 1228.08);
usleep(66627.00);
touchUp(3, 220.81, 1228.08);
usleep(274922.75);

touchDown(1, 232.06, 1431.96);
usleep(66559.04);
—(1, 222.88, 1411.48);
usleep(8587.62);
—(1, 218.78, 1408.41);
usleep(8295.54);
—(1, 215.72, 1405.34);
usleep(8240.54);
touchUp(1, 212.66, 1399.17);
usleep(150103.79);

touchDown(3, 201.41, 1186.08);
usleep(24823.17);
touchUp(3, 201.41, 1186.08);
usleep(358788.79);

touchDown(1, 230.03, 1373.55);
usleep(57797.54);
touchUp(1, 230.03, 1373.55);
usleep(133259.00);

touchDown(3, 201.41, 1205.53);
usleep(75391.17);
touchUp(3, 201.41, 1205.53);
usleep(333090.17);

touchDown(1, 213.66, 1413.52);
usleep(66781.00);
touchUp(1, 213.66, 1413.52);
usleep(150036.83);

touchDown(3, 197.31, 1208.62);
usleep(50409.92);
touchUp(3, 197.31, 1208.62);
usleep(349505.54);

touchDown(1, 200.38, 1410.45);
usleep(83415.38);
touchUp(1, 200.38, 1410.45);
usleep(124906.29);

touchDown(3, 192.19, 1216.80);
usleep(49994.54);
touchUp(3, 192.19, 1216.80);
usleep(350230.79);

touchDown(7, 208.56, 1464.75);
usleep(74892.17);
touchUp(7, 208.56, 1464.75);
usleep(141624.58);

touchDown(3, 200.38, 1237.31);
usleep(50037.08);
touchUp(3, 200.38, 1237.31);
usleep(391877.92);

touchDown(7, 213.66, 1426.85);
usleep(83637.62);
touchUp(7, 213.66, 1426.85);
usleep(116273.25);

touchDown(3, 208.56, 1222.97);
usleep(83493.83);
touchUp(3, 208.56, 1222.97);
usleep(349833.96);

touchDown(7, 187.09, 1446.30);
usleep(50241.46);
—(7, 184.00, 1424.79);
usleep(7903.38);
—(7, 184.00, 1419.68);
usleep(8728.08);
—(7, 184.00, 1413.52);
usleep(8331.46);
—(7, 183.00, 1407.38);
usleep(8133.25);
—(7, 183.00, 1401.23);
usleep(8270.88);
touchUp(7, 181.97, 1390.99);
usleep(91928.71);

touchDown(3, 190.16, 1255.73);
usleep(66467.00);
touchUp(3, 190.16, 1255.73);
usleep(341681.88);

touchDown(3, 193.22, 1239.35);
usleep(75054.38);
touchUp(3, 193.22, 1239.35);
usleep(91583.96);

touchDown(3, 192.19, 1230.14);
usleep(66875.62);
touchUp(3, 192.19, 1230.14);
usleep(174919.79);

touchDown(1, 203.44, 1373.55);
usleep(108137.04);
touchUp(1, 203.44, 1373.55);
usleep(108389.67);
touchUp(1, 215.72, 1384.83);
usleep(233579.83);

touchDown(3, 214.69, 1211.70);
usleep(91495.96);
touchUp(3, 214.69, 1211.70);
usleep(233536.58);

touchDown(3, 214.69, 1215.80);
usleep(83442.67);
touchUp(3, 214.69, 1215.80);
usleep(191667.00);

touchDown(1, 234.12, 1420.69);
usleep(91329.83);
touchUp(1, 234.12, 1420.69);
usleep(342372.79);

touchDown(1, 238.19, 1424.79);
usleep(66305.67);
touchUp(1, 238.19, 1424.79);
usleep(266789.67);

touchDown(3, 220.81, 1201.45);
usleep(91313.62);
touchUp(3, 220.81, 1201.45);
usleep(266586.96);

touchDown(10, 240.25, 1270.08);
usleep(108528.12);
touchUp(10, 240.25, 1270.08);
usleep(174806.88);

touchDown(1, 231.03, 1407.38);
usleep(91989.46);
touchUp(1, 231.03, 1407.38);
usleep(99844.08);

touchDown(1, 227.97, 1386.89);
usleep(50203.67);
touchUp(1, 227.97, 1386.89);
usleep(341549.38);

touchDown(3, 239.22, 1197.35);
usleep(83283.04);
touchUp(3, 239.22, 1197.35);
usleep(158279.25);
touchUp(3, 222.88, 1196.32);
usleep(241692.54);

touchDown(1, 261.72, 1429.92);
usleep(75539.25);
touchUp(1, 261.72, 1429.92);
usleep(851110.83);

touchDown(3, 238.19, 1256.77);
usleep(40324.50);
touchUp(3, 238.19, 1256.77);
usleep(166389.46);

touchDown(1, 243.31, 1371.52);
usleep(108701.58);
touchUp(1, 243.31, 1371.52);
usleep(124798.71);

touchDown(1, 237.19, 1427.86);
usleep(33562.00);
touchUp(1, 237.19, 1427.86);
usleep(291699.46);

touchDown(3, 215.72, 1240.38);
usleep(83385.00);
touchUp(3, 215.72, 1240.38);
usleep(91380.88);

touchDown(3, 217.75, 1241.39);
usleep(83287.33);
touchUp(3, 217.75, 1241.39);
usleep(166771.25);

touchDown(1, 246.38, 1397.13);
usleep(108505.71);
touchUp(1, 246.38, 1397.13);
usleep(50300.17);

touchDown(1, 237.19, 1416.59);
usleep(91283.25);
touchUp(1, 237.19, 1416.59);
usleep(183144.83);

touchDown(3, 241.28, 1242.42);
usleep(92011.58);
touchUp(3, 241.28, 1242.42);
usleep(83406.67);

touchDown(3, 227.97, 1231.15);
usleep(66488.75);
touchUp(3, 227.97, 1231.15);
usleep(266813.83);

touchDown(1, 243.31, 1421.72);
usleep(66534.21);
touchUp(1, 243.31, 1421.72);
usleep(75010.38);

touchDown(1, 223.88, 1404.30);
usleep(91728.96);
touchUp(1, 223.88, 1404.30);
usleep(216668.96);

touchDown(3, 236.16, 1220.91);
usleep(50148.83);
touchUp(3, 236.16, 1220.91);
usleep(83529.96);

touchDown(3, 222.88, 1236.28);
usleep(66189.71);
touchUp(3, 222.88, 1236.28);
usleep(250170.38);

touchDown(1, 236.16, 1417.62);
usleep(83434.50);
touchUp(1, 236.16, 1417.62);
usleep(66601.33);

touchDown(1, 229.00, 1436.06);
usleep(99925.17);
touchUp(1, 229.00, 1436.06);
usleep(225132.54);

touchDown(3, 211.62, 1228.08);
usleep(83364.92);
touchUp(3, 211.62, 1228.08);
usleep(49769.00);

touchDown(3, 209.56, 1234.22);
usleep(91820.46);
touchUp(3, 209.56, 1234.22);
usleep(216674.29);

touchDown(1, 229.00, 1405.34);
usleep(74855.79);
touchUp(1, 229.00, 1405.34);
usleep(93405.17);

touchDown(1, 232.06, 1418.65);
usleep(48537.25);
touchUp(1, 232.06, 1418.65);
usleep(191425.21);

touchDown(3, 252.50, 1237.31);
usleep(75130.54);
touchUp(3, 252.50, 1237.31);
usleep(75090.96);

touchDown(3, 240.25, 1238.32);
usleep(91649.00);
touchUp(3, 240.25, 1238.32);
usleep(208187.75);

touchDown(2, 220.81, 1054.95);
usleep(66541.67);
touchUp(2, 220.81, 1054.95);
usleep(475247.54);

touchDown(9, 244.34, 1161.49);
usleep(75246.29);
touchUp(9, 244.34, 1161.49);
usleep(274622.04);

touchDown(1, 239.22, 1411.48);
usleep(116830.17);
touchUp(1, 239.22, 1411.48);
usleep(183436.00);

touchDown(9, 244.34, 1192.22);
usleep(99909.25);
touchUp(9, 244.34, 1192.22);
usleep(300007.50);

touchDown(3, 246.38, 1273.17);
usleep(66876.71);
touchUp(3, 246.38, 1273.17);
usleep(249866.83);

touchDown(1, 235.12, 1434.02);
usleep(108304.83);
touchUp(1, 235.12, 1434.02);
usleep(183306.33);

touchDown(3, 221.84, 1268.04);
usleep(91978.58);
touchUp(3, 221.84, 1268.04);
usleep(333381.67);

touchDown(3, 222.88, 1242.42);
usleep(99720.96);
touchUp(3, 222.88, 1242.42);
usleep(466824.88);

touchDown(3, 246.38, 1270.08);
usleep(91539.75);
touchUp(3, 246.38, 1270.08);
usleep(266768.33);

touchDown(1, 221.84, 1422.75);
usleep(116464.96);
touchUp(1, 221.84, 1422.75);
usleep(617096.92);

touchDown(7, 199.34, 1339.76);
usleep(125110.54);
touchUp(7, 199.34, 1339.76);
usleep(474824.04);

touchDown(9, 221.84, 1200.42);
usleep(83293.25);
touchUp(9, 221.84, 1200.42);
usleep(316712.67);

touchDown(7, 231.03, 1364.34);
usleep(108170.08);
touchUp(7, 231.03, 1364.34);
usleep(266717.29);

touchDown(9, 204.47, 1211.70);
usleep(108704.79);
touchUp(9, 204.47, 1211.70);
usleep(341326.88);

touchDown(1, 193.22, 1418.65);
usleep(124966.83);
touchUp(1, 193.22, 1418.65);
usleep(308538.79);

touchDown(9, 215.72, 1216.80);
usleep(124839.12);
touchUp(9, 215.72, 1216.80);
usleep(275106.04);

touchDown(1, 220.81, 1400.20);
usleep(91658.96);
—(1, 217.75, 1389.96);
usleep(8483.79);
—(1, 214.69, 1389.96);
usleep(8309.33);
—(1, 210.59, 1389.96);
usleep(8512.33);
—(1, 209.56, 1389.96);
usleep(8097.92);
touchUp(1, 204.47, 1385.86);
usleep(275116.38);

touchDown(9, 227.97, 1245.49);
usleep(108140.38);
touchUp(9, 227.97, 1245.49);
usleep(325229.29);

touchDown(1, 198.31, 1435.03);
usleep(116970.46);
touchUp(1, 198.31, 1435.03);
usleep(258140.79);

touchDown(9, 225.94, 1230.14);
usleep(108135.29);
touchUp(9, 225.94, 1230.14);
usleep(241511.17);

touchDown(7, 219.81, 1361.27);
usleep(108539.33);
touchUp(7, 219.81, 1361.27);
usleep(191666.17);

touchDown(9, 200.38, 1217.84);
usleep(99908.46);
touchUp(9, 200.38, 1217.84);
usleep(158871.25);

touchDown(7, 221.84, 1366.38);
usleep(91143.83);
touchUp(7, 221.84, 1366.38);
usleep(141996.21);

touchDown(9, 209.56, 1206.56);
usleep(74764.88);
touchUp(9, 209.56, 1206.56);
usleep(133216.58);

touchDown(7, 235.12, 1371.52);
usleep(91875.62);
touchUp(7, 235.12, 1371.52);
usleep(133277.38);

touchDown(9, 223.88, 1218.87);
usleep(58357.88);
touchUp(9, 223.88, 1218.87);
usleep(191679.21);

touchDown(7, 222.88, 1386.89);
usleep(108426.88);
touchUp(7, 222.88, 1386.89);
usleep(133270.62);

touchDown(9, 225.94, 1209.63);
usleep(83473.79);
touchUp(9, 225.94, 1209.63);
usleep(133046.04);

touchDown(4, 251.50, 1399.17);
usleep(75507.38);
—(4, 241.28, 1381.76);
usleep(8110.33);
—(4, 238.19, 1381.76);
usleep(8677.42);
—(4, 235.12, 1381.76);
usleep(7801.38);
touchUp(4, 231.03, 1377.66);
usleep(166724.54);

touchDown(9, 236.16, 1204.52);
usleep(66592.92);
touchUp(9, 236.16, 1204.52);
usleep(158463.88);

touchDown(4, 230.03, 1387.90);
usleep(100312.08);
touchUp(4, 230.03, 1387.90);
usleep(157863.50);

touchDown(2, 224.91, 1003.71);
usleep(83455.50);
touchUp(2, 224.91, 1003.71);
usleep(283193.96);

touchDown(9, 249.44, 1173.77);
usleep(92065.50);
touchUp(9, 249.44, 1173.77);
usleep(191434.83);

touchDown(4, 263.75, 1369.48);
usleep(91950.58);
touchUp(4, 263.75, 1369.48);
usleep(183397.67);

touchDown(3, 255.59, 1238.32);
usleep(91384.50);
touchUp(3, 255.59, 1238.32);
usleep(158455.88);

touchDown(3, 251.50, 1233.21);
usleep(66624.04);
touchUp(3, 251.50, 1233.21);
usleep(83559.25);

touchDown(3, 264.78, 1202.46);
usleep(83306.79);
touchUp(3, 264.78, 1202.46);
usleep(149771.29);

touchDown(4, 266.84, 1417.62);
usleep(100148.42);
touchUp(4, 266.84, 1417.62);
usleep(183487.50);

touchDown(3, 263.75, 1214.77);
usleep(83144.12);
touchUp(3, 263.75, 1214.77);
usleep(83565.08);

touchDown(3, 246.38, 1215.80);
usleep(74887.71);
touchUp(3, 246.38, 1215.80);
usleep(149812.17);

touchDown(4, 257.62, 1348.97);
usleep(49904.08);
touchUp(4, 257.62, 1348.97);
usleep(141902.83);

touchDown(1, 234.12, 1434.02);
usleep(108175.42);
touchUp(1, 234.12, 1434.02);
usleep(208533.88);

touchDown(2, 186.06, 1022.16);
usleep(108394.00);
touchUp(2, 186.06, 1022.16);
usleep(375280.08);

touchDown(11, 1962.97, 102.12);
usleep(66707.88);
—(11, 1985.47, 93.91);
usleep(7853.04);
—(11, 1990.56, 92.88);
usleep(8785.33);
—(11, 1996.72, 89.81);
usleep(7867.71);
—(11, 2003.88, 84.70);
usleep(8587.21);
touchUp(11, 2010.00, 73.43);
usleep(691642.54);

touchDown(8, 793.34, 1209.63);
usleep(33127.58);
—(8, 796.44, 1229.11);
usleep(8866.42);
—(8, 796.44, 1234.22);
usleep(7799.83);
—(8, 796.44, 1239.35);
usleep(8766.75);
—(8, 796.44, 1243.45);
usleep(7951.79);
—(8, 794.38, 1247.55);
usleep(8610.54);
—(8, 790.28, 1251.66);
usleep(8291.88);
—(8, 787.22, 1253.70);
usleep(8350.17);
—(8, 787.22, 1255.73);
usleep(7966.79);
touchUp(8, 781.09, 1254.73);
usleep(816783.88);

touchDown(5, 148.22, 1411.48);
usleep(116828.62);
touchUp(5, 148.22, 1411.48);


