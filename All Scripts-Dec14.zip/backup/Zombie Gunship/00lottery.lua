-- Demo, Scout, Scout, Assault - Napalm, Napalm, HCan

usleep(1500000);

--set camera

touchDown(0, 894, 603);
usleep(20000);

touchMove(0, 218, 132);
usleep(20000);

touchUp(0, 1604, 314);
usleep(20000);

--tap map

usleep(1000000);

tap(1184, 431);
usleep(20000);

--deploy

tap(1904, 1356);
usleep(20000);

--Position Crosshair

usleep(250000);

touchDown(0, 1062, 788);
usleep(50000);

touchMove(0, 1140, 1040);
usleep(250000);

touchUp(0, 1090, 1050);
usleep(4750000);

--

function guns()

tap(300, 1400);
usleep(500000);

tap(300, 1200);
usleep(500000);

touchDown(1, 300, 1000);
usleep(150000);
touchUp(1, 300, 1000);

usleep(1000000);

end

--do guns

for i=21,1,-1 do guns()
end

--Extraction

toast("Extraction in 5 seconds", 5);
usleep(4500000);

touchDown(0, 317, 643);
usleep(4000000);
touchUp(0, 317, 643);

usleep(40000000);

--tap retry

tap(150, 1500);
usleep(2500000);












































