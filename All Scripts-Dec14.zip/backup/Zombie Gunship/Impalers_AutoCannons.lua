usleep(1000000);
--
touchDown(0, 648, 811);
usleep(100000);
touchMove(0, 1577, 714);
usleep(100000);
touchUp(0, 1577, 714);
usleep(500000);
--
tap(1105, 922);
usleep(500000);
tap(1901, 1370);
usleep(1000000);
tap(138, 645);
usleep(250000);
--
touchDown(0, 1026, 766);
usleep(100000);
touchMove(0, 1125, 675);
usleep(100000);
touchUp(0, 1125, 675);
usleep(1000000);
-- GUNS

touchDown(0, 250, 1400);

usleep(3000000);

touchUp(0, 250, 1400);

usleep(1000000);

touchDown(0, 250, 1200);

usleep(2500000);

touchUp(0, 250, 1200);

usleep(1000000);

-- GUNS Repeat

touchDown(0, 250, 1400);

usleep(3000000);

touchUp(0, 250, 1400);

usleep(1000000);

touchDown(0, 250, 1200);

usleep(2500000);

touchUp(0, 250, 1200);

usleep(1000000);
touchDown(0, 250, 1400);

usleep(3000000);

touchUp(0, 250, 1400);

usleep(1000000);

touchDown(0, 250, 1200);

usleep(2500000);

touchUp(0, 250, 1200);

usleep(1000000);
touchDown(0, 250, 1400);

usleep(3000000);

touchUp(0, 250, 1400);

usleep(1000000);

touchDown(0, 250, 1200);

usleep(2500000);

touchUp(0, 250, 1200);

usleep(1000000);
touchDown(0, 250, 1400);

usleep(3000000);

touchUp(0, 250, 1400);

usleep(1000000);

touchDown(0, 250, 1200);

usleep(2500000);

touchUp(0, 250, 1200);

usleep(1000000);
touchDown(0, 250, 1400);

usleep(3000000);

touchUp(0, 250, 1400);

usleep(1000000);

touchDown(0, 250, 1200);

usleep(2500000);

touchUp(0, 250, 1200);

usleep(1000000);
touchDown(0, 250, 1400);

usleep(3000000);

touchUp(0, 250, 1400);

usleep(1000000);

touchDown(0, 250, 1200);

usleep(2500000);

touchUp(0, 250, 1200);

usleep(1000000);
touchDown(0, 250, 1400);

usleep(3000000);

touchUp(0, 250, 1400);

usleep(1000000);

touchDown(0, 250, 1200);

usleep(2500000);

touchUp(0, 250, 1200);

usleep(1000000);
touchDown(0, 250, 1400);

usleep(3000000);

touchUp(0, 250, 1400);

usleep(1000000);

touchDown(0, 250, 1200);

usleep(2500000);

touchUp(0, 250, 1200);

usleep(1000000);
touchDown(0, 250, 1400);

usleep(3000000);

touchUp(0, 250, 1400);

usleep(1000000);

touchDown(0, 250, 1200);

usleep(2500000);

touchUp(0, 250, 1200);

usleep(1000000);
touchDown(0, 250, 1400);

usleep(3000000);

touchUp(0, 250, 1400);

usleep(1000000);

touchDown(0, 250, 1200);

usleep(2500000);

touchUp(0, 250, 1200);

usleep(1000000);

touchDown(0, 250, 1400);

usleep(3000000);

touchUp(0, 250, 1400);

usleep(1000000);

touchDown(0, 250, 1200);

usleep(2500000);

touchUp(0, 250, 1200);

usleep(1000000);
touchDown(0, 250, 1400);

usleep(3000000);

touchUp(0, 250, 1400);

usleep(1000000);

touchDown(0, 250, 1200);

usleep(2500000);

touchUp(0, 250, 1200);

usleep(1000000);
touchDown(0, 250, 1400);

usleep(3000000);

touchUp(0, 250, 1400);

usleep(1000000);

touchDown(0, 250, 1200);

usleep(2500000);

touchUp(0, 250, 1200);

usleep(1000000);
touchDown(0, 250, 1400);

usleep(3000000);

touchUp(0, 250, 1400);

usleep(1000000);

touchDown(0, 250, 1200);

usleep(2500000);

touchUp(0, 250, 1200);

usleep(1000000);
touchDown(0, 250, 1400);

usleep(3000000);

touchUp(0, 250, 1400);

usleep(1000000);

touchDown(0, 250, 1200);

usleep(2500000);

touchUp(0, 250, 1200);

usleep(1000000);

touchDown(0, 250, 1400);

usleep(3000000);

touchUp(0, 250, 1400);

usleep(1000000);

touchDown(0, 250, 1200);

usleep(2500000);

touchUp(0, 250, 1200);

usleep(1000000);
touchDown(0, 250, 1400);

usleep(3000000);

touchUp(0, 250, 1400);

usleep(1000000);

touchDown(0, 250, 1200);

usleep(2500000);

touchUp(0, 250, 1200);

usleep(1000000);
touchDown(0, 250, 1400);

usleep(3000000);

touchUp(0, 250, 1400);

usleep(1000000);

touchDown(0, 250, 1200);

usleep(2500000);

touchUp(0, 250, 1200);

usleep(1000000);
touchDown(0, 250, 1400);

usleep(3000000);

touchUp(0, 250, 1400);

usleep(1000000);

touchDown(0, 250, 1200);

usleep(2500000);

touchUp(0, 250, 1200);

usleep(1000000);

touchDown(0, 250, 1400);

usleep(3000000);

touchUp(0, 250, 1400);

usleep(1000000);

touchDown(0, 250, 1200);

usleep(2500000);

touchUp(0, 250, 1200);

usleep(1000000);
touchDown(0, 250, 1400);

usleep(3000000);

touchUp(0, 250, 1400);

usleep(1000000);

touchDown(0, 250, 1200);

usleep(2500000);

touchUp(0, 250, 1200);

usleep(1000000);
touchDown(0, 250, 1400);

usleep(3000000);

touchUp(0, 250, 1400);

usleep(1000000);

touchDown(0, 250, 1200);

usleep(2500000);

touchUp(0, 250, 1200);

usleep(1000000);
touchDown(0, 250, 1400);

usleep(3000000);

touchUp(0, 250, 1400);

usleep(1000000);

touchDown(0, 250, 1200);

usleep(2500000);

touchUp(0, 250, 1200);

usleep(1000000);

touchDown(0, 250, 1400);

usleep(3000000);

touchUp(0, 250, 1400);

usleep(1000000);

touchDown(0, 250, 1200);

usleep(2500000);

touchUp(0, 250, 1200);

usleep(1000000);

touchDown(0, 250, 1400);

usleep(3000000);

touchUp(0, 250, 1400);

usleep(1000000);

touchDown(0, 250, 1200);

usleep(2500000);

touchUp(0, 250, 1200);

usleep(1000000);

touchDown(0, 250, 1400);

usleep(3000000);

touchUp(0, 250, 1400);

usleep(1000000);

touchDown(0, 250, 1200);

usleep(2500000);

touchUp(0, 250, 1200);

usleep(1000000);

-- End guns

tap(1965, 82);
usleep(500000);
tap(1016, 1197);
usleep(2000000);
tap(156, 1441);
usleep(1000000);




































