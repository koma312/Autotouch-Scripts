--appActivate("com.flaregames.zombiegunship");

usleep(1000000);
--usleep(5000000);
--Deployment Map

touchDown(0, 1111, 1391);
usleep(50000);
touchMove(0, 1111, 233);
usleep(50000);
touchUp(0, 1111, 233);
usleep(250000);
tap(1493, 518);
usleep(250000);
tap(1902, 1360);
usleep(250000);
tap(143, 646);
usleep(250000);

--Camera Position

touchDown(0, 1025, 766);
usleep(50000);

touchMove(0, 1242, 610);
usleep(50000);

touchUp(0, 1474, 569);
usleep(250000);

--Guns

usleep(100000);
tap(250, 1000);

usleep(200000000);

--Extraction

usleep(500000);
tap(1965, 82);
usleep(500000);
tap(1016, 1197);
usleep(1000000);
tap(156, 1441);
usleep(2000000);
































