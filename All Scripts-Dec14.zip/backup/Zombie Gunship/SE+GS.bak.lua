--------------------------------------
-- Mission = Scorched Earth (Hard)
-- Weapon 01 = anything
-- Weapon 02 = Rocket68
-- Weapon 03 = hCan105
-- 
-- 
--------------------------------------

toast("Begin Mission");
usleep(500000);

touchDown(0, 1094, 819);
usleep(50000);

touchMove(0, 610, 781);
usleep(50000);

touchUp(0, 610, 781);
usleep(250000);

--Deploy

usleep(500000);
tap(498, 673);
usleep(500000);
tap(1902, 1357);
usleep(500000);

--Position Crosshair

usleep(250000);

touchDown(0, 1023, 762);
usleep(50000);

touchMove(0, 730, 1036);
usleep(250000);

touchUp(0, 657, 1054);
usleep(250000);

-- touchMove(0, 730, 1036); ON FENCE RIGHT ABOVE TROOP EXIT POSITION
-- touchMove(0, 657, 1054); MIDDLE OF MAP, CROSSHAIRS ON SMALL BUNKER
-- touchMove(0, 781, 1002); CORNER OF BUILDING CLOSE TO DOOR

function bigCan()

	tap(250, 1000);
	usleep(2000);
	
end

function rock()

	tap(250, 1200);
	usleep(2000);
	
end

-- Waiting for Zombies

toast("Waiting for Zombies", 18);
usleep(22000000);

-- Begin Firing Sequence

rock()

usleep(24000000);

rock()

usleep(29000000);

bigCan()

usleep(5000000);

rock()

toast("Looping in 15s", 4);
usleep(5000000);

toast("Looping in 10s", 4);
usleep(5000000);

toast("Looping in 5s", 4);
usleep(4000000);

toast("Looping Now", 3);
usleep(1000000);


--End of Mission

tap(156, 1441);
usleep(2500000);

toast("End of Script");



























































