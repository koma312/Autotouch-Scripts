toast("Arena Start", 2);
usleep(2e6);

function tap(x, y)

    touchDown(2, x, y);
    usleep(2e4);
    touchUp(2, x, y);
end

function clearChamps()

	if getColor(631, 621) == 16054514 then repeat

		tap(631, 621);
		usleep(2e6);

	until 
		getColor(631, 621) ~= 16054514
end
end

usleep(2e6);
clearChamps()

for i=3,1,-1 do

	usleep(1e6);
	touchDown(0, 714, 719);
	usleep(3e4);
	touchMove(0, 439, 729);
	usleep(3e4);
	touchUp(0, 493, 729);
	usleep(1e6); 
	tap(271, 1430);
end

	usleep(7e6); 
	tap(1268, 1191);

for i=6,1,-1 do

	usleep(2e6);
	tap(1756, 1445);
end

	usleep(6e6);

-- if gc then -- for i=

if getColor(1732, 1444) ~= 16777215 then repeat

	tap(1303, 1209);
	usleep(5e6);

until getColor(1732, 1444) == 16777215

	usleep(2e6); 
	tap(1403, 1456);
	usleep(6e6);
end


----

clearChamps()

toast('</end>', 1);
usleep(1e6);

















































