-- const { getColor, touchDown, touchMove, touchUp, usleep, appActivate, keyDown, keyUp, toast, } = at

usleep(5e5);

toast("Arena Start", 2);
usleep(2000000);

function champ()

    usleep(1000000);
	touchDown(0, 714, 719);
	usleep(50000);
	touchMove(0, 439, 729);
	usleep(50000);
	touchUp(0, 493, 729);
	usleep(1500000); 
	tap(271, 1430);
	
end


champ()
champ()
champ()
--champ()

usleep(3e6); 
tap(1268, 1191);

function tapConfirm()
     buttonColor = getColor(914, 1010);
     while buttonColor == 3223343 do
	     tap(1756, 1445);
	     usleep(1000000)
	end
end

tapConfirm()
tapConfirm()
tapConfirm()


while fightColor ~= 2302498 do
		usleep(1e6);
end
--fightColor == 2302498
--end


function fight()

	fightColor = getColor(1082, 76);
     while (fightColor)==2302498 do 
		--tap(1654, 354);
		tap(1285, 1211);
		--usleep(2e6);
	end

while (fightColor) ~= 2302498 do 
		tap(1285, 1211);
		--usleep(2e6);
end
end

--usleep(8e6);
fight()
--usleep(2e6);
fight()
--usleep(2e6);
fight()
--usleep(2e6);












































