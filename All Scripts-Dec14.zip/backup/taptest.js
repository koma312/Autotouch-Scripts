const { touchDown, touchMove, touchUp, usleep, appActivate, keyDown, keyUp, toast, } = at



function tap(x, y) {
    touchDown(0, x, y)
    usleep(2e4)
    touchUp(0, x, y)
}


tap([
    {168, 623},
    {246, 566},
    {324, 508},
    {397, 447},
    {478, 389},
    {545, 331},
    {635, 268},
    {709, 202},
    {853, 105}])




































