const { touchDown, touchMove, touchUp, usleep, appActivate, keyDown, keyUp, toast, } = at

usleep(5e5);

function tap(x, y) {
    touchDown(0, x, y)
    usleep(2e4)
    touchUp(0, x, y)
    usleep(3e4); 
}

