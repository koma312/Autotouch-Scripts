/**
 * A simple package showing the way AutoTouch works
 */

// import function `run()` from the module `worker`
const { run } = require("./worker")

// call the function
run()