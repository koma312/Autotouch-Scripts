killall rm
killall curl
killall at
killall autotouch
killall
killall
killall
killall
killall
killall
killall














