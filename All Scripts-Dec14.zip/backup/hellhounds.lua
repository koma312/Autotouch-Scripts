--------------------------------------
-- Information of recording
-- Time: 2020-11-22 12:28:47
-- Resolution: 1536, 2048
-- Front most app: ZG Survival
-- Orientation of front most app: LandscapeRight;
--------------------------------------

appActivate("com.flaregames.zombiegunship");

usleep(1000000);
touchDown(1, 1893.44, 1360.24);
usleep(116701.29);
touchUp(1, 1893.44, 1360.24);
usleep(29706466.21);

touchDown(7, 148.22, 634.88);
usleep(54289.88);
touchUp(7, 148.22, 634.88);
usleep(100000000);

touchDown(4, 1967.06, 77.53);
usleep(73597.12);
touchUp(4, 1967.06, 77.53);
usleep(942025.12);

touchDown(9, 1249.34, 1187.11);
usleep(66480.17);
touchUp(9, 1249.34, 1187.11);
usleep(2573614.42);

touchDown(8, 142.09, 1423.76);
usleep(101342.92);
touchUp(8, 142.09, 1423.76);
usleep(1000000);