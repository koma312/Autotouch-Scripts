

function heavy()

touchDown(0, 1691, 768);
usleep(650000);
touchUp(0, 1691, 768);
usleep(1200000);

end

-- heavy Repeat

for i=10,1,-1 do heavy()
end

-- End heavy

usleep(250000);
tap(339, 1375);

usleep(2800000);












































