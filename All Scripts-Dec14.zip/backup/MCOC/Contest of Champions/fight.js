const { touchDown, touchMove, touchUp, usleep, appActivate, keyDown, keyUp, tap, toast, } = at

const targetImagePath = 'images/abe_win.png'

const options = {
    targetImagePath: targetImagePath,
    count: 0, // OPTIONAL, default is 0, 0 means no limitation
    threshold: 0.8, // OPTIONAL, default is 0.9
    region: null, // OPTIONAL, default is null, null means the whole screen
    debug: false, // OPTIONAL, default is false, true means turn on the debug mode which will produce an image showing the finding process
    method: 1, // OPTIONAL, default is 1, 2 means a more intelligent method
}

//console.log(`>>>>>>>>> Starting Script - ${new Date().toLocaleString()}`)

//————————————————————————————————————

usleep(2000000);

function heavy()

touchDown(0, 1691, 768);
usleep(650000);
touchUp(0, 1691, 768);
usleep(1200000);

end

-- heavy Repeat

for i=5,1,-1 do heavy()
end

-- End heavy

usleep(250000);
tap(339, 1375);
usleep(1500000);


at.findImage({
    options, // OPTIONAL, options for finding image.
    duration: 800, // OPTIONAL, how long time you want it to keep finding? Three formats are supported: 1. `duration: 10` means repeat finding 10 times, the value must be a number, can't be a string; 2. `duration: '60s'` means keep finding for 60 seconds, the value must be seconds + a character 's'; 3. `duration: '2020-05-30 12:00:00'` means keep finding till 2020-05-30 12:00:00. Default is `duration: 10` means repeat 10 times, the value must be a string.
    interval: 1000, // OPTIONAL, interval between loops in milliseconds, default is 1000 milliseconds.
    exitIfFound: true, // OPTIONAL, if exit findImage if got a result successfully, default is true.
    eachFindingCallback: () => { // OPTIONAL, will call this function after each finding loop.
        //console.log(`------Did a time of findImage at ${new Date().toLocaleString()}-------`)
 
//toast("findingImage", 1);

    },
    foundCallback: result => { // OPTIONAL, will call this function while getting matched result, returns the rectangle coordinate matching the action you specified through `matchMethod`.
        //console.log(`Got result of findImage:\n${JSON.stringify(result, null, '    ')}`);










    },
    errorCallback: error => { // OPTIONAL, handle any error, will exit findImage if got error, if no errorCallback provide, it will alert while getting error.
        alert(error)
    },
    completedCallback: () => { // OPTIONAL, callback when all finding completed
        
toast('findImage failed', 10);

    },
    block: true, // OPTIONAL, you want to run findImage asynchronously or synchronously, block=true means it will run synchronously and block here till completed, default is false, doesn't block here.
})

//console.log(`>>>>>>>>> Exiting findImage - ${new Date().toLocaleString()}`)

toast('exiting findImage', 10);
usleep(2000000);


toast("Ending…");
usleep(5000000);

//console.log(`>>>>>>>>> Script Ended - ${new Date().toLocaleString()}`)