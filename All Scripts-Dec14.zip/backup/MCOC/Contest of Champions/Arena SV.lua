usleep(2000000);

touchDown(6, 828.12, 748.59);
usleep(33241.96);
touchMove(6, 806.66, 731.18);
usleep(8633.12);
touchMove(6, 797.44, 728.11);
usleep(8203.12);
touchMove(6, 790.28, 725.04);
usleep(8338.92);
touchMove(6, 782.12, 722.98);
usleep(8228.79);
touchMove(6, 772.91, 720.94);
usleep(8319.38);
touchMove(6, 760.66, 718.88);
usleep(8152.00);
touchMove(6, 748.38, 717.87);
usleep(8481.04);
touchMove(6, 737.12, 716.84);
usleep(8355.29);
touchMove(6, 725.88, 715.80);
usleep(8754.21);
touchMove(6, 714.62, 714.80);
usleep(7922.62);
touchMove(6, 704.41, 713.77);
usleep(8584.71);
touchMove(6, 693.16, 712.73);
usleep(7803.50);
touchMove(6, 683.97, 711.70);
usleep(8489.04);
touchMove(6, 675.78, 710.70);
usleep(8416.25);
touchMove(6, 667.59, 709.66);
usleep(8685.88);
touchMove(6, 659.44, 708.63);
usleep(7985.25);
touchMove(6, 650.22, 707.62);
usleep(8526.29);
touchMove(6, 641.03, 705.56);
usleep(8005.21);
touchMove(6, 631.81, 703.52);
usleep(9278.83);
touchMove(6, 621.59, 699.42);
usleep(7836.75);
touchMove(6, 612.41, 696.35);
usleep(8218.38);
touchMove(6, 603.19, 693.28);
usleep(8256.08);
touchMove(6, 596.03, 689.18);
usleep(8457.00);
touchMove(6, 588.88, 686.11);
usleep(8960.54);
touchMove(6, 581.72, 683.02);
usleep(7810.71);
touchMove(6, 574.56, 678.94);
usleep(8416.79);
touchMove(6, 567.41, 674.84);
usleep(8082.42);
touchMove(6, 558.22, 669.70);
usleep(8378.33);
touchMove(6, 549.00, 664.59);
usleep(10317.00);
touchMove(6, 537.75, 659.46);
usleep(6108.88);
touchMove(6, 527.53, 654.35);
usleep(8774.83);
touchMove(6, 517.31, 650.25);
usleep(8021.08);
touchMove(6, 508.12, 646.15);
usleep(8586.75);
touchMove(6, 499.94, 643.08);
usleep(10404.75);
touchMove(6, 492.78, 641.02);
usleep(6137.50);
touchMove(6, 485.62, 640.01);
usleep(8001.92);
touchMove(6, 480.50, 638.98);
usleep(8760.96);
touchMove(6, 474.38, 637.95);
usleep(7987.00);
touchMove(6, 469.25, 636.91);
usleep(8715.46);
touchMove(6, 463.12, 636.91);
usleep(7892.67);
touchMove(6, 454.94, 636.91);
usleep(8437.17);
touchUp(6, 450.84, 634.88);
usleep(2500000);

touchDown(11, 827.09, 737.32);
usleep(26752.38);
touchMove(11, 810.75, 727.08);
usleep(6649.04);
touchMove(11, 801.53, 727.08);
usleep(7945.33);
touchMove(11, 792.34, 725.04);
usleep(8751.71);
touchMove(11, 782.12, 722.98);
usleep(8014.50);
touchMove(11, 772.91, 721.97);
usleep(8596.21);
touchMove(11, 760.66, 720.94);
usleep(8380.92);
touchMove(11, 745.31, 718.88);
usleep(8387.42);
touchMove(11, 727.94, 715.80);
usleep(8080.04);
touchMove(11, 709.53, 710.70);
usleep(8288.79);
touchMove(11, 686.00, 702.49);
usleep(8113.75);
touchMove(11, 662.50, 694.29);
usleep(8768.96);
touchMove(11, 635.91, 685.08);
usleep(7935.38);
touchMove(11, 609.34, 674.84);
usleep(8578.88);
touchMove(11, 581.72, 665.60);
usleep(8146.79);
touchMove(11, 556.16, 656.39);
usleep(8663.33);
touchMove(11, 531.62, 649.22);
usleep(8258.42);
touchMove(11, 512.19, 645.12);
usleep(8205.12);
touchMove(11, 491.75, 644.09);
usleep(8067.83);
touchMove(11, 474.38, 644.09);
usleep(8800.79);
touchMove(11, 459.03, 644.09);
usleep(7848.46);
touchUp(11, 443.69, 647.18);
usleep(2500000);

touchDown(1, 809.72, 769.08);
usleep(16529.71);
touchMove(1, 796.44, 768.07);
usleep(8370.75);
touchMove(1, 785.19, 768.07);
usleep(8347.50);
touchMove(1, 773.94, 768.07);
usleep(8195.88);
touchMove(1, 763.72, 768.07);
usleep(8961.21);
touchMove(1, 752.47, 768.07);
usleep(7663.50);
touchMove(1, 741.22, 768.07);
usleep(8827.25);
touchMove(1, 725.88, 770.11);
usleep(8005.67);
touchMove(1, 713.62, 772.17);
usleep(8435.25);
touchMove(1, 697.25, 774.21);
usleep(8424.33);
touchMove(1, 680.91, 774.21);
usleep(8173.62);
touchMove(1, 663.50, 775.24);
usleep(8038.67);
touchMove(1, 646.12, 775.24);
usleep(8604.33);
touchMove(1, 626.72, 775.24);
usleep(8222.04);
touchMove(1, 608.31, 775.24);
usleep(8783.88);
touchMove(1, 591.94, 775.24);
usleep(7780.00);
touchMove(1, 578.66, 776.25);
usleep(8794.67);
touchMove(1, 566.38, 777.28);
usleep(8055.58);
touchMove(1, 554.12, 779.34);
usleep(8390.54);
touchMove(1, 542.88, 781.38);
usleep(8283.75);
touchMove(1, 533.69, 783.42);
usleep(8473.75);
touchMove(1, 525.50, 785.48);
usleep(8057.21);
touchMove(1, 517.31, 788.55);
usleep(9761.88);
touchMove(1, 509.12, 792.66);
usleep(7091.71);
touchMove(1, 501.97, 796.76);
usleep(8662.08);
touchMove(1, 495.84, 799.83);
usleep(7833.50);
touchMove(1, 489.72, 803.93);
usleep(8649.25);
touchUp(1, 484.59, 813.14);
usleep(100000);

usleep(3000000);

-- find match

tap(257, 1423);
usleep(4200000);

-- select bottom arena

tap(1400, 1189);
usleep(1000000);

-- continue

tap(1807, 1469);
usleep(8000000);

-- accept

tap(1722, 1450);
usleep(1000000);

-- continue

tap(1809, 1459);
usleep(18000000);

-- fight one

tap(1668, 810);
usleep(2000000);
tap(1668, 810);
usleep(2000000);
tap(1668, 810);
usleep(8000000);

-- next fight

tap(1288, 1213);
usleep(12000000);

-- fight two

tap(1668, 810);
usleep(2000000);
tap(1668, 810);
usleep(2000000);
tap(1668, 810);
usleep(8000000);

-- final fight

tap(1288, 1213);
usleep(12000000);

-- fight three

tap(1668, 810);
usleep(2000000);
tap(1668, 810);
usleep(2000000);
tap(1668, 810);
usleep(12000000);

-- tap anywhere

tap(1288, 1213);
usleep(22000000);

--next series

tap(1308, 1446);
usleep(26000000);

-- countdown

toast("Clearing in 03 seconds", 1);
usleep(1200000);

toast("Clearing in 02 seconds", 1);
usleep(1200000);

toast("Clearing in 01 seconds", 1);
usleep(1200000);

--ask help

tap(158, 1019);
usleep(250000);
tap(158, 1019);
usleep(250000);
tap(158, 1019);

usleep(500000);
tap(660, 601);
usleep(500000);

tap(158, 1019);
usleep(250000);
tap(158, 1019);
usleep(250000);

-- help 2

toast("Clearing in 04 seconds", 1);
usleep(1200000);

toast("Clearing in 03 seconds", 1);
usleep(1200000);

toast("Clearing in 02 seconds", 1);
usleep(1200000);

toast("Clearing in 01 seconds", 1);
usleep(1200000);

tap(158, 1019);
usleep(250000);
tap(158, 1019);
usleep(250000);
tap(158, 1019);

usleep(500000);
tap(660, 601);
usleep(500000);

tap(158, 1019);
usleep(250000);
tap(158, 1019);
usleep(250000);

-- help 3

toast("Clearing in 04 seconds", 1);
usleep(1200000);

toast("Clearing in 03 seconds", 1);
usleep(1200000);

toast("Clearing in 02 seconds", 1);
usleep(1200000);

toast("Clearing in 01 seconds", 1);
usleep(1200000);

tap(158, 1019);
usleep(250000);
tap(158, 1019);
usleep(250000);
tap(158, 1019);

usleep(500000);
tap(660, 601);
usleep(500000);

tap(158, 1019);
usleep(250000);
tap(158, 1019);

usleep(5000000);

--End








































