function heavy()

touchDown(0, 1691, 768);
usleep(650000);
touchUp(0, 1691, 768);
usleep(1200000);

end

-- heavy Repeat

for i=100,1,-1 do heavy()
end

-- End heavy
