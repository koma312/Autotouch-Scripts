toast("Starting Script", 'center', 1);
usleep(2000000);

-- first champ

touchDown(11, 827.09, 737.32);
usleep(26752.38);
touchMove(11, 810.75, 727.08);
usleep(6649.04);
touchMove(11, 801.53, 727.08);
usleep(7945.33);
touchMove(11, 792.34, 725.04);
usleep(8751.71);
touchMove(11, 782.12, 722.98);
usleep(8014.50);
touchMove(11, 772.91, 721.97);
usleep(8596.21);
touchMove(11, 760.66, 720.94);
usleep(8380.92);
touchMove(11, 745.31, 718.88);
usleep(8387.42);
touchMove(11, 727.94, 715.80);
usleep(8080.04);
touchMove(11, 709.53, 710.70);
usleep(8288.79);
touchMove(11, 686.00, 702.49);
usleep(8113.75);
touchMove(11, 662.50, 694.29);
usleep(8768.96);
touchMove(11, 635.91, 685.08);
usleep(7935.38);
touchMove(11, 609.34, 674.84);
usleep(8578.88);
touchMove(11, 581.72, 665.60);
usleep(8146.79);
touchMove(11, 556.16, 656.39);
usleep(8663.33);
touchMove(11, 531.62, 649.22);
usleep(8258.42);
touchMove(11, 512.19, 645.12);
usleep(8205.12);
touchMove(11, 491.75, 644.09);
usleep(8067.83);
touchMove(11, 474.38, 644.09);
usleep(8800.79);
touchMove(11, 459.03, 644.09);
usleep(7848.46);
touchUp(11, 443.69, 647.18);
usleep(1000000);

-- second champ

touchDown(11, 827.09, 737.32);
usleep(26752.38);
touchMove(11, 810.75, 727.08);
usleep(6649.04);
touchMove(11, 801.53, 727.08);
usleep(7945.33);
touchMove(11, 792.34, 725.04);
usleep(8751.71);
touchMove(11, 782.12, 722.98);
usleep(8014.50);
touchMove(11, 772.91, 721.97);
usleep(8596.21);
touchMove(11, 760.66, 720.94);
usleep(8380.92);
touchMove(11, 745.31, 718.88);
usleep(8387.42);
touchMove(11, 727.94, 715.80);
usleep(8080.04);
touchMove(11, 709.53, 710.70);
usleep(8288.79);
touchMove(11, 686.00, 702.49);
usleep(8113.75);
touchMove(11, 662.50, 694.29);
usleep(8768.96);
touchMove(11, 635.91, 685.08);
usleep(7935.38);
touchMove(11, 609.34, 674.84);
usleep(8578.88);
touchMove(11, 581.72, 665.60);
usleep(8146.79);
touchMove(11, 556.16, 656.39);
usleep(8663.33);
touchMove(11, 531.62, 649.22);
usleep(8258.42);
touchMove(11, 512.19, 645.12);
usleep(8205.12);
touchMove(11, 491.75, 644.09);
usleep(8067.83);
touchMove(11, 474.38, 644.09);
usleep(8800.79);
touchMove(11, 459.03, 644.09);
usleep(7848.46);
touchUp(11, 443.69, 647.18);
usleep(1000000);

-- third champ

touchDown(11, 827.09, 737.32);
usleep(26752.38);
touchMove(11, 810.75, 727.08);
usleep(6649.04);
touchMove(11, 801.53, 727.08);
usleep(7945.33);
touchMove(11, 792.34, 725.04);
usleep(8751.71);
touchMove(11, 782.12, 722.98);
usleep(8014.50);
touchMove(11, 772.91, 721.97);
usleep(8596.21);
touchMove(11, 760.66, 720.94);
usleep(8380.92);
touchMove(11, 745.31, 718.88);
usleep(8387.42);
touchMove(11, 727.94, 715.80);
usleep(8080.04);
touchMove(11, 709.53, 710.70);
usleep(8288.79);
touchMove(11, 686.00, 702.49);
usleep(8113.75);
touchMove(11, 662.50, 694.29);
usleep(8768.96);
touchMove(11, 635.91, 685.08);
usleep(7935.38);
touchMove(11, 609.34, 674.84);
usleep(8578.88);
touchMove(11, 581.72, 665.60);
usleep(8146.79);
touchMove(11, 556.16, 656.39);
usleep(8663.33);
touchMove(11, 531.62, 649.22);
usleep(8258.42);
touchMove(11, 512.19, 645.12);
usleep(8205.12);
touchMove(11, 491.75, 644.09);
usleep(8067.83);
touchMove(11, 474.38, 644.09);
usleep(8800.79);
touchMove(11, 459.03, 644.09);
usleep(7848.46);
touchUp(11, 443.69, 647.18);
usleep(3000000);

-- find match

touchDown(1, 257, 1423);
usleep(25000);
touchUp(1, 257, 1423);

usleep(8000000);

-- select bottom arena

touchDown(2, 1400, 1189);
usleep(25000);
touchUp(2, 1400, 1189);

usleep(3000000);

-- continue

touchDown(3, 1807, 1469);
usleep(25000);
touchUp(3, 1807, 1469);

usleep(5000000);

-- accept

touchDown(4, 1722, 1450);
usleep(25000);
touchUp(4, 1722, 1450);

usleep(5000000);

-- continue

touchDown(5, 1809, 1459);
usleep(25000);
touchUp(5, 1809, 1459);

usleep(3000000);

toast("Round One in 10 Seconds", 'center', 1);
usleep(800000);

toast("Round One in 09 Seconds", 'center', 1);
usleep(800000);

toast("Round One in 08 Seconds", 'center', 1);
usleep(800000);

toast("Round One in 07 Seconds", 'center', 1);
usleep(800000);

toast("Round One in 06 Seconds", 'center', 1);
usleep(800000);

toast("Round One in 05 Seconds", 'center', 1);
usleep(800000);

toast("Round One in 04 Seconds", 'center', 1);
usleep(1000000);

toast("Round One in 03 Seconds", 'center', 1);
usleep(1000000);

toast("Round One in 02 Seconds", 'center', 1);
usleep(1000000);

toast("Round One in 01 Seconds", 'center', 1);
usleep(1000000);

-- fight one

toast("Round One", 'center', 1);
usleep(800000);

toast("FIGHT", 'center', 1);
usleep(500000);

touchDown(1, 1668, 810);
usleep(25000);
touchUp(1, 1668, 810);

usleep(2000000);

touchDown(2, 1668, 810);
usleep(25000);
touchUp(2, 1668, 810);

usleep(2000000);

touchDown(3, 1668, 810);
usleep(25000);
touchUp(3, 1668, 810);

usleep(6000000);

-- next fight

touchDown(4, 1288, 1213);
usleep(25000);
touchUp(4, 1288, 1213);

usleep(250000);

touchDown(5, 1288, 1213);
usleep(25000);
touchUp(5, 1288, 1213);

usleep(250000);

touchDown(6, 1288, 1213);
usleep(25000);
touchUp(6, 1288, 1213);

usleep(10000000);

-- fight two

toast("Round Two", 'center', 1);
usleep(800000);

toast("FIGHT", 'center', 1);
usleep(500000);

touchDown(7, 1668, 810);
usleep(25000);
touchUp(7, 1668, 810);

usleep(2000000);

touchDown(8, 1668, 810);
usleep(25000);
touchUp(8, 1668, 810);

usleep(2000000);

touchDown(9, 1668, 810);
usleep(25000);
touchUp(9, 1668, 810);

usleep(6000000);

-- final fight

touchDown(1, 1288, 1213);
usleep(25000);
touchUp(1, 1288, 1213);

usleep(250000);

touchDown(2, 1288, 1213);
usleep(25000);
touchUp(2, 1288, 1213);

usleep(250000);

touchDown(3, 1288, 1213);
usleep(25000);
touchUp(3, 1288, 1213);

usleep(10000000);

-- fight three

toast("Round Three", 'center', 1);
usleep(800000);

toast("FIGHT", 'center', 1);
usleep(500000);

touchDown(1668, 810);
usleep(25000);
touchUp(1668, 810);

usleep(2000000);

touchDown(4, 1668, 810);
usleep(25000);
touchUp(4, 1668, 810);

usleep(2000000);

touchDown(5, 1668, 810);
usleep(25000);
touchUp(5, 1668, 810);

usleep(6000000);

-- tap anywhere

touchDown(6, 1288, 1213);
usleep(25000);
touchUp(6, 1288, 1213);

usleep(500000);

touchDown(7, 813, 1257);
usleep(25000);
touchUp(7, 813, 1257);

usleep(500000);

touchDown(8, 813, 1257);
usleep(25000);
touchUp(8, 813, 1257);

usleep(500000);

touchDown(9, 813, 1257);
usleep(25000);
touchUp(9, 813, 1257);

usleep(5000000);

toast("Next Series in 05 seconds", 1);
usleep(1000000);

toast("Next Series in 04 seconds", 1);
usleep(1000000);

toast("Next Series in 03 seconds", 1);
usleep(1000000);

toast("Next Series in 02 seconds", 1);
usleep(1000000);

toast("Next Series in 01 seconds", 1);
usleep(1000000);

-- next series

touchDown(1, 1308, 1446);
usleep(25000);
touchUp(1, 1308, 1446);

usleep(200000);

touchDown(2, 1308, 1446);
usleep(25000);
touchUp(2, 1308, 1446);

usleep(8000000);

-- help 1

toast("Clearing in 03 seconds", 'center', 1);
usleep(1000000);

toast("Clearing in 02 seconds", 'center', 1);
usleep(1000000);

toast("Clearing in 01 seconds", 'center', 1);
usleep(500000);

tap(158, 1019);
usleep(50000);
tap(158, 1019);
usleep(50000);
tap(158, 1019);

usleep(1000000);

touchDown(3, 660, 600);
usleep(25000);
touchUp(3, 660, 600);

usleep(50000);

tap(158, 1019);
usleep(2000000);

-- help 2

toast("Clearing in 03 seconds", 'center', 1);
usleep(1000000);

toast("Clearing in 02 seconds", 'center', 1);
usleep(1000000);

toast("Clearing in 01 seconds", 'center', 1);
usleep(500000);

tap(158, 1019);
usleep(50000);
tap(158, 1019);
usleep(50000);
tap(158, 1019);

usleep(1000000);

touchDown(5, 660, 600);
usleep(25000);
touchUp(5, 660, 600);

usleep(50000);

tap(158, 1019);
usleep(2000000);


-- help 3

toast("Clearing in 03 seconds", 'center', 1);
usleep(1000000);

toast("Clearing in 02 seconds", 'center', 1);
usleep(1000000);

toast("Clearing in 01 seconds", 'center', 1);
usleep(500000);

tap(158, 1019);
usleep(50000);
tap(158, 1019);
usleep(50000);
tap(158, 1019);

usleep(1000000);

touchDown(8, 660, 600);
usleep(25000);
touchUp(8, 660, 600);

usleep(50000);

tap(158, 1019);
usleep(2000000);

toast("Exit in 3 Seconds", 'center', 3);
usleep(2200000);

--End