while getColor(631, 621) == 16054514 do

	tap(623, 558);
	usleep(1e6);
end