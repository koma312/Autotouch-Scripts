appActivate("com.kabam.marvelbattle");

toast("Arena Start", 2);
usleep(2000000);

function champ()
    usleep(1000000);
	touchDown(0, 714, 719);
	usleep(50000);
	touchMove(0, 439, 729);
	usleep(50000);
	touchUp(0, 493, 729);
	usleep(1500000); 
	tap(271, 1430);
end

champ()
champ()
champ()

-- while getColor(1168, 1330) == 1974051 do tap(1268, 1191); usleep(1000000); end




function tapConfirm()
     buttonColor = getColor(914, 1010);
     if buttonColor == 3223343 then
	     tap(1756, 1445);
	     usleep(1000000);
     end
usleep(3000000);
end

function fight()

	fightColor = getColor(1082, 76);
	if fightColor == 2302498 then 
		tap(1654, 354); else
		usleep(500000);
     end

usleep(300000);
tap(1654, 354);
usleep(500000);
tap(1654, 354);
usleep(2000000);
--nextColor = getColor(1000, 670);
--while nextColor == 13158600 do
		tap(1304, 1212); 
		usleep(2000000);
--end
end

--[[
function nextFight()

	tap(1593, 927);
	usleep(500000);
	tap(1593, 927);
	usleep(500000);
	tap(1593, 927);
	usleep(2000000);

	nextFightColor = getColor(1558, 547);
	while nextFightColor == 3223343 do
		tap(1370, 1230);
		usleep(1000000);
	end
end
--]]


usleep(3000000);
tap(1304, 1224);
usleep(2000000);

tapConfirm()
usleep(2500000);
tap(1756, 1445);

usleep(10000000);
toast("Fight One", 2);
fight()

--usleep(2000000);
--toast("Next Fight", 2);
--nextFight()

usleep(5000000);
toast("Fight Two", 2);
fight()

usleep(5000000);
toast("Fight Three", 2);
fight()

usleep(5000000);

--[[
nextSeries = getColor(1549, 1190);
if nextSeries == 1843494 then
	tap(1288, 1213); -- Anywhere to continue
else
	usleep(1000000);
end
--]]

-- Tap Next Series
while getColor(1549, 1190) == 1843494 do 
	tap(1310, 1447);
	usleep(1000000); 
end


function clearChamps()
     helpColor = getColor(638, 595);
     while helpColor == 16185842 do
	     tap(661, 592);
	     usleep(4000000);
end
end

toast("Clearing", 8);
usleep(6000000);

clearChamps()

toast("End of script", 2);
usleep(2000000);
















