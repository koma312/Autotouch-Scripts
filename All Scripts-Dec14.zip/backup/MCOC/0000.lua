appActivate("com.kabam.marvelbattle");

toast("Arena Start", 2);
usleep(2000000);

function champ()
    usleep(1000000);
	touchDown(0, 714, 719);
	usleep(50000);
	touchMove(0, 439, 729);
	usleep(50000);
	touchUp(0, 493, 729);
	usleep(1500000); 
	tap(271, 1430);
end

champ()
champ()
champ()


buttonColor = getColor(914, 1010);
if buttonColor == 3223343 then
tap(1756, 1445);
else
usleep(500000);
end

usleep(3000000);

buttonColor = getColor(914, 1010);
if buttonColor == 3223343 then
tap(1756, 1445);
else
usleep(500000);
end

usleep(3000000);

buttonColor = getColor(1826, 1129);
if buttonColor == 2500653 then
tap(1756, 1445);
else
usleep(500000);
end

--
usleep(8000000);
--

fightColor = getColor(1013, 93);
while buttonColor == 10205338 do
tap(1756, 1445);
usleep(500000);
end

usleep(5000000);

nextColor = getColor(1003, 672);
if buttonColor == 13158600 then
tap(1438, 1204);
else
usleep(500000);
end

usleep(5000000);

fightColor = getColor(1013, 93);
while buttonColor == 10205338 do
tap(1756, 1445);
usleep(500000);
end

usleep(5000000);

nextColor = getColor(1003, 672);
if buttonColor == 13158600 then
tap(1438, 1204);
else
usleep(500000);
end

usleep(5000000);

fightColor = getColor(1013, 93);
while buttonColor == 10205338 do
tap(1756, 1445);
usleep(500000);
end

usleep(5000000);

nextColor = getColor(1003, 672);
if buttonColor == 13158600 then
tap(1438, 1204);
else
usleep(500000);
end

usleep(15000000);

nextSeries = getColor(1288, 1442);
if buttonColor == 16777215 then
tap(1335, 1445);
else
usleep(500000);
end

usleep(6000000);

function clearChamps()
tap(661, 596);
usleep(1000000);
tap(36, 996);
usleep(4000000);
end

clearChamps()
clearChamps()
clearChamps()

usleep(2000000);





