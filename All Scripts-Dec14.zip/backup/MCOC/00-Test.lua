appActivate("com.kabam.marvelbattle");
usleep(1000000);

function guns()

	usleep(750000);
	touchDown(0, 714, 719);
	usleep(100000);
	touchMove(0, 439, 729);
	usleep(100000);
	touchUp(0, 493, 729);
	usleep(500000); 
	tap(271, 1430);
end

	for i=3,1,-1 do guns()
end

usleep(5000000);
tap(1356, 1153);
usleep(1000000);

-- MENU BULLSHIT --

bullShit = getColor(443, 93);

	while bullShit == 7012352 do
	
		repeat
			tap(1356, 1153);
			usleep(1000000); 
			tap(1809, 1466);
			usleep(3000000); 
		until

	bullShit ~= 7012352
end

usleep(4000000); 

-- AUTOFIGHT --

myColor = getColor(1214, 1454);

	while myColor ~= 16777215 do
	
		repeat 
			tap(1434, 1208);
			usleep(3000000); 
		until

	myColor == 16777215
end

usleep(3000000); 
tap(1327, 1445);
usleep(5000000); 
toast('Clearing', 3); 

function clearChamps()

	tap(661, 596);
	usleep(1000000);
	tap(36, 996);
	usleep(3000000);
end

	for i=3,1,-1 do clearChamps()
end








































