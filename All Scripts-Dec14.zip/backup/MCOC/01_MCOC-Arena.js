const { getColor, touchDown, touchMove, touchUp, usleep, appActivate, keyDown, keyUp, toast, } = at

appActivate("com.kabam.marvelbattle");

function tap(x, y) {
    touchDown(0, x, y)
    usleep(2e4)
    touchUp(0, x, y)
    usleep(3e4)
}


toast("Arena Start", 2);
usleep(2000000);

function champ() {
    usleep(1000000);
	touchDown(0, 714, 719);
	usleep(50000);
	touchMove(0, 439, 729);
	usleep(50000);
	touchUp(0, 493, 729);
	usleep(1500000); 
	tap(271, 1430);
}

champ()
champ()
champ()


usleep(3600000); tap(1268, 1191);

function tapConfirm(){
     buttonColor = getColor(914, 1010);
     while (buttonColor)==3223343 do
	     tap(1756, 1445);
	     usleep(1000000)
}

tapConfirm()
tapConfirm()
tapConfirm()

function fight(){

	fightColor = getColor(1082, 76);
     while (fightColor)==2302498 do 
		tap(1654, 354);
		usleep(2e6);
}



function nextFight(){

      nextFightColor1 = getColor(1001, 672);
      nextFightColor2 = getColor(1750, 1320);

while (nextFightColor1)==13158600 and
          (nextFightColor2)==3157806 do
			usleep(2e6);
      end

		tap(1285, 1211);
		usleep(2e6);
		toast('all good');


}

/*
function fightNext()

myColor = getColor(670,1103);

if myColor == 3390094 then
    tap(519,1067);
else
    usleep(500000);
end

*/




toast("Fight One", 5);
fight()
usleep(4e6); 
toast("Next Fight", 5);
nextFight()
usleep(4e6); 
toast("Fight Two", 5);
fight()
usleep(4e6); 
toast("Next Fight", 5);
nextFight()
usleep(4e6); 
toast(" Three", 5);
fight()
usleep(4e6); 
toast("Next Fight", 5);
nextFight()
usleep(4e6); 

toast("DEBUGGing Next Series in 5 seconds", 5);
usleep(5000000);
while getColor(1549, 1190)==1843494 do tap(1288, 1213); usleep(1000000); end

function clear()
     helpColor = getColor(638, 595);
     while (helpColor)==16185842 do
	     tap(661, 592);
	     usleep(4000000);
end
end

toast("Clearing", 8);

clear()
usleep(2e6); 
clear()
usleep(2e6); 
clear()
usleep(2e6); 

toast("End of script", 2);
usleep(2000000);
















