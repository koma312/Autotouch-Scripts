if getColor(1732, 1444) ~= 16777215 then repeat

	tap(1303, 1209);
	usleep(3e6);

until getColor(1732, 1444) == 16777215


	usleep(2e6); 
	tap(1403, 1456);
	usleep(6e6);
end


----

while getColor(631, 621) == 16054514 do

	tap(623, 558);
	usleep(2e6);
end

toast('</end>', 1);
usleep(1e6);
