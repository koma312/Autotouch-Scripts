toast("Arena Start", 2);
usleep(2e6);

function tap(x, y)

    touchDown(0, x, y);
    usleep(3e4);
    touchUp(0, x, y);
end

while getColor(631, 621) == 16054514 do

	tap(623, 558);
	usleep(1e6);
end

for i=3,1,-1 do

	usleep(1e6);
	touchDown(0, 714, 719);
	usleep(5e4);
	touchMove(0, 439, 729);
	usleep(5e4);
	touchUp(0, 493, 729);
	usleep(1e6); 
	tap(271, 1430);
end

	usleep(7e6); 
	tap(1268, 1191);

for i=6,1,-1 do

	usleep(2e6);
	tap(1756, 1445);
end

	usleep(6e6);

-- if gc then -- for i=

while getColor(1732, 1444) ~= 16777215 do

	tap(1303, 1209);
	usleep(3e6);
end
	usleep(2e6); 
	tap(1403, 1456);
	usleep(6e6);

while getColor(631, 621) == 16054514 do

	tap(623, 558);
	usleep(2e6);
end

toast('</end>', 1);
usleep(1e6);
























