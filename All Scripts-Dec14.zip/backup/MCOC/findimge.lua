--local imagePath = "images/victory.PNG";
--local region = {696, 416, 391, 122};

myImage = findImage("images/node.png", 5, 0.99, nil, true);
    if myImage ~= nil then
    alert("Found");
else
    alert("Not Found");
end