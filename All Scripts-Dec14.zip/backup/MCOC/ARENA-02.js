// --------------------------------------
// Information of recording
// Time: 2021-10-13 17:26:13
// Resolution: 1536, 2048
// Front most app: Champions
// Orientation of front most app: LandscapeRight
// --------------------------------------

const { touchDown, touchMove, touchUp, usleep, appActivate, keyDown, keyUp } = at

appActivate("com.kabam.marvelbattle");


touchDown(4, 259.66, 1066.20);
usleep(125082.42);
touchUp(4, 259.66, 1066.20);
usleep(1649686.04);

touchDown(1, 380.31, 1038.54);
usleep(125357.33);
touchUp(1, 380.31, 1038.54);
usleep(484327.79);

touchDown(9, 831.19, 744.49);
usleep(32676.67);
touchMove(9, 806.66, 736.31);
usleep(8479.00);
touchMove(9, 797.44, 736.31);
usleep(8211.92);
touchMove(9, 789.28, 736.31);
usleep(7926.17);
touchMove(9, 781.09, 734.25);
usleep(8734.88);
touchMove(9, 770.88, 731.18);
usleep(8273.96);
touchMove(9, 758.59, 728.11);
usleep(8668.92);
touchMove(9, 747.34, 724.01);
usleep(7732.46);
touchMove(9, 736.09, 718.88);
usleep(8553.38);
touchMove(9, 723.84, 713.77);
usleep(8385.25);
touchMove(9, 712.59, 707.62);
usleep(8450.50);
touchMove(9, 700.31, 701.46);
usleep(8117.38);
touchMove(9, 689.06, 694.29);
usleep(8811.67);
touchMove(9, 677.84, 686.11);
usleep(7897.00);
touchMove(9, 667.59, 678.94);
usleep(8282.79);
touchMove(9, 656.34, 671.77);
usleep(8265.00);
touchMove(9, 647.16, 664.59);
usleep(8735.92);
touchMove(9, 640.00, 657.42);
usleep(8060.58);
touchMove(9, 632.84, 651.26);
usleep(8232.12);
touchMove(9, 626.72, 645.12);
usleep(8172.42);
touchMove(9, 621.59, 637.95);
usleep(8686.88);
touchMove(9, 616.50, 630.77);
usleep(8404.08);
touchMove(9, 612.41, 621.56);
usleep(8129.96);
touchMove(9, 608.31, 612.33);
usleep(8059.54);
touchMove(9, 604.22, 602.09);
usleep(8715.38);
touchMove(9, 601.16, 590.81);
usleep(8386.83);
touchMove(9, 598.09, 578.53);
usleep(8423.71);
touchMove(9, 595.00, 564.19);
usleep(7892.92);
touchMove(9, 591.94, 551.88);
usleep(8528.75);
touchMove(9, 588.88, 539.60);
usleep(8215.33);
touchMove(9, 584.78, 528.33);
usleep(8434.67);
touchMove(9, 579.69, 518.09);
usleep(8343.75);
touchMove(9, 575.59, 507.82);
usleep(8447.96);
touchMove(9, 571.50, 498.61);
usleep(8237.71);
touchMove(9, 568.44, 490.41);
usleep(8278.50);
touchMove(9, 564.34, 482.23);
usleep(8106.21);
touchMove(9, 560.25, 472.99);
usleep(9109.17);
touchMove(9, 555.16, 463.78);
usleep(7887.12);
touchMove(9, 550.03, 454.55);
usleep(8261.08);
touchMove(9, 544.91, 444.30);
usleep(8153.58);
touchMove(9, 539.81, 435.09);
usleep(8643.92);
touchMove(9, 534.69, 426.89);
usleep(8549.29);
touchMove(9, 530.59, 419.72);
usleep(8509.67);
touchMove(9, 526.50, 414.61);
usleep(7657.25);
touchMove(9, 523.44, 411.52);
usleep(8684.50);
touchMove(9, 519.34, 409.48);
usleep(8256.67);
touchMove(9, 516.28, 408.45);
usleep(8762.08);
touchMove(9, 513.22, 407.44);
usleep(7598.00);
touchMove(9, 510.16, 406.41);
usleep(8689.21);
touchMove(9, 508.12, 406.41);
usleep(8319.42);
touchMove(9, 505.03, 406.41);
usleep(8587.29);
touchMove(9, 503.00, 406.41);
usleep(7975.46);
touchMove(9, 500.97, 406.41);
usleep(8434.58);
touchMove(9, 498.91, 406.41);
usleep(10085.46);
touchMove(9, 496.88, 406.41);
usleep(7291.42);
touchMove(9, 493.81, 405.38);
usleep(7333.12);
touchMove(9, 491.75, 404.34);
usleep(8893.50);
touchMove(9, 487.66, 401.27);
usleep(7882.50);
touchMove(9, 483.56, 397.17);
usleep(10486.58);
touchMove(9, 478.47, 391.03);
usleep(5999.12);
touchMove(9, 471.31, 384.89);
usleep(8756.17);
touchUp(9, 465.16, 372.59);
usleep(1233236.96);

touchDown(7, 805.62, 713.77);
usleep(41596.58);
touchMove(7, 790.28, 714.80);
usleep(8523.29);
touchMove(7, 785.19, 714.80);
usleep(8622.21);
touchMove(7, 779.03, 714.80);
usleep(8269.79);
touchMove(7, 771.88, 714.80);
usleep(7861.62);
touchMove(7, 764.72, 714.80);
usleep(8600.79);
touchMove(7, 755.53, 714.80);
usleep(8013.88);
touchMove(7, 747.34, 714.80);
usleep(9372.25);
touchMove(7, 738.16, 714.80);
usleep(7433.83);
touchMove(7, 731.00, 714.80);
usleep(8420.88);
touchMove(7, 723.84, 714.80);
usleep(8178.88);
touchMove(7, 716.69, 714.80);
usleep(8588.12);
touchMove(7, 709.53, 714.80);
usleep(8361.67);
touchMove(7, 702.38, 714.80);
usleep(8397.79);
touchMove(7, 695.22, 714.80);
usleep(9255.54);
touchMove(7, 687.03, 714.80);
usleep(7550.42);
touchMove(7, 679.88, 714.80);
usleep(7880.33);
touchMove(7, 671.69, 714.80);
usleep(8855.54);
touchMove(7, 662.50, 713.77);
usleep(7858.33);
touchMove(7, 652.28, 712.73);
usleep(8688.42);
touchMove(7, 643.06, 709.66);
usleep(8337.46);
touchMove(7, 632.84, 706.59);
usleep(8158.00);
touchMove(7, 620.56, 702.49);
usleep(8334.96);
touchMove(7, 608.31, 697.36);
usleep(8660.58);
touchMove(7, 596.03, 692.25);
usleep(8245.71);
touchMove(7, 583.78, 686.11);
usleep(8333.54);
touchMove(7, 570.47, 680.98);
usleep(8512.50);
touchMove(7, 558.22, 675.84);
usleep(8457.79);
touchMove(7, 541.84, 670.73);
usleep(7836.92);
touchMove(7, 530.59, 667.66);
usleep(8224.54);
touchMove(7, 516.28, 663.56);
usleep(8188.96);
touchMove(7, 501.97, 660.49);
usleep(8634.92);
touchMove(7, 489.72, 657.42);
usleep(8284.00);
touchMove(7, 477.44, 654.35);
usleep(8306.00);
touchMove(7, 466.19, 652.29);
usleep(8103.04);
touchMove(7, 454.94, 650.25);
usleep(8784.58);
touchMove(7, 444.72, 649.22);
usleep(7982.17);
touchMove(7, 436.53, 648.19);
usleep(8579.71);
touchMove(7, 428.38, 647.18);
usleep(7915.75);
touchMove(7, 422.22, 646.15);
usleep(8880.54);
touchMove(7, 417.12, 645.12);
usleep(8102.42);
touchMove(7, 413.03, 644.09);
usleep(8167.33);
touchMove(7, 411.00, 642.05);
usleep(8426.00);
touchMove(7, 408.94, 640.01);
usleep(8307.46);
touchMove(7, 407.91, 636.91);
usleep(8219.71);
touchMove(7, 407.91, 632.84);
usleep(8361.21);
touchMove(7, 406.91, 627.70);
usleep(8172.00);
touchUp(7, 407.91, 616.43);
usleep(1325365.12);

touchDown(8, 822.00, 748.59);
usleep(50319.96);
touchMove(8, 803.59, 742.45);
usleep(8070.71);
touchMove(8, 796.44, 742.45);
usleep(8510.71);
touchMove(8, 788.25, 742.45);
usleep(8014.42);
touchMove(8, 777.00, 742.45);
usleep(8674.71);
touchMove(8, 762.69, 742.45);
usleep(8425.38);
touchMove(8, 747.34, 742.45);
usleep(7960.25);
touchMove(8, 731.00, 742.45);
usleep(8284.50);
touchMove(8, 713.62, 742.45);
usleep(8829.88);
touchMove(8, 696.22, 742.45);
usleep(7918.54);
touchMove(8, 678.84, 742.45);
usleep(8596.54);
touchMove(8, 660.44, 742.45);
usleep(8048.50);
touchMove(8, 644.09, 742.45);
usleep(8320.04);
touchMove(8, 628.75, 743.48);
usleep(8677.67);
touchMove(8, 614.44, 744.49);
usleep(8472.71);
touchMove(8, 600.12, 745.52);
usleep(8079.46);
touchMove(8, 585.81, 747.56);
usleep(8266.08);
touchMove(8, 572.53, 748.59);
usleep(8215.88);
touchMove(8, 559.22, 748.59);
usleep(10678.88);
touchMove(8, 545.94, 748.59);
usleep(5993.17);
touchMove(8, 533.69, 748.59);
usleep(8603.75);
touchMove(8, 520.38, 748.59);
usleep(8235.75);
touchMove(8, 508.12, 748.59);
usleep(8127.58);
touchMove(8, 496.88, 748.59);
usleep(8379.75);
touchMove(8, 486.66, 748.59);
usleep(8322.71);
touchMove(8, 477.44, 748.59);
usleep(8549.71);
touchMove(8, 467.22, 748.59);
usleep(8159.00);
touchMove(8, 459.03, 748.59);
usleep(8281.38);
touchMove(8, 450.84, 745.52);
usleep(8493.08);
touchMove(8, 445.75, 739.38);
usleep(8248.67);
touchMove(8, 441.66, 731.18);
usleep(8476.71);
touchMove(8, 439.62, 719.91);
usleep(7943.92);
touchUp(8, 437.56, 705.56);
usleep(1608964.21);

touchDown(10, 192.19, 1399.17);
usleep(133438.04);
touchUp(10, 192.19, 1399.17);
usleep(6950673.46);

touchDown(11, 1361.81, 1210.66);
usleep(191089.42);
touchUp(11, 1361.81, 1210.66);
usleep(1650366.79);

touchDown(3, 1849.50, 1425.82);
usleep(158631.46);
touchUp(3, 1849.50, 1425.82);
usleep(7440465.50);

touchDown(3, 1791.22, 1457.58);
usleep(143069.79);
touchUp(3, 1791.22, 1457.58);
usleep(4007277.46);

touchDown(3, 1837.22, 1464.75);
usleep(176387.38);
touchUp(3, 1837.22, 1464.75);
usleep(16955842.04);

touchDown(5, 1555.03, 970.92);
usleep(79151.67);
touchUp(5, 1555.03, 970.92);
usleep(666739.83);

touchDown(5, 1549.94, 971.95);
usleep(91417.58);
touchUp(5, 1549.94, 971.95);
usleep(375270.08);

touchDown(5, 1527.44, 948.38);
usleep(116628.00);
touchUp(5, 1527.44, 948.38);
usleep(600784.58);

touchDown(5, 1558.09, 913.55);
usleep(124211.38);
touchUp(5, 1558.09, 913.55);
usleep(1083019.42);

touchDown(5, 1540.72, 903.30);
usleep(108990.96);
touchUp(5, 1540.72, 903.30);
usleep(591235.71);

touchDown(5, 1537.66, 907.41);
usleep(125249.25);
touchUp(5, 1537.66, 907.41);
usleep(2304499.50);

touchDown(5, 1550.94, 889.99);
usleep(120512.12);
touchUp(5, 1550.94, 889.99);
usleep(293462.12);

touchDown(5, 1562.19, 888.96);
usleep(132431.79);
touchUp(5, 1562.19, 888.96);
usleep(390979.71);

touchDown(5, 1536.62, 928.92);
usleep(142071.92);
touchUp(5, 1536.62, 928.92);
usleep(283124.00);

touchDown(11, 1388.38, 1213.73);
usleep(117074.75);
touchUp(11, 1388.38, 1213.73);
usleep(16854935.33);

touchDown(6, 1625.59, 969.89);
usleep(163323.00);
touchUp(6, 1625.59, 969.89);
usleep(799604.12);

touchDown(6, 1619.44, 953.51);
usleep(116714.08);
touchUp(6, 1619.44, 953.51);
usleep(833007.75);

touchDown(5, 1563.22, 856.17);
usleep(124771.54);
touchUp(5, 1563.22, 856.17);
usleep(1558845.38);

touchDown(5, 1542.78, 877.69);
usleep(133600.67);
touchUp(5, 1542.78, 877.69);
usleep(366463.04);

touchDown(2, 1576.50, 751.66);
usleep(99930.38);
touchUp(2, 1576.50, 751.66);
usleep(1808638.29);

touchDown(2, 1553.00, 783.42);
usleep(144215.75);
touchUp(2, 1553.00, 783.42);
usleep(364264.04);

touchDown(5, 1555.03, 886.90);
usleep(133497.75);
touchUp(5, 1555.03, 886.90);
usleep(708253.33);

touchDown(2, 1563.22, 799.83);
usleep(149631.71);
touchUp(2, 1563.22, 799.83);
usleep(776880.96);

touchDown(2, 1560.16, 841.83);
usleep(215522.67);
touchUp(2, 1560.16, 841.83);
usleep(833063.04);

touchDown(2, 1572.41, 801.87);
usleep(99883.96);
touchMove(2, 1585.72, 798.80);
usleep(8237.04);
touchMove(2, 1586.72, 800.86);
usleep(8749.58);
touchMove(2, 1587.75, 803.93);
usleep(7609.21);
touchMove(2, 1587.75, 808.03);
usleep(8703.38);
touchMove(2, 1587.75, 811.10);
usleep(8340.58);
touchMove(2, 1587.75, 815.20);
usleep(8252.54);
touchMove(2, 1587.75, 819.28);
usleep(8466.96);
touchMove(2, 1585.72, 822.38);
usleep(8205.25);
touchUp(2, 1577.53, 830.55);
usleep(925337.83);

touchDown(11, 1408.84, 1203.49);
usleep(124828.00);
touchUp(11, 1408.84, 1203.49);
usleep(16034949.75);

touchDown(4, 1660.34, 759.87);
usleep(108212.00);
touchUp(4, 1660.34, 759.87);
usleep(758707.75);

touchDown(2, 1623.53, 847.97);
usleep(99791.67);
touchUp(2, 1623.53, 847.97);
usleep(841217.00);

touchDown(2, 1608.22, 822.38);
usleep(133475.54);
touchUp(2, 1608.22, 822.38);
usleep(650277.62);

touchDown(2, 1589.81, 834.66);
usleep(149623.83);
touchUp(2, 1589.81, 834.66);
usleep(1292110.33);

touchDown(2, 1580.59, 860.27);
usleep(174608.04);
touchUp(2, 1580.59, 860.27);
usleep(1008940.67);

touchDown(2, 1576.50, 860.27);
usleep(174853.00);
touchUp(2, 1576.50, 860.27);
usleep(283195.12);

touchDown(2, 1577.53, 832.62);
usleep(200156.42);
touchUp(2, 1577.53, 832.62);
usleep(1675681.88);

touchDown(1, 1549.94, 734.25);
usleep(166505.54);
touchUp(1, 1549.94, 734.25);
usleep(249635.25);

touchDown(2, 1558.09, 797.77);
usleep(208178.54);
touchUp(2, 1558.09, 797.77);
usleep(1125618.29);

touchDown(2, 1532.56, 773.18);
usleep(233009.67);
touchUp(2, 1532.56, 773.18);
usleep(575349.96);

touchDown(2, 1549.94, 822.38);
usleep(241703.08);
touchUp(2, 1549.94, 822.38);
usleep(416866.92);

touchDown(9, 1516.19, 1308.00);
usleep(133039.29);
touchUp(9, 1516.19, 1308.00);
usleep(22340442.83);

touchDown(7, 1362.84, 1466.79);
usleep(111724.79);
touchUp(7, 1362.84, 1466.79);
usleep(8240504.29);

touchDown(8, 660.44, 575.46);
usleep(134745.88);
touchUp(8, 660.44, 575.46);
usleep(1216729.25);

touchDown(10, 186.06, 1061.09);
usleep(216612.50);
touchUp(10, 186.06, 1061.09);
usleep(2712989.75);

touchDown(8, 654.31, 593.88);
usleep(154239.58);
touchUp(8, 654.31, 593.88);
usleep(1309851.96);

touchDown(10, 208.56, 1074.40);
usleep(264743.79);
touchUp(10, 208.56, 1074.40);
usleep(2790758.88);

touchDown(8, 658.41, 586.71);
usleep(135521.04);
touchMove(8, 650.22, 592.88);
usleep(7746.25);
touchMove(8, 645.12, 592.88);
usleep(8167.42);
touchUp(8, 640.00, 591.84);
usleep(1127007.08);

touchDown(10, 175.84, 1085.67);
usleep(273066.38);
touchUp(10, 175.84, 1085.67);
