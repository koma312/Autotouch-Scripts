function guns()

tap(300, 1400);
usleep(500000);

tap(300, 1200);
usleep(500000);

touchDown(1, 300, 1000);
usleep(150000);
touchUp(1, 300, 1000);

usleep(1000000);

end

--wait
--toast("Waiting 5s");
usleep(2500000);

-- Send first rotation

--toast("Sending first rotation");
usleep(1000000);

touchDown(0, 300, 1000);
usleep(150000);
touchUp(0, 300, 1000);

usleep(3000000);

tap(300, 1200);
usleep(5000000);

tap(300, 1400);
usleep(4000000);

--do guns
usleep(100000);

for i=15,1,-1 do guns()
end




























