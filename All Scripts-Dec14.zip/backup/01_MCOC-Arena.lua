appActivate("com.kabam.marvelbattle");

toast("Arena Start", 2);
usleep(2000000);

function champ()
    usleep(1000000);
	touchDown(0, 714, 719);
	usleep(50000);
	touchMove(0, 439, 729);
	usleep(50000);
	touchUp(0, 493, 729);
	usleep(1500000); 
	tap(271, 1430);
end

champ()
champ()
champ()

--[[
chooseArena = getColor(1168, 1330);
while chooseArena == 1974051 do
tap(1268, 1191);
end

choose third
usleep(2500000); tap(1268, 1191);
--]]

while getColor(1168, 1330) == 1974051 do tap(1268, 1191); usleep(1000000); end

function tapConfirm()
     buttonColor = getColor(914, 1010);
     while buttonColor == 3223343 do
	     tap(1756, 1445);
	     usleep(1000000);
     end
end

tapConfirm()
tapConfirm()
tapConfirm()

function fight()

	fightColor = getColor(1082, 76);
     while fightColor == 2302498 do 
		tap(1654, 354);
		usleep(1000000);
     end
end


-- const [result, error] = getColor(1376, 526); // 3223343, 0x312F2F

// Original colors:     {x: 1003, y: 671};     {x: 1462, y: 565}
const [result1, error1] = getColors([
    {x: 1003, y: 671},
    {x: 1462, y: 565}])

--[[
function nextFight()

	nextFightColor = getColor(1558, 547);
	while nextFightColor == 3223343 do
		tap(1370, 1230);
		usleep(1000000);
	end
end
--]]

toast("Fight One", 5);
fight()
toast("Next Fight", 5);
nextFight()
toast("Fight Two", 5);
fight()
toast("Next Fight", 5);
nextFight()
toast("Fight Three", 5);
fight()
toast("Next Fight", 5);
nextFight()

--[[
nextSeries = getColor(1549, 1190);
if nextSeries == 1843494 then
	tap(1288, 1213); -- Anywhere to continue
else
	usleep(1000000);
end
--]]

-- Tap Next Series
while getColor(1549, 1190) == 1843494 do tap(1288, 1213); usleep(1000000); end

function clear()
     helpColor = getColor(638, 595);
     while helpColor == 16185842 do
	     tap(661, 592);
	     usleep(4000000);
end
end

toast("Clearing", 8);
--usleep(2000000);

clear()
clear()
clear()

toast("End of script", 2);
usleep(2000000);
















