for (let i = 0; i < 10; i++) {
    console.log(`>>>>>>>AAA loop to ${i}`)
}
