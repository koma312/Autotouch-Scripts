local results = findImage("images/node.png", 0, 0.6, nil, true, 1);

	if #results > 0 then
	touchDown(results[1][1], results[1][2]);
	usleep(3e4);
	touchUp(results[1][1], results[1][2]);
	toast('you are have a great success', 4);
else
    toast('Failure', 5);
end









































