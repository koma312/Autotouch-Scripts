targetImagePath = 'images/node.png'

local result = findImage(

	targetImagePath,
	0,
	0.6,
	null,
	true,
	1,
)

    

toast('found', 5);









































