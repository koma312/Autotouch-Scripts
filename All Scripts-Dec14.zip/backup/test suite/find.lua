-- const { touchDown, touchMove, touchUp, usleep, appActivate, keyDown, keyUp, tap, toast, } = at

const targetImagePath = 'images/node.png'

const options = {

    targetImagePath: targetImagePath,
    count: 0,
    threshold: 0.6,
    region: null,
    debug: true, 
    method: 1,
}

findImage({

    options,
    duration: 30,
    interval: 10000,
    exitIfFound: true,
    errorCallback: error => {alert(error)},
    block: true, 
})

toast('found', 5);





































