const { touchDown, touchMove, touchUp, usleep, appActivate, keyDown, keyUp, toast, tap } = at

toast('Attacking', 'center', 3);
usleep(3400000);

//Select Golems

toast('Golems', 'bottom', 2);
tap(569, 1417);
usleep(1000000);

//Deploy Golems

tap(935, 31);
usleep(500000);
tap(1135, 39);
usleep(1500000);

//Select Pekka

toast('Pekka', 'bottom', 2);
tap(392, 1409);
usleep(1000000);

//Deploy Pekka's

tap(935, 31);
usleep(500000);
tap(1135, 39);
usleep(1500000);

//Select Giants

toast('Giants', 'bottom', 2);
tap(216, 1403);
usleep(1000000);

//Deploy Giants

tap(935, 31);
usleep(250000);
tap(1135, 39);
usleep(1500000);

//Select Witches

toast('Witches', 'bottom', 2);
tap(737, 1387);
usleep(1000000);

//Deploy Witches

tap(915, 39);
usleep(250000);

tap(1127, 37);
usleep(4200000);

toast('More Witches', 'top', 3);

tap(1023, 20);
usleep(250000);

tap(1023, 20);
usleep(250000);

tap(1023, 20);
usleep(250000);

tap(1023, 20);
usleep(250000);

tap(1023, 20);
usleep(250000);

tap(1023, 20);
usleep(250000);

tap(1023, 20);
usleep(250000);

tap(1023, 20);
usleep(1500000);

//Select Grand Warden

toast('Grand Warden', 'bottom', 2);
tap(1268, 1363);
usleep(250000);

//Deploy Grand Warden

tap(1023, 20);
usleep(1500000);

//Select Jump Spell

toast('Jump', 'bottom', 2);
tap(1636, 1376);
usleep(1500000);

//Deploy Jump Spell

tap(1102, 290);
usleep(250000);
tap(940, 295);
usleep(1000000);

//Select Skeletons Spell

toast('Skeletons', 'bottom', 2);
tap(1814, 1386);
usleep(1000000);

//Deploy Skeletons Spell

tap(1025, 561);
usleep(1500000);

tap(1025, 561);
usleep(1500000);

tap(1025, 561);
usleep(1500000);

//Select Rage Spell

toast('RAGE', 'bottom', 2);
tap(1466, 1384);
usleep(1000000);

//Deploy Rage Spell

tap(1138, 375);
usleep(250000);
tap(899, 369);
usleep(1000000);

//Select King

toast('King Alfred', 'bottom', 2);
tap(936, 1369);
usleep(1000000);

//Deploy King

tap(858, 111);
usleep(1000000);

//Select Queen

toast('Queen Lagatha', 'bottom', 2);
tap(1096, 1380);
usleep(1000000);

//Deploy Queen

tap(1191, 98);
usleep(1000000);

//Hero Activation Delay

usleep(8200000);
toast('Activating Heroes', 'center', 4);

//Activate King

tap(936, 1369);
usleep(1000000);

//Activate Queen

tap(1096, 1380);

//Activate Grand Warden 

usleep(6800000);
tap(1023, 20);

usleep(1000000);
toast("End of Script", 'center', 5);










































