// --------------------------------------
// Information of recording
// Time: 2021-05-28 05:07:07
// Resolution: 1536, 2048
// Front most app: Clash of Clans
// Orientation of front most app: LandscapeRight
// --------------------------------------

const { touchDown, touchMove, touchUp, usleep, appActivate, keyDown, keyUp } = at

appActivate("com.supercell.magic");


touchDown(8, 589.91, 1397.13);
usleep(66517.58);
touchUp(8, 589.91, 1397.13);
usleep(1458895.92);

touchDown(3, 1027.50, -4.43);
usleep(91337.67);
touchUp(3, 1027.50, -4.43);
usleep(1342014.25);

touchDown(2, 417.12, 1389.96);
usleep(49977.12);
touchUp(2, 417.12, 1389.96);
usleep(816745.62);

touchDown(3, 1044.88, -10.59);
usleep(66911.25);
touchUp(3, 1044.88, -10.59);
usleep(1641504.75);

touchDown(8, 611.38, 1401.23);
usleep(58602.92);
touchUp(8, 611.38, 1401.23);
usleep(2700019.33);

touchDown(3, 1034.66, 2.74);
usleep(74783.71);
touchUp(3, 1034.66, 2.74);
usleep(758602.04);

touchDown(2, 426.31, 1361.27);
usleep(50015.12);
touchUp(2, 426.31, 1361.27);
usleep(1291502.79);

touchDown(3, 1023.41, -2.39);
usleep(108700.17);
touchUp(3, 1023.41, -2.39);
usleep(2170669.04);

touchDown(11, 254.56, 1375.62);
usleep(46196.00);
touchUp(11, 254.56, 1375.62);
usleep(1358240.62);

touchDown(3, 1027.50, 0.68);
usleep(99920.04);
touchUp(3, 1027.50, 0.68);
usleep(491939.88);

touchDown(3, 1030.56, 19.12);
usleep(66827.12);
touchUp(3, 1030.56, 19.12);
usleep(799800.92);

touchDown(6, 1466.09, 1406.34);
usleep(67145.92);
touchUp(6, 1466.09, 1406.34);
usleep(2570369.79);

touchDown(5, 1061.22, 284.48);
usleep(70839.42);
touchUp(5, 1061.22, 284.48);
usleep(1650310.50);

touchDown(10, 1061.22, 406.41);
usleep(83263.92);
touchUp(10, 1061.22, 406.41);
usleep(2798923.67);

touchDown(9, 762.69, 1376.65);
usleep(43163.79);
touchUp(9, 762.69, 1376.65);
usleep(1066730.88);

touchDown(3, 1041.81, -11.60);
usleep(58404.04);
touchUp(3, 1041.81, -11.60);
usleep(583411.62);

touchDown(3, 1058.16, -3.42);
usleep(49739.04);
touchUp(3, 1058.16, -3.42);
usleep(509796.67);

touchDown(3, 1054.06, -5.46);
usleep(15594.50);
touchUp(3, 1054.06, -5.46);
usleep(500056.58);

touchDown(3, 1051.00, -2.39);
usleep(57937.54);
touchUp(3, 1051.00, -2.39);
usleep(508799.46);

touchDown(3, 1042.81, 7.85);
usleep(49824.62);
touchUp(3, 1042.81, 7.85);
usleep(491475.67);

touchDown(3, 1030.56, 9.91);
usleep(49748.83);
touchUp(3, 1030.56, 9.91);
usleep(558863.17);

touchDown(3, 1033.62, 12.98);
usleep(58265.67);
touchUp(3, 1033.62, 12.98);
usleep(533509.96);
touchUp(3, 1037.72, 15.02);
usleep(733068.08);

touchDown(3, 1044.88, 0.68);
usleep(66619.58);
touchUp(3, 1044.88, 0.68);
usleep(616915.25);

touchDown(3, 1032.59, 8.88);
usleep(50079.21);
touchUp(3, 1032.59, 8.88);
usleep(525128.54);

touchDown(3, 1033.62, 20.16);
usleep(66559.04);
touchUp(3, 1033.62, 20.16);
usleep(550112.12);

touchDown(3, 1040.78, 20.16);
usleep(133522.08);
touchUp(3, 1040.78, 20.16);
usleep(591625.42);

touchDown(3, 1056.12, 30.40);
usleep(66368.33);
touchUp(3, 1056.12, 30.40);
usleep(1600369.17);

touchDown(1, 1318.88, 1414.55);
usleep(58308.08);
touchUp(1, 1318.88, 1414.55);
usleep(716714.83);

touchDown(10, 1069.41, 356.20);
usleep(41406.62);
touchUp(10, 1069.41, 356.20);
usleep(2883720.00);

touchDown(4, 1075.53, 490.41);
usleep(58819.75);
touchUp(4, 1075.53, 490.41);
usleep(1874706.62);

touchDown(7, 1638.88, 1399.17);
usleep(50199.96);
touchUp(7, 1638.88, 1399.17);
usleep(966417.54);

touchDown(4, 1058.16, 509.88);
usleep(58645.46);
touchUp(4, 1058.16, 509.88);
usleep(1774809.67);

touchDown(8, 966.16, 1374.59);
usleep(50074.38);
touchUp(8, 966.16, 1374.59);
usleep(2145953.75);

touchDown(2, 878.22, 68.30);
usleep(54187.38);
touchUp(2, 878.22, 68.30);
usleep(733799.08);

touchDown(11, 1113.38, 1381.76);
usleep(58142.67);
touchUp(11, 1113.38, 1381.76);
usleep(708142.58);

touchDown(6, 1213.56, 44.74);
usleep(100094.92);
touchUp(6, 1213.56, 44.74);
usleep(24950833.79);

touchDown(8, 973.31, 1413.52);
usleep(51301.67);
touchUp(8, 973.31, 1413.52);
usleep(2829334.92);

touchDown(11, 1101.09, 1423.76);
usleep(46024.67);
touchUp(11, 1101.09, 1423.76);
