--
--
usleep(2000000);

function champ()

	usleep(1000000);
	touchDown(0, 714, 719);
	usleep(50000);
	touchMove(0, 439, 729);
	usleep(50000);
	touchUp(0, 493, 729);
	usleep(1000000); 
	tap(271, 1430);
end

champ()
champ()
champ()

-- choose third
usleep(2500000); tap(1268, 1191);

function tapConfirm()

	usleep(2500000);
	tap(1756, 1445);
	usleep(50000);
end

tapConfirm()
tapConfirm()
tapConfirm()

usleep(10000000);

function fight()

	fightColor = getColor(1082, 76);

	while fightColor == 2302498 do 
		tap(1654, 354);
		usleep(1000000);
end
end

function nextFight()

nextFightColor = getColor(1563, 858);

if nextFightColor == 1843494 then
	tap(1298, 1216);
else
	usleep(1000000);
end
end

fight()
nextFight()
fight()
nextFight()
fight()
nextFight()

nextSeries = getColor(1549, 1190);

if nextSeries == 1843494 then
	tap(1288, 1213); -- Anywhere to continue
else
	usleep(1000000);
end

function clear()

helpColor = getColor(638, 595);

if helpColor == 16185842 then
	tap(661, 592);
	usleep(4000000);
end
end

usleep(3200000);
Toast("Clearing", 8);

clear()
clear()
clear()

Toast("End of script", 2);
usleep(2000000);
















