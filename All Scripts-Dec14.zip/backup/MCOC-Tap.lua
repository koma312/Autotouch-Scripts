appActivate("com.kabam.marvelbattle");

usleep(500000);

function singleTap()

tap(624, 554);
usleep(2000000);

end

for i=9,1,-1 do singleTap()
end













