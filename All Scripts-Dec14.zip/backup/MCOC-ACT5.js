const { touchDown, touchMove, touchUp, usleep, appActivate, keyDown, keyUp, tap, toast, } = at
usleep(2000000);

//skip
toast('skipping', 'center', 3);
usleep(500000);
tap(1023, 1436);

usleep(3000000);

//tap node
toast('Tap Node', 'center', 5);
usleep(500000);
tap(1495, 757);
usleep(8000000);

//tap fight
toast('Tap Fight', 'center', 1);
usleep(500000);
tap(1789, 1422);
usleep(1600000);

//fight loading
toast('Loading', 'center', 8);
usleep(8800000);

//

function tapRight(){
usleep(300000);
tap(1614, 831);
usleep(300000);
}

//fighting
/*
toast('PERFORMING [4] TAPS', 'center', 2);

usleep(500000);

for (i=4;1;-1){
tapRight()
}
*/
//end


//toast('COMPLETED: [4] TAPS', 'center', 4);

tapRight()
tapRight()

tapRight()
tapRight()

tapRight()
tapRight()

tapRight()
tapRight()

tapRight()
toast('tapped 9x', 'center', 5)
//restart quest

usleep(6000000);

toast('Restarting Quest', 'center', 4);
usleep(2500000);
tap(1824, 1084);
usleep(2000000);
tap(1018, 875);

//waiting for load
toast('Loading', 'center', 8);
usleep(8000000);



