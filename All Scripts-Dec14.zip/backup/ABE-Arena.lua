usleep(500000);

toast("Starting Arena");
usleep(500000);
tap(1463, 1201);
usleep(8200000);

toast("Autoplaying");
usleep(500000);
tap(1982, 1467);
usleep(12000000);

toast("Victory");
usleep(500000);
tap(1953, 1451);
usleep(8000000);


toast("Rewards?");
usleep(500000);
tap(1953, 1451);

toast("Waiting 10");
usleep(10000000);

toast("End");
usleep(500000);















































