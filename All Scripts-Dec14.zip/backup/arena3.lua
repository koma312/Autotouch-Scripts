usleep(1e6);
toast("Arena Start", 2);

function champ()

	usleep(1e6);
	touchDown(0, 714, 719);
	usleep(5e4);
	touchMove(0, 439, 729);
	usleep(5e4);
	touchUp(0, 493, 729);
	usleep(5e5); 
	tap(271, 1430);
	usleep(1e6);
end
usleep(1e6);
champ()
champ()
champ()

usleep(3e6); 
tap(1268, 1191);
usleep(1e6); 
tap(1756, 1445);

usleep(2e6);
tap(1756, 1445);

usleep(2e6);
tap(1756, 1445);

usleep(2e6);
tap(1756, 1445);

usleep(2e6);
tap(1756, 1445);

-- Fighting

usleep(6e6);

while getColor(1732, 1444) ~= 16777215 do 
	tap(1303, 1209);
	usleep(1e6);
end
	usleep(1000000); 
	tap(1403, 1456);
	usleep(3e6);

--Clearing

while getColor(638, 595) ~= 16185842 do
	usleep(5e5);
end
	tap(661, 592);
	usleep(4e6);

while getColor(638, 595) ~= 16185842 do
	usleep(5e5);
end
	tap(661, 592);
	usleep(4e6);

while getColor(638, 595) ~= 16185842 do
	usleep(5e5);
end
	tap(661, 592);

toast('end');

usleep(1e6);













