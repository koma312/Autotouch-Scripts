usleep(5e5);

toast("Arena Start", 2);
usleep(2000000);

function champ()

	usleep(1000000);
	touchDown(0, 714, 719);
	usleep(50000);
	touchMove(0, 439, 729);
	usleep(50000);
	touchUp(0, 493, 729);
	usleep(1500000); 
	tap(271, 1430);
end

champ()
champ()
champ()


usleep(3e6); 
tap(1268, 1191);
usleep(1e6); 

-- while getColor(914, 1010) == 3223343 do

tap(1756, 1445);
usleep(3e6)

tap(1756, 1445);
usleep(3e6)

tap(1756, 1445);
usleep(6e6)

--end

while getColor(1732, 1444) ~= 16777215 do 
		tap(1303, 1209);
		usleep(1000000);

end

usleep(1000000); 
tap(1403, 1456);






















