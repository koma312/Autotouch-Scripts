appActivate("com.kabam.marvelbattle");

toast("Arena Start", 1);
usleep(1200000);

-- first champ

touchDown(11, 827.09, 737.32);
usleep(26752.38);
touchMove(11, 810.75, 727.08);
usleep(6649.04);
touchMove(11, 801.53, 727.08);
usleep(7945.33);
touchMove(11, 792.34, 725.04);
usleep(8751.71);
touchMove(11, 782.12, 722.98);
usleep(8014.50);
touchMove(11, 772.91, 721.97);
usleep(8596.21);
touchMove(11, 760.66, 720.94);
usleep(8380.92);
touchMove(11, 745.31, 718.88);
usleep(8387.42);
touchMove(11, 727.94, 715.80);
usleep(8080.04);
touchMove(11, 709.53, 710.70);
usleep(8288.79);
touchMove(11, 686.00, 702.49);
usleep(8113.75);
touchMove(11, 662.50, 694.29);
usleep(8768.96);
touchMove(11, 635.91, 685.08);
usleep(7935.38);
touchMove(11, 609.34, 674.84);
usleep(8578.88);
touchMove(11, 581.72, 665.60);
usleep(8146.79);
touchMove(11, 556.16, 656.39);
usleep(8663.33);
touchMove(11, 531.62, 649.22);
usleep(8258.42);
touchMove(11, 512.19, 645.12);
usleep(8205.12);
touchMove(11, 491.75, 644.09);
usleep(8067.83);
touchMove(11, 474.38, 644.09);
usleep(8800.79);
touchMove(11, 459.03, 644.09);
usleep(7848.46);
touchUp(11, 443.69, 647.18);
usleep(1000000);

-- second champ

touchDown(9, 827.09, 737.32);
usleep(26752.38);
touchMove(9, 810.75, 727.08);
usleep(6649.04);
touchMove(9, 801.53, 727.08);
usleep(7945.33);
touchMove(9, 792.34, 725.04);
usleep(8751.71);
touchMove(9, 782.12, 722.98);
usleep(8014.50);
touchMove(9, 772.91, 721.97);
usleep(8596.21);
touchMove(9, 760.66, 720.94);
usleep(8380.92);
touchMove(9, 745.31, 718.88);
usleep(8387.42);
touchMove(9, 727.94, 715.80);
usleep(8080.04);
touchMove(9, 709.53, 710.70);
usleep(8288.79);
touchMove(9, 686.00, 702.49);
usleep(8113.75);
touchMove(9, 662.50, 694.29);
usleep(8768.96);
touchMove(9, 635.91, 685.08);
usleep(7935.38);
touchMove(9, 609.34, 674.84);
usleep(8578.88);
touchMove(9, 581.72, 665.60);
usleep(8146.79);
touchMove(9, 556.16, 656.39);
usleep(8663.33);
touchMove(9, 531.62, 649.22);
usleep(8258.42);
touchMove(9, 512.19, 645.12);
usleep(8205.12);
touchMove(9, 491.75, 644.09);
usleep(8067.83);
touchMove(9, 474.38, 644.09);
usleep(8800.79);
touchMove(9, 459.03, 644.09);
usleep(7848.46);
touchUp(9, 443.69, 647.18);
usleep(1000000);

-- third champ

touchDown(5, 827.09, 737.32);
usleep(26752.38);
touchMove(5, 810.75, 727.08);
usleep(6649.04);
touchMove(5, 801.53, 727.08);
usleep(7945.33);
touchMove(5, 792.34, 725.04);
usleep(8751.71);
touchMove(5, 782.12, 722.98);
usleep(8014.50);
touchMove(5, 772.91, 721.97);
usleep(8596.21);
touchMove(5, 760.66, 720.94);
usleep(8380.92);
touchMove(5, 745.31, 718.88);
usleep(8387.42);
touchMove(5, 727.94, 715.80);
usleep(8080.04);
touchMove(5, 709.53, 710.70);
usleep(8288.79);
touchMove(5, 686.00, 702.49);
usleep(8113.75);
touchMove(5, 662.50, 694.29);
usleep(8768.96);
touchMove(5, 635.91, 685.08);
usleep(7935.38);
touchMove(5, 609.34, 674.84);
usleep(8578.88);
touchMove(5, 581.72, 665.60);
usleep(8146.79);
touchMove(5, 556.16, 656.39);
usleep(8663.33);
touchMove(5, 531.62, 649.22);
usleep(8258.42);
touchMove(5, 512.19, 645.12);
usleep(8205.12);
touchMove(5, 491.75, 644.09);
usleep(8067.83);
touchMove(5, 474.38, 644.09);
usleep(8800.79);
touchMove(5, 459.03, 644.09);
usleep(7848.46);
touchUp(5, 443.69, 647.18);
usleep(1000000);

-- find match

touchDown(1, 257, 1423);
usleep(50000);
touchUp(1, 257, 1423);

usleep(5000000);
usleep(3000000);

-- select bottom arena

touchDown(2, 1400, 1189);
usleep(50000);
touchUp(2, 1400, 1189);

usleep(2000000);
usleep(1500000);
-- continue

touchDown(3, 1807, 1469);
usleep(50000);
touchUp(3, 1807, 1469);

usleep(4000000);
usleep(3000000);
-- accept

touchDown(4, 1722, 1450);
usleep(50000);
touchUp(4, 1722, 1450);

usleep(2500000);
usleep(3000000);
-- continue

touchDown(5, 1809, 1459);
usleep(50000);
touchUp(5, 1809, 1459);

usleep(4600000);

toast("Fight in 05 Seconds", 4);
usleep(5000000);

-- fight one

toast("Fight One", 2);
usleep(50000);

touchDown(0, 1845, 870);
usleep(50000);
touchUp(0, 1845, 870);

usleep(3000000);

touchDown(0, 1845, 870);
usleep(50000);
touchUp(0, 1845, 870);

usleep(3000000);

touchDown(0, 1845, 870);
usleep(50000);
touchUp(0, 1845, 870);

usleep(1000000);

touchDown(0, 1845, 870);
usleep(50000);
touchUp(0, 1845, 870);

usleep(4000000);

-- next fight

toast("Tap Next Fight", 2);
usleep(2000000);

touchDown(5, 1288, 1213);
usleep(50000);
touchUp(5, 1288, 1213);

usleep(5000000);

-- fight two

toast("Fight Two", 2);
usleep(50000);

touchDown(0, 1845, 870);
usleep(50000);
touchUp(0, 1845, 870);

usleep(3000000);

touchDown(0, 1845, 870);
usleep(50000);
touchUp(0, 1845, 870);

usleep(3000000);

touchDown(0, 1845, 870);
usleep(50000);
touchUp(0, 1845, 870);

usleep(1000000);

touchDown(0, 1845, 870);
usleep(50000);
touchUp(0, 1845, 870);

usleep(4000000);


-- final fight

toast("Tap Final Fight", 2);
usleep(2000000);

touchDown(5, 1288, 1213);
usleep(50000);
touchUp(5, 1288, 1213);

usleep(5000000);

-- fight three

toast("Final Fight", 1);
usleep(50000);

touchDown(0, 1845, 870);
usleep(50000);
touchUp(0, 1845, 870);

usleep(3000000);

touchDown(0, 1845, 870);
usleep(50000);
touchUp(0, 1845, 870);

usleep(3000000);

touchDown(0, 1845, 870);
usleep(50000);
touchUp(0, 1845, 870);

usleep(1000000);

touchDown(0, 1845, 870);
usleep(50000);
touchUp(0, 1845, 870);

usleep(4000000);

-- tap anywhere

tap(1845, 870);
usleep(50000);

toast("Tap Anywhere", 5);

usleep(1000000);

tap(1845, 870);
usleep(50000);

touchDown(0, 1845, 870);
usleep(50000);
touchUp(0, 1845, 870);

usleep(500000);

tap(1845, 870);
usleep(50000);

tap(1845, 870);
touchDown(0, 1845, 870);
usleep(50000);
touchUp(0, 1845, 870);

usleep(500000);

tap(1845, 870);
usleep(50000);

tap(1845, 870);
touchDown(0, 1845, 870);
usleep(50000);
touchUp(0, 1845, 870);

usleep(500000);

tap(1845, 870);
usleep(50000);

usleep(8000000);

toast("Next Series in 03 seconds", 1);
usleep(1000000);

toast("Next Series in 02 seconds", 1);
usleep(1000000);

toast("Next Series in 01 seconds", 1);
usleep(1000000);

-- next series

toast("Tap Next Series", 2);

usleep(1000000);

touchDown(1, 1308, 1446);
usleep(50000);
touchUp(1, 1308, 1446);

usleep(2000000);

toast("Clearing in 03 seconds", 3);
usleep(3000000);

-- help 1

touchDown(3, 660, 600);
usleep(50000);
touchUp(3, 660, 600);

usleep(500000);

tap(158, 1019);
usleep(500000);
tap(158, 1019);

usleep(1000000);

-- help 2

touchDown(3, 660, 600);
usleep(50000);
touchUp(3, 660, 600);

usleep(500000);

tap(158, 1019);
usleep(500000);
tap(158, 1019);

usleep(1000000);

-- help 3

touchDown(3, 660, 600);
usleep(50000);
touchUp(3, 660, 600);

usleep(500000);

tap(158, 1019);
usleep(500000);
tap(158, 1019);

usleep(50000);

-- End



























