toast('Starting', 3);
usleep(1e6);

function tap(x, y)

    touchDown(0, x, y);
    usleep(3e4);
    touchUp(0, x, y);
end

tap(1419, 658);
usleep(6e6);

-- Zoom Out

touchDown(3, 400, 768);
touchDown(1, 1547, 768);
usleep(5e4);
touchMove(3, 700, 768);
touchMove(1, 1347, 768);
usleep(5e4);
touchUp(3, 700, 768);
touchUp(1, 1347, 768);

-- Scroll Up

usleep(1e6); 
touchDown(2, 1024, 868);
usleep(3e4);
touchMove(2, 1024, 568);
usleep(3e4);
touchUp(2, 1024, 568);
usleep(5e5);

-- Troop Slots

function s1()
	tap(238, 1391);
	usleep(5e5);
end

function s2()
	tap(420, 1399);
	usleep(5e5);
end

function s3()
	tap(582, 1399);
	usleep(5e5);
end

function s4()
	tap(762, 1403);
	usleep(5e5);
end

function s5()
	tap(917, 1388);
	usleep(5e5);
end

function s6()
	tap(1104, 1379);
	usleep(1e6);
end

function s7()
	tap(1296, 1404);
	usleep(5e5);
end

-- Map Positions

function fl()
	tap(991, 213);
	usleep(5e5);
end

function l()
	tap(1041, 175);
	usleep(5e5);
end

function m()
	tap(1090, 144);
	usleep(5e5);
end

function r()
	tap(1139, 175);
	usleep(5e5);
end

function fr()
	tap(1190, 213);
	usleep(5e5);
end

usleep(2e6);

s1() m()

usleep(2e6);

s3() m() l() r()

usleep(3e6);

s2() m()

usleep(5e5);

s4() m() l() r()

usleep(3e6);

s1() l() r()

usleep(2e6);

s2() fl() fr()

usleep(3e6);

s5() fl() fr() m() l() r()

usleep(5e5);

s1() m()

usleep(4e6);

s7() m()

usleep(3e6);

s6() m()

usleep(1e6);

s2() m()

usleep(1e7);


if getColor(1066, 1265) ~= 16777215 then repeat

	s7()
	usleep(7e6);
	usleep(5e5);
	usleep(5e5);
	usleep(5e5);
	usleep(5e5);
	usleep(5e5);
	usleep(5e5);
	usleep(5e5);
	usleep(5e5);

until getColor(1066, 1265) == 16777215

	usleep(2e6); 
	tap(1032, 1269);
end

	usleep(1e6);

repeat

tap(1616, 1042);
usleep(2e6);

until getColor(1554, 681) == 16777215

usleep(1e6); 

--[[

if getColor(331, 350) ~= 8890831 then repeat

	usleep(2e6); 

until getColor(331, 350) == 8890831 

	usleep(2e6);
	tap(1605, 1047);
	usleep(1e6);
end


--]]


toast('</end>', 3);














