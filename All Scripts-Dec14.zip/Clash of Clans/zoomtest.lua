-- Zoom Out







touchDown(3, 400, 768);
touchDown(1, 1547, 768);
usleep(5e4);
touchMove(3, 700, 768);
touchMove(1, 1347, 768);
usleep(5e4);
touchUp(3, 700, 768);
touchUp(1, 1347, 768);

-- Scroll Up

usleep(1e6); 
touchDown(2, 1024, 868);
usleep(3e4);
touchMove(2, 1024, 568);
usleep(3e4);
touchUp(2, 1024, 568);
usleep(1e6);
toast('end');



































