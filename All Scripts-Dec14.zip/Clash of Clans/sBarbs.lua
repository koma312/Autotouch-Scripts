toast('Starting sBarbs.js', 3);
usleep(1e6);

-- Zoom Out

touchDown(0, 470, 890);
touchDown(1, 1605, 651);
usleep(5e4);
touchMove(0, 846, 840);
touchMove(1, 1194, 835);
usleep(5e4);
touchUp(0, 846, 840);
touchUp(1, 1194, 835);

-- Scroll Up

usleep(1e6); 
touchDown(2, 1000, 400);
usleep(3e4);
touchMove(2, 1000, 400);
usleep(3e4);
touchUp(2, 1000, 900);
--

-- select sbarbs
tap(228, 1401);
usleep(5e5);

tap(1000, 100);
usleep(5e5);
tap(1050, 150);
usleep(5e5);


tap(1900, 700);
usleep(5e5);

--[[
// Original colors:     {x: 1002, y: 81};     {x: 1061, y: 110};     {x: 1130, y: 157};     {x: 1216, y: 206};     {x: 1262, y: 243};     {x: 1325, y: 298};     {x: 1380, y: 336};     {x: 1458, y: 376};     {x: 1512, y: 446};     {x: 1574, y: 467};     {x: 1641, y: 532};     {x: 1713, y: 599};     {x: 1777, y: 630};     {x: 1833, y: 674};     {x: 1904, y: 727}
const [result1, error1] = getColors([
    {x: 1002, y: 81},
    {x: 1061, y: 110},
    {x: 1130, y: 157},
    {x: 1216, y: 206},
    {x: 1262, y: 243},
    {x: 1325, y: 298},
    {x: 1380, y: 336},
    {x: 1458, y: 376},
    {x: 1512, y: 446},
    {x: 1574, y: 467},
    {x: 1641, y: 532},
    {x: 1713, y: 599},
    {x: 1777, y: 630},
    {x: 1833, y: 674},
    {x: 1904, y: 727}])
]]--













































