usleep(1e6); 
touchDown(0, 470, 890);
touchDown(1, 1605, 651);
usleep(5e4);
touchMove(0, 846, 840);
touchMove(1, 1194, 835);
usleep(5e4);
touchUp(0, 846, 840);
touchUp(1, 1194, 835);

-- Scroll Up

usleep(5e5); 
touchDown(2, 1000, 400);
usleep(3e4);
touchMove(2, 1000, 600);
usleep(3e4);
touchUp(2, 1000, 600);
usleep(5e5);