-- Find all instances of image and tap each one


i1 = findImage("/images/node.png", 0, 0.7, null, true, 1);
for i,v in pairs(i1) do
  tap(v[1], v[2])
  usleep(1e4)
end





































