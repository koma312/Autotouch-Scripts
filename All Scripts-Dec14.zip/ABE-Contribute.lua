function donate()
tap(1770, 660);
usleep(50000);
end
for i=10,1,-1 do donate()
end









