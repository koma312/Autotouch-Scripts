const { touchDown, touchMove, touchUp, usleep, appActivate, keyDown, keyUp, tap, toast, } = at

usleep(500000);

toast("Starting Arena", 12);
usleep(500000);
tap(1463, 1201);
usleep(12000000);

at.toast('Arena 1/5', 'center', 28)

toast("Autoplaying", 8);
usleep(500000);
tap(1982, 1467);
usleep(8000000);

toast("Victory", 6);
usleep(1500000);
tap(1953, 1451);
usleep(4500000);
usleep(500000);
tap(1953, 1451);

toast("Long waiting 15s", 4);
usleep(4000000);

toast("Long waiting 10s", 4);
usleep(4000000);

toast("Long waiting 05s", 4);
usleep(4000000);

toast("Ending", 3);
usleep(3000000);


////////////////////// 02 //////////////////

usleep(500000);

toast("Starting Arena", 12);
usleep(500000);
tap(1463, 1201);
usleep(12000000);

at.toast('Arena 2/5', 'center', 28)

toast("Autoplaying", 8);
usleep(500000);
tap(1982, 1467);
usleep(8000000);

toast("Victory", 6);
usleep(1500000);
tap(1953, 1451);
usleep(4500000);
usleep(500000);
tap(1953, 1451);

toast("Long waiting 15s", 4);
usleep(4000000);

toast("Long waiting 10s", 4);
usleep(4000000);

toast("Long waiting 05s", 4);
usleep(4000000);

toast("Ending", 3);
usleep(3000000);

////////////////////// 03 /////////////////

usleep(500000);

toast("Starting Arena", 12);
usleep(500000);
tap(1463, 1201);
usleep(12000000);

at.toast('Arena 3/5', 'center', 28)

toast("Autoplaying", 8);
usleep(500000);
tap(1982, 1467);
usleep(8000000);

toast("Victory", 6);
usleep(1500000);
tap(1953, 1451);
usleep(4500000);
usleep(500000);
tap(1953, 1451);

toast("Long waiting 15s", 4);
usleep(4000000);

toast("Long waiting 10s", 4);
usleep(4000000);

toast("Long waiting 05s", 4);
usleep(4000000);

toast("Ending", 3);
usleep(3000000);

////////////////////// 04 ////////////////

usleep(500000);

toast("Starting Arena", 12);
usleep(500000);
tap(1463, 1201);
usleep(12000000);

at.toast('Arena 4/5', 'center', 28)

toast("Autoplaying", 8);
usleep(500000);
tap(1982, 1467);
usleep(8000000);

toast("Victory", 6);
usleep(1500000);
tap(1953, 1451);
usleep(4500000);
usleep(500000);
tap(1953, 1451);

toast("Long waiting 15s", 4);
usleep(4000000);

toast("Long waiting 10s", 4);
usleep(4000000);

toast("Long waiting 05s", 4);
usleep(4000000);

toast("Ending", 3);
usleep(3000000);

////////////////////// 05 /////////////////

usleep(500000);

toast("Starting Arena", 12);
usleep(500000);
tap(1463, 1201);
usleep(12000000);

at.toast('Arena 5/5', 'center', 28)

toast("Autoplaying", 8);
usleep(500000);
tap(1982, 1467);
usleep(8000000);

toast("Victory", 6);
usleep(1500000);
tap(1953, 1451);
usleep(4500000);
usleep(500000);
tap(1953, 1451);

toast("Long waiting 15s", 4);
usleep(4000000);

toast("Long waiting 10s", 4);
usleep(4000000);

toast("Long waiting 05s", 4);
usleep(4000000);

toast("Ending", 3);
usleep(3000000);























