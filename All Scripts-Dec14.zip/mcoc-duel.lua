function tap(x, y)
	touchDown(4, x, y);
	usleep(2e4);
	touchUp(4, x, y);
	usleep(2e6)
end

usleep(2e6);
	tap(887, 193);
usleep(1e6);

	inputText('six and one');

usleep(1e6);
	tap(1541, 198);
usleep(1e6);
	tap(747, 455);
usleep(1e6);
	tap(595, 313);
usleep(1e6);
	tap(1325, 1142);
usleep(2e6);
	tap(270, 1411);
usleep(3e6);

repeat
	tap(1303, 1475);
	usleep(1e6);
	until getColor(1261, 952) == 3223600
toast('end', 2);

















































