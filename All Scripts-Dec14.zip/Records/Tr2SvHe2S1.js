const { touchDown, touchMove, touchUp, usleep, appActivate, keyDown, keyUp, toast, } = at

usleep(5e5);

function tap(x, y) {
    touchDown(0, x, y)
    usleep(2e4)
    touchUp(0, x, y)
    usleep(3e4); 
}


//Select Slot One

tap(232, 1392)
usleep(1e6); 

//Place Super Barbs

tap(168, 623)
tap(246, 566)
tap(324, 508)
tap(397, 447)
tap(478, 389)
tap(545, 331)
tap(635, 268)
tap(709, 202)
tap(853, 105)
usleep(1e6); 

//lower right 10

tap(1937, 662)
tap(1864, 735)
tap(1782, 797)
tap(1699, 851)
tap(1632, 912)
tap(1567, 956)
tap(1470, 1029)
tap(1360, 1106)
tap(1280, 1172)
tap(1173, 1252)
usleep(1e6); 

//lower left 9 (last tap maybe boost troops button)

tap(113, 649)
tap(209, 732)
tap(315, 816)
tap(411, 880)
tap(496, 945)
tap(574, 998)
tap(649, 1064)
tap(737, 1124)
tap(870, 1241)
usleep(1e6); 

//upper right 11

tap(1903, 627)
tap(1847, 591)
tap(1773, 535)
tap(1718, 489)
tap(1647, 427)
tap(1567, 361)
tap(1488, 318)
tap(1426, 271)
tap(1346, 208)
tap(1239, 132)
tap(1149, 62)
usleep(1e6); 

//Select Slot Two

tap(389, 1408)
usleep(1e6);

//Place Slot Two

    {x: 428, y: 401},
    {x: 1659, y: 448},
    {x: 1347, y: 1128},
    {x: 635, y: 1068},
    {x: 755, y: 150},
    {x: 1213, y: 109}])


//Select Spell

tap(1144, 1405);
usleep(1e6); 

//Place skeleton spells


    {x: 1649, y: 634},
    {x: 1025, y: 1124},
    {x: 416, y: 657},
    {x: 1035, y: 121},
    {x: 1036, y: 213},
    {x: 1624, y: 646},
    {x: 421, y: 655},
    {x: 1025, y: 1054},
    {x: 694, y: 391},
    {x: 742, y: 444},
    {x: 773, y: 480}])


//place Earthquakes


    {x: 687, y: 355},
    {x: 699, y: 358},
    {x: 711, y: 364},
    {x: 745, y: 378},
    {x: 1377, y: 328},
    {x: 1371, y: 348},
    {x: 1358, y: 364},
    {x: 1338, y: 389},
    {x: 1321, y: 408},
    {x: 1356, y: 373},
    {x: 728, y: 373}])


//Place Slot Four



//Select Slot Five



//Place Slot Five



//Select Slot Six



//Place Slot Six












































































