usleep(2000000);

--green button
tap(1358, 56);

usleep(2000000);

--100gems
tap(1216, 1023);

usleep(2000000);

--quick fight
tap(823, 1037);

usleep(2000000);

--battle x10
tap(1048, 967);

usleep(4000000);

--claim prize
tap(1024, 1069);

usleep(2000000);


















